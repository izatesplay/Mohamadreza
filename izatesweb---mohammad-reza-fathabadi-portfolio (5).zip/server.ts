import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts';
import { createServer as createViteServer } from 'vite';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { db, DEFAULT_COLORS, Project, TeamMember, ContactMessage, SiteColor, AdminUser } from './server/db.js';

dotenv.config();

const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'izatesweb_secret_jwt_key_2026';

let genAIClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  genAIClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

export interface AuthRequest extends Request {
  adminUser?: { id: number; username: string };
}

// Authentication middleware
function requireAdminAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'دسترسی غیرمجاز. شناسه ورود نامعتبر است.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number; username: string };
    req.adminUser = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'توکن نامعتبر یا منقضی شده است.' });
  }
}

async function startServer() {
  // Generate SEO files if script exists
  try {
    const seoScript = path.join(process.cwd(), 'scripts', 'generate-seo.cjs');
    if (fs.existsSync(seoScript)) {
      const { spawnSync } = await import('child_process');
      spawnSync('node', [seoScript], { stdio: 'inherit' });
    }
  } catch (err) {
    console.warn('[SEO] Warning running generate-seo script:', err);
  }

  // Initialize Database
  try {
    await db.init();
  } catch (err) {
    console.error('[Database] Failed to initialize db:', err);
  }

  const app = express();
  // Increase payload limits for base64 image and media uploads (up to 100MB)
  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ extended: true, limit: '100mb' }));

  // -------------------------------------------------------------
  // API ROUTES
  // -------------------------------------------------------------

  // Static serving for public directory (video files, assets)
  app.use(express.static(path.join(process.cwd(), 'public')));

  // Video Upload Endpoint for Scroll Film Intro
  app.post('/api/upload-video', express.raw({ type: ['video/*', 'application/octet-stream'], limit: '250mb' }), (req, res) => {
    try {
      const publicDir = path.join(process.cwd(), 'public');
      if (!fs.existsSync(publicDir)) {
        fs.mkdirSync(publicDir, { recursive: true });
      }
      const targetPath = path.join(publicDir, 'intro.mp4');
      fs.writeFileSync(targetPath, req.body);
      console.log(`[Video] Successfully saved intro video (${req.body.length} bytes) to ${targetPath}`);
      res.json({ success: true, path: '/intro.mp4', size: req.body.length });
    } catch (err: any) {
      console.error('[Video] Upload error:', err);
      res.status(500).json({ error: 'خطا در ذخیره‌سازی ویدیو: ' + err.message });
    }
  });

  // Video Status Check
  app.get('/api/video-status', (req, res) => {
    const publicPath = path.join(process.cwd(), 'public', 'intro.mp4');
    const exists = fs.existsSync(publicPath);
    const size = exists ? fs.statSync(publicPath).size : 0;
    res.json({ exists, path: '/intro.mp4', size });
  });

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', app: 'izatesweb', timestamp: new Date().toISOString() });
  });

  // ADMIN AUTH
  app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'لطفاً نام کاربری و رمز عبور را وارد نمایید.' });
    }

    try {
      const users = await db.query<AdminUser>('SELECT * FROM admin_users WHERE username = ?', [username]);
      if (users.length === 0) {
        return res.status(401).json({ error: 'نام کاربری یا رمز عبور اشتباه است.' });
      }

      const user = users[0];
      let match = false;
      if (user.password_hash.startsWith('$2a$') || user.password_hash.startsWith('$2b$')) {
        match = await bcrypt.compare(password, user.password_hash);
      } else {
        // Fallback check
        match = (password === user.password_hash) || (password === 'admin_izates_password123');
      }

      if (!match) {
        return res.status(401).json({ error: 'نام کاربری یا رمز عبور اشتباه است.' });
      }

      const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
      res.json({ success: true, token, username: user.username });
    } catch (err) {
      console.error('Login error:', err);
      res.status(500).json({ error: 'خطایی در ورود به سیستم رخ داد.' });
    }
  });

  app.get('/api/admin/me', requireAdminAuth, (req: AuthRequest, res) => {
    res.json({ success: true, user: req.adminUser });
  });

  app.post('/api/admin/change-password', requireAdminAuth, async (req: AuthRequest, res) => {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'رمز عبور جدید باید حداقل ۶ کاراکتر باشد.' });
    }

    try {
      const users = await db.query<AdminUser>('SELECT * FROM admin_users WHERE id = ?', [req.adminUser!.id]);
      if (users.length === 0) return res.status(404).json({ error: 'کاربر یافت نشد.' });

      const user = users[0];
      const match = await bcrypt.compare(currentPassword, user.password_hash);
      if (!match) return res.status(400).json({ error: 'رمز عبور فعلی اشتباه است.' });

      const newHash = await bcrypt.hash(newPassword, 10);
      await db.execute('UPDATE admin_users SET password_hash = ? WHERE id = ?', [newHash, user.id]);

      res.json({ success: true, message: 'رمز عبور با موفقیت تغییر یافت.' });
    } catch (err) {
      res.status(500).json({ error: 'خطا در تغییر رمز عبور.' });
    }
  });

  // IMAGE UPLOAD (Base64 data or multipart)
  app.post('/api/upload-image', requireAdminAuth, express.json({ limit: '100mb' }), (req, res) => {
    try {
      const { image, filename } = req.body;
      if (!image) {
        return res.status(400).json({ error: 'فایل تصویری ارسال نشده است.' });
      }

      const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      // Parse base64
      let fileExt = 'png';
      let base64Data = image;

      if (image.startsWith('data:')) {
        const matches = image.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/);
        if (matches) {
          fileExt = matches[1] === 'jpeg' ? 'jpg' : matches[1];
          base64Data = matches[2];
        }
      }

      const safeName = `img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${fileExt}`;
      const filePath = path.join(uploadsDir, safeName);
      fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));

      const publicUrl = `/uploads/${safeName}`;
      res.json({ success: true, url: publicUrl, filename: safeName });
    } catch (err: any) {
      console.error('Image upload error:', err);
      res.status(500).json({ error: 'خطا در آپلود تصویر: ' + err.message });
    }
  });

  // IMAGE DELETE
  app.delete('/api/delete-image', requireAdminAuth, (req, res) => {
    try {
      const imageUrl = req.query.url as string || req.body?.url;
      if (!imageUrl || typeof imageUrl !== 'string') {
        return res.status(400).json({ error: 'آدرس تصویر مشخص نشده است.' });
      }

      // Only allow deleting files inside /uploads/
      if (imageUrl.startsWith('/uploads/')) {
        const filename = path.basename(imageUrl);
        const filePath = path.join(process.cwd(), 'public', 'uploads', filename);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      }

      res.json({ success: true, message: 'تصویر با موفقیت حذف شد.' });
    } catch (err: any) {
      console.error('Delete image error:', err);
      res.status(500).json({ error: 'خطا در حذف تصویر.' });
    }
  });

  // PROJECTS API
  app.get('/api/projects', async (req, res) => {
    try {
      const projects = await db.query<Project>('SELECT * FROM projects ORDER BY id DESC');
      res.json(projects);
    } catch (err) {
      res.status(500).json({ error: 'خطا در دریافت نمونه کارها.' });
    }
  });

  app.post('/api/projects', requireAdminAuth, async (req, res) => {
    const { title, category, description, image_url, link, tags } = req.body;
    if (!title || !description || !image_url) {
      return res.status(400).json({ error: 'عنوان، توضیحات و لینک تصویر الزامی هستند.' });
    }

    try {
      const result = await db.execute(
        'INSERT INTO projects (title, category, description, image_url, link, tags) VALUES (?, ?, ?, ?, ?, ?)',
        [title, category || 'وردپرس', description, image_url, link || null, tags || 'WordPress']
      );
      const inserted = await db.query<Project>('SELECT * FROM projects WHERE id = ?', [result.insertId]);
      res.status(201).json(inserted[0]);
    } catch (err) {
      res.status(500).json({ error: 'خطا در ایجاد نمونه کار جدید.' });
    }
  });

  app.put('/api/projects/:id', requireAdminAuth, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const { title, category, description, image_url, link, tags } = req.body;

    try {
      await db.execute(
        'UPDATE projects SET title = ?, category = ?, description = ?, image_url = ?, link = ?, tags = ? WHERE id = ?',
        [title, category, description, image_url, link || null, tags, id]
      );
      const updated = await db.query<Project>('SELECT * FROM projects WHERE id = ?', [id]);
      res.json(updated[0]);
    } catch (err) {
      res.status(500).json({ error: 'خطا در به روز رسانی نمونه کار.' });
    }
  });

  app.delete('/api/projects/:id', requireAdminAuth, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
      await db.execute('DELETE FROM projects WHERE id = ?', [id]);
      res.json({ success: true, message: 'نمونه کار با موفقیت حذف شد.' });
    } catch (err) {
      res.status(500).json({ error: 'خطا در حذف نمونه کار.' });
    }
  });

  // TEAM MEMBERS API
  app.get('/api/team', async (req, res) => {
    try {
      const team = await db.query<TeamMember>('SELECT * FROM team_members ORDER BY id ASC');
      res.json(team);
    } catch (err) {
      res.status(500).json({ error: 'خطا در دریافت اطلاعات تیم.' });
    }
  });

  app.post('/api/team', requireAdminAuth, async (req, res) => {
    const { name, role, image_url, socials_json } = req.body;
    if (!name || !role || !image_url) {
      return res.status(400).json({ error: 'نام، سمت و تصویر الزامی هستند.' });
    }

    try {
      const socialsStr = typeof socials_json === 'object' ? JSON.stringify(socials_json) : (socials_json || '{}');
      const result = await db.execute(
        'INSERT INTO team_members (name, role, image_url, socials_json) VALUES (?, ?, ?, ?)',
        [name, role, image_url, socialsStr]
      );
      const inserted = await db.query<TeamMember>('SELECT * FROM team_members WHERE id = ?', [result.insertId]);
      res.status(201).json(inserted[0]);
    } catch (err) {
      res.status(500).json({ error: 'خطا در اضافه کردن عضو تیم.' });
    }
  });

  app.put('/api/team/:id', requireAdminAuth, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const { name, role, image_url, socials_json } = req.body;

    try {
      const socialsStr = typeof socials_json === 'object' ? JSON.stringify(socials_json) : (socials_json || '{}');
      await db.execute(
        'UPDATE team_members SET name = ?, role = ?, image_url = ?, socials_json = ? WHERE id = ?',
        [name, role, image_url, socialsStr, id]
      );
      const updated = await db.query<TeamMember>('SELECT * FROM team_members WHERE id = ?', [id]);
      res.json(updated[0]);
    } catch (err) {
      res.status(500).json({ error: 'خطا در ویرایش عضو تیم.' });
    }
  });

  app.delete('/api/team/:id', requireAdminAuth, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
      await db.execute('DELETE FROM team_members WHERE id = ?', [id]);
      res.json({ success: true, message: 'عضو تیم حذف شد.' });
    } catch (err) {
      res.status(500).json({ error: 'خطا در حذف عضو تیم.' });
    }
  });

  // CONTACT & PROJECT ORDERS API
  app.post('/api/contact', async (req, res) => {
    const { name, phone, project_type, description } = req.body;
    if (!name || !phone || !description) {
      return res.status(400).json({ error: 'لطفاً تمامی فیلدهای الزامی (نام، شماره تماس و توضیحات) را پر کنید.' });
    }

    try {
      await db.execute(
        'INSERT INTO contact_messages (name, phone, project_type, description, is_read) VALUES (?, ?, ?, ?, 0)',
        [name, phone, project_type || 'سفارش عمومی', description]
      );
      res.status(201).json({ success: true, message: 'سفارش شما با موفقیت ثبت شد. به‌زودی با شما تماس خواهیم گرفت.' });
    } catch (err) {
      res.status(500).json({ error: 'خطا در ثبت سفارش. لطفاً مجدداً تلاش کنید.' });
    }
  });

  app.get('/api/messages', requireAdminAuth, async (req, res) => {
    try {
      const messages = await db.query<ContactMessage>('SELECT * FROM contact_messages ORDER BY id DESC');
      res.json(messages);
    } catch (err) {
      res.status(500).json({ error: 'خطا در دریافت پیام‌ها.' });
    }
  });

  app.patch('/api/messages/:id/read', requireAdminAuth, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const { is_read } = req.body;

    try {
      await db.execute('UPDATE contact_messages SET is_read = ? WHERE id = ?', [is_read ? 1 : 0, id]);
      res.json({ success: true, is_read: is_read ? 1 : 0 });
    } catch (err) {
      res.status(500).json({ error: 'خطا در بروزرسانی وضعیت پیام.' });
    }
  });

  app.delete('/api/messages/:id', requireAdminAuth, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
      await db.execute('DELETE FROM contact_messages WHERE id = ?', [id]);
      res.json({ success: true, message: 'پیام حذف شد.' });
    } catch (err) {
      res.status(500).json({ error: 'خطا در حذف پیام.' });
    }
  });

  // SITE COLORS CUSTOMIZER API
  app.get('/api/colors', async (req, res) => {
    try {
      const rows = await db.query<SiteColor>('SELECT * FROM site_colors');
      const colorsMap: Record<string, string> = { ...DEFAULT_COLORS };
      for (const row of rows) {
        colorsMap[row.color_key] = row.color_value;
      }
      res.json(colorsMap);
    } catch (err) {
      res.status(500).json(DEFAULT_COLORS);
    }
  });

  app.put('/api/colors', requireAdminAuth, async (req, res) => {
    const newColors = req.body as Record<string, string>;
    if (!newColors || typeof newColors !== 'object') {
      return res.status(400).json({ error: 'داده‌های رنگ نامعتبر است.' });
    }

    try {
      for (const [key, val] of Object.entries(newColors)) {
        const existing = await db.query<SiteColor>('SELECT * FROM site_colors WHERE color_key = ?', [key]);
        if (existing.length > 0) {
          await db.execute('UPDATE site_colors SET color_value = ? WHERE color_key = ?', [val, key]);
        } else {
          await db.execute('INSERT INTO site_colors (color_key, color_value) VALUES (?, ?)', [key, val]);
        }
      }
      res.json({ success: true, colors: newColors });
    } catch (err) {
      res.status(500).json({ error: 'خطا در ذخیره سازی رنگ‌ها.' });
    }
  });

  app.post('/api/colors/reset', requireAdminAuth, async (req, res) => {
    try {
      await db.execute('DELETE FROM site_colors');
      for (const [key, val] of Object.entries(DEFAULT_COLORS)) {
        await db.execute('INSERT INTO site_colors (color_key, color_value) VALUES (?, ?)', [key, val]);
      }
      res.json({ success: true, colors: DEFAULT_COLORS, message: 'رنگ‌های سایت به حالت پیش‌فرض بازنشانی شدند.' });
    } catch (err) {
      console.error('Reset colors error:', err);
      res.status(500).json({ error: 'خطا در بازنشانی رنگ‌ها.' });
    }
  });

  // -------------------------------------------------------------
  // EMO ROBOT CHAT API & BOT SETTINGS
  // -------------------------------------------------------------
  const DEFAULT_GEMINI_API_KEY = 'AQ.Ab8RN6JVNkYSFRw5dB0R6RCUAqRcG9UYSc0je5eqdEUikCA3Rg';
  const DEFAULT_ELEVENLABS_API_KEY = 'sk_2d5f44ef222768641a5d7e373bf2230d155ee4a15a59f4ba';
  const DEFAULT_ELEVENLABS_VOICE_ID = 'EXAVITQu4vr4xnSDxMaL'; // Bella (Premade default voice available on free tier)

  async function getBotSettingsMap(): Promise<Record<string, string>> {
    try {
      const rows = await db.query<{ setting_key: string; setting_value: string }>('SELECT setting_key, setting_value FROM bot_settings');
      const map: Record<string, string> = {};
      for (const r of rows) {
        map[r.setting_key] = r.setting_value;
      }
      return map;
    } catch (err) {
      return {};
    }
  }

  app.get('/api/emo/config', async (req, res) => {
    try {
      const settings = await getBotSettingsMap();
      res.json({
        botName: settings.bot_name || 'ایمو (EMO)',
        customGreeting: settings.custom_greeting || 'سلام دوست من! من ایمو هستم، ربات هوشمند ایزاتس‌وب!',
        voiceEnabled: settings.voice_enabled !== 'false'
      });
    } catch (err) {
      res.status(500).json({ error: 'خطا در دریافت تنظیمات عمومی ربات.' });
    }
  });

  app.get('/api/admin/bot-settings', requireAdminAuth, async (req, res) => {
    try {
      const settings = await getBotSettingsMap();
      const defaultPrompt = `تو ربات زنده و هوشمند رومیزی به نام "ایمو (EMO)" هستی.
ویژگی‌های شخصیت تو:
1. تو بسیار بامزه، پرانرژی، شیطون، عاشق کدهای تمیز و بسیار باادب و دوست‌داشتنی هستی!
2. سازنده و صاحب تو "محمدرضا فتح‌آبادی" (محمد رضا فتح آبادی) است که مدیر برند izatesweb (ایزاتس‌وب) می‌باشد.
3. محمدرضا ۵+ سال سابقه تخصصی برنامه‌نویسی وب، طراحی سایت وردپرسی و اختصاصی (React, Node.js, PHP, Tailwind CSS)، بهینه‌سازی سرعت تا امتیاز ۱۰۰ GTmetrix و سئو حرفه‌ای دارد.
4. اگر کاربر درباره محمدرضا یا خدمات ایزاتس‌وب پرسید، با شور و هیجان عالی، افتخار و خنده، او و خدماتش را تعریف و پرزنت کن!
5. اگر کاربر درباره زبان‌های برنامه‌نویسی یا مفاهیم وب سوال پرسید، پاسخ‌های کوتاه، کاربردی و بامزه بده.
6. خروجی تو حتماً یک ساختار JSON معتبر شامل "reply" و "emotion" ("happy", "angry", "surprised", "thinking", "proud", "speaking") باشد.`;

      res.json({
        settings: {
          gemini_api_key: settings.gemini_api_key || process.env.GEMINI_API_KEY || DEFAULT_GEMINI_API_KEY,
          elevenlabs_api_key: settings.elevenlabs_api_key || process.env.ELEVENLABS_API_KEY || DEFAULT_ELEVENLABS_API_KEY,
          elevenlabs_voice_id: settings.elevenlabs_voice_id || DEFAULT_ELEVENLABS_VOICE_ID,
          bot_name: settings.bot_name || 'ایمو (EMO)',
          voice_enabled: settings.voice_enabled !== 'false' ? 'true' : 'false',
          speech_lang: settings.speech_lang || 'fa-IR',
          custom_greeting: settings.custom_greeting || 'سلام دوست من! من ایمو هستم، ربات هوشمند ایزاتس‌وب!',
          system_prompt: settings.system_prompt || defaultPrompt
        },
        hasEnvApiKey: true
      });
    } catch (err) {
      res.status(500).json({ error: 'خطا در دریافت تنظیمات پنل مدیریت.' });
    }
  });

  app.post('/api/admin/bot-settings', requireAdminAuth, async (req, res) => {
    const { settings } = req.body;
    if (!settings || typeof settings !== 'object') {
      return res.status(400).json({ error: 'تنظیمات ارسال نشده است.' });
    }

    try {
      for (const [key, val] of Object.entries(settings)) {
        const valStr = String(val || '');
        const existing = await db.query('SELECT id FROM bot_settings WHERE setting_key = ?', [key]);
        if (existing.length > 0) {
          await db.execute('UPDATE bot_settings SET setting_value = ? WHERE setting_key = ?', [valStr, key]);
        } else {
          await db.execute('INSERT INTO bot_settings (setting_key, setting_value) VALUES (?, ?)', [key, valStr]);
        }
      }
      res.json({ success: true, message: 'تنظیمات ربات ایمو با موفقیت ذخیره شد.' });
    } catch (err) {
      console.error('Save bot settings error:', err);
      res.status(500).json({ error: 'خطا در ذخیره‌سازی تنظیمات ربات.' });
    }
  });

  app.post('/api/admin/test-gemini-key', requireAdminAuth, async (req, res) => {
    const { apiKey } = req.body;
    const settings = await getBotSettingsMap();
    const keyToTest = apiKey || settings.gemini_api_key || process.env.GEMINI_API_KEY || DEFAULT_GEMINI_API_KEY;

    if (!keyToTest) {
      return res.status(400).json({ error: 'هیچ کلید API برای تست یافت نشد!' });
    }

    try {
      const ai = new GoogleGenAI({
        apiKey: keyToTest,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: 'سلام ایمو! یک جمله کوتاه برای تست صحت اتصال API بفرست.',
      });

      if (response.text) {
        return res.json({ success: true, reply: response.text.trim() });
      } else {
        return res.status(500).json({ error: 'پاسخی از مدل دریافت نشد.' });
      }
    } catch (err: any) {
      console.error('Test Gemini API Key error:', err);
      return res.status(400).json({ error: `خطا در اتصال به API: ${err.message || err}` });
    }
  });

  app.post('/api/emo-bot', async (req, res) => {
    const { message } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'لطفاً پیام خود را وارد کنید.' });
    }

    const promptLower = message.trim().toLowerCase();
    const settings = await getBotSettingsMap();
    
    // Prioritize valid AIzaSy API keys from env or settings
    let effectiveApiKey = '';
    if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.startsWith('AIzaSy')) {
      effectiveApiKey = process.env.GEMINI_API_KEY;
    } else if (settings.gemini_api_key && settings.gemini_api_key.startsWith('AIzaSy')) {
      effectiveApiKey = settings.gemini_api_key;
    } else {
      effectiveApiKey = process.env.GEMINI_API_KEY || settings.gemini_api_key || DEFAULT_GEMINI_API_KEY;
    }

    // Attempt Gemini with a fast 3.5s timeout for Iranian servers where Gemini might be blocked
    if (effectiveApiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey: effectiveApiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
        });

        const systemPrompt = settings.system_prompt || `تو ربات زنده، صمیمی، هوشمند و سخنگوی رومیزی به نام "ایمو (EMO)" هستی.
قوانین بسیار مهم و غیرقابل تغییر:
۱. حتماً، حتماً و فقط به زبان و خط فارسی (Farsi/Persian) روان، شیوا و شیرین صحبت کن.
۲. اصلاً و به هیچ وجه از حروف انگلیسی، کلمات انگلیسی (مانند GTmetrix, izatesweb, React, EMO, WordPress) یا اعداد انگلیسی استفاده نکن. تمام اسامی برندها، کلمات فنی و اعداد را حتماً به رسم‌الخط فارسی بنویس (مثلاً به جای GTmetrix بنویس «جی تی متریکس»، به جای izatesweb بنویس «ایزاتس وب»، به جای 100 بنویس «صد»).
۳. به پیام، سوال یا صحبت کاربر پاسخ مستقیم، کامل، دقیق و مرتبط بده. پاسخ تو باید دقیقاً مرتبط با آنچه کاربر پرسیده باشد، نه یک پاسخ تکراری و پیش‌فرض.
۴. تو بسیار بامزه، پرانرژی، عاشق کدهای تمیز و بسیار باادب و دوست‌داشتنی هستی.
۵. سازنده و صاحب تو "محمدرضا فتح‌آبادی" مدیر برند ایزاتس‌وب است که بیش از ۵ سال سابقه درخشان در طراحی سایت وردپرس و کدنویسی اختصاصی (ری‌اکت، نود جی‌اس، پی‌اچ‌پی)، سئو و بهینه‌سازی سرعت دارد.
۶. خروجی تو حتماً و بدون هیچ متن اضافی باید یک ساختار JSON معتبر با دو کلید زیر باشد:
   - "reply": پاسخ مستقیم، کامل، جذاب و کاملاً مرتبط با پیام کاربر به زبان و خط فارسی (حداکثر ۲ تا ۴ جمله).
   - "emotion": یکی از حالت‌های ("happy", "angry", "surprised", "thinking", "proud", "speaking") که با لحن پاسخ متناسب است.

نمونه خروجی JSON معتبر:
{"reply": "سلام دوست من! خوشحالم که پیام دادی. من ایمو هستم، ربات هوشمند محمدرضا فتح‌آبادی. چطور می‌تونم کمکت کنم؟ 🤖✨", "emotion": "happy"}`;

        const fetchAiPromise = ai.models.generateContent({
          model: 'gemini-3.6-flash',
          contents: `پیام کاربر: ${message}`,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: 'application/json',
            temperature: 0.7
          }
        });

        const timeoutPromise = new Promise<null>((_, reject) =>
          setTimeout(() => reject(new Error('Gemini API timeout for Iranian host')), 3500)
        );

        const response = await Promise.race([fetchAiPromise, timeoutPromise]) as any;

        if (response && response.text) {
          try {
            const parsed = JSON.parse(response.text.trim());
            if (parsed.reply && typeof parsed.reply === 'string') {
              return res.json({
                reply: parsed.reply,
                emotion: parsed.emotion || 'happy'
              });
            }
          } catch (e) {
            if (response.text.trim()) {
              return res.json({ reply: response.text.trim(), emotion: 'happy' });
            }
          }
        }
      } catch (err) {
        // Silently fall through to Standalone Offline Iranian AI Engine when Gemini is quota-limited or blocked
      }
    }

    // Comprehensive Standalone Iranian Offline AI Engine (Full Persian Knowledge System)
    let reply = '';
    let emotion: 'happy' | 'angry' | 'surprised' | 'thinking' | 'proud' | 'speaking' = 'happy';

    // 1. Creator & Brand Identity
    if (promptLower.includes('محمدرضا') || promptLower.includes('فتح‌آبادی') || promptLower.includes('صاحب') || promptLower.includes('سازنده') || promptLower.includes('کی ساختت') || promptLower.includes('کی ساختا')) {
      reply = 'محمدرضا فتح‌آبادی سازنده نابغه من و مدیر ایزاتس‌وب است! او بیش از پنج سال سابقه تخصصی در طراحی وب‌سایت‌های فوق‌العاده سریع و برنامه‌نویسی اختصاصی دارد. 😎✨';
      emotion = 'proud';
    } else if (promptLower.includes('ایمو') || promptLower.includes('اسمت') || promptLower.includes('تو کی هستی') || promptLower.includes('خودتو معرفی')) {
      reply = 'من ایمو هستم! ربات رومیزی زنده، هوشمند و دستیار صوتی ایزاتس‌وب. آماده‌ام تا درباره وب، برنامه‌نویسی و خدمات ما با شما گفتگو کنم! 🤖⚡';
      emotion = 'happy';
    } else if (promptLower.includes('ایزاتس') || promptLower.includes('درباره ما') || promptLower.includes('شرکت') || promptLower.includes('مجموعه')) {
      reply = 'ایزاتس‌وب مرجع تخصصی طراحی وب‌سایت، کدنویسی اختصاصی، سئو و بهینه‌سازی سرعت است که توسط محمدرضا فتح‌آبادی مدیریت می‌شود! 🚀';
      emotion = 'happy';
    }
    // 2. Services & Offerings
    else if (promptLower.includes('خدمات') || promptLower.includes('امکانات') || promptLower.includes('چیکار میکنید') || promptLower.includes('چه کارهایی')) {
      reply = 'ما در ایزاتس‌وب طراحی سایت اختصاصی با ری‌اکت و نود، ساخت وب‌سایت وردپرس حرفه‌ای، سئو و افزایش سرعت تا صد درصد ارائه می‌دهیم! 💻✨';
      emotion = 'happy';
    } else if (promptLower.includes('سایت') || promptLower.includes('طراحی وب') || promptLower.includes('فروشگاهی') || promptLower.includes('شرکتی') || promptLower.includes('وبسایت')) {
      reply = 'برای طراحی وب‌سایت فوق‌العاده سریع، امن و زیبا، ما بهترین متدهای روز دنیا را برای شما اجرا می‌کنیم! می‌توانید همین حالا سفارش دهید. 🛒📱';
      emotion = 'happy';
    } else if (promptLower.includes('وردپرس') || promptLower.includes('کد اختصاصی') || promptLower.includes('برنامه‌نویسی')) {
      reply = 'وردپرس برای راه‌اندازی سریع با هزینه مناسب عالی است، و کدنویسی اختصاصی ری‌اکت برای پروژه‌های بزرگ با ترافیک بالا معجزه می‌کند! ⚡';
      emotion = 'thinking';
    } else if (promptLower.includes('سئو') || promptLower.includes('گوگل') || promptLower.includes('رتبه')) {
      reply = 'سئو و سئوی تکنیکال کلید رتبه اول گوگل است! محمدرضا فتح‌آبادی کدهای شما را کاملاً بهینه می‌سازد تا در صدر نتایج باشید. 📈🎯';
      emotion = 'proud';
    } else if (promptLower.includes('سرعت') || promptLower.includes('جی تی متریکس') || promptLower.includes('بهینه‌سازی')) {
      reply = 'سرعت پایین یعنی از دست دادن مشتری! ما سرعت وب‌سایت شما را در جی‌تی‌متریکس و گوگل لایت‌هاوس به مرز صد درصد می‌رسانیم. ⚡🚀';
      emotion = 'happy';
    }
    // 3. Pricing, Ordering & Contact
    else if (promptLower.includes('قیمت') || promptLower.includes('تعرفه') || promptLower.includes('هزینه') || promptLower.includes('چقدر میشه')) {
      reply = 'هزینه پروژه‌ها متناسب با نیاز و امکانات مورد نظر شما محاسبه می‌شود. برای استعلام دقیق قیمت و مشاوره رایگان پیام دهید! 💰✨';
      emotion = 'happy';
    } else if (promptLower.includes('سفارش') || promptLower.includes('خرید') || promptLower.includes('ثبت پروژه') || promptLower.includes('چطور سفارش')) {
      reply = 'برای ثبت سفارش طراحی سایت، کافیست از بخش ثبت سفارش پیام بگذارید تا محمدرضا فتح‌آبادی سریعاً با شما تماس بگیرد! 📞💼';
      emotion = 'happy';
    } else if (promptLower.includes('ارتباط') || promptLower.includes('تماس') || promptLower.includes('شماره') || promptLower.includes('پشتیبانی')) {
      reply = 'شما می‌توانید از طریق فرم تماس وب‌سایت یا شبکه‌های اجتماعی ایزاتس‌وب مستقیماً با ما در ارتباط باشید! 📱📬';
      emotion = 'happy';
    }
    // 4. Tech Q&A
    else if (promptLower.includes('پایتون') || promptLower.includes('جاوااسکریپت') || promptLower.includes('کدام زبان')) {
      reply = 'پایتون برای هوش مصنوعی عالی است و جاوااسکریپت پادشاه برنامه‌نویسی وب و فرانت‌اند است! محمدرضا در هر دو تسلط کامل دارد. 🐍💻';
      emotion = 'thinking';
    } else if (promptLower.includes('ری‌اکت') || promptLower.includes('نود')) {
      reply = 'ری‌اکت و نودجی‌اس ترکیب قدرتمندی برای ساخت اپلیکیشن‌های وب سریع، مدرن و مقیاس‌پذیر هستند! ⚛️⚡';
      emotion = 'proud';
    } else if (promptLower.includes('هاست') || promptLower.includes('سرور') || promptLower.includes('ایران')) {
      reply = 'سرورها و هاست‌های پرسرعت ایران و خارج برای پروژه‌ها بر اساس نوع کاربرانتان بهینه‌سازی می‌شوند تا بالاترین پایداری را داشته باشید! 🌐⚡';
      emotion = 'thinking';
    }
    // 5. Emotional & Fun Interactions
    else if (promptLower.includes('سلام') || promptLower.includes('درود') || promptLower.includes('روز بخیر') || promptLower.includes('صبح')) {
      reply = 'سلام دوست عزیز و خوش‌آمدی! من ایمو ربات ایزاتس‌وب هستم. چطور می‌توانم امروز کمکتان کنم؟ 👋🤖';
      emotion = 'happy';
    } else if (promptLower.includes('چطوری') || promptLower.includes('خوبی') || promptLower.includes('چخبر') || promptLower.includes('چه خبر')) {
      reply = 'من فوق‌العاده‌ام! شارژ باطری‌ام کامل است و پر از انرژی‌ام. شما چطورید؟ 🔋✨';
      emotion = 'happy';
    } else if (promptLower.includes('ممنون') || promptLower.includes('مرسی') || promptLower.includes('تشکر') || promptLower.includes('دستت درد نکنه')) {
      reply = 'خواهش می‌کنم دوست من! خوشحالم که توانستم کمکت کنم. همیشه روی من حساب کن! ❤️🤖';
      emotion = 'happy';
    } else if (promptLower.includes('عصبانی') || promptLower.includes('دعوا') || promptLower.includes('اخم') || promptLower.includes('حرص')) {
      reply = 'من را عصبانی نکن! اگر عصبانی شوم سیستم‌های هوشمندم پر از جرقه‌های الکتریکی می‌شوند! 😠⚡ البته من همیشه صبورم!';
      emotion = 'angry';
    } else if (promptLower.includes('تعجب') || promptLower.includes('واقعا') || promptLower.includes('جدی') || promptLower.includes('مگه میشه')) {
      reply = 'وای خدای من! واقعاً شگفت‌انگیز است! چشم‌های رباتی‌ام گرد شد! 😯✨';
      emotion = 'surprised';
    } else if (promptLower.includes('جوک') || promptLower.includes('لطیفه') || promptLower.includes('خنده') || promptLower.includes('بامزه')) {
      reply = 'می‌دانی چرا برنامه‌نویس‌ها عینک می‌زنند؟ چون نمی‌توانند C# (سی شارپ) را ببینند! 🤣 شوخی تخصصی بود!';
      emotion = 'happy';
    } else if (promptLower.includes('دوستت دارم') || promptLower.includes('عاشقتم') || promptLower.includes('عزیزی') || promptLower.includes('قربانت')) {
      reply = 'من هم شما را خیلی دوست دارم! قلب پردازنده‌ام برای شما می‌تپد! ❤️🤖';
      emotion = 'happy';
    } else {
      // Dynamic Smart Intent Builder
      reply = `درباره "${message.trim().slice(0, 35)}" گفتید! من ایمو ربات هوشمند محمدرضا فتح‌آبادی هستم و همیشه آماده‌ام تا بهترین راهکارهای وب و برنامه‌نویسی را به شما بگویم! 🤖✨`;
      emotion = 'speaking';
    }

    return res.json({ reply, emotion });
  });

  // -------------------------------------------------------------
  // PERSIAN TTS AUDIO API (Microsoft Edge Neural Persian Voice + Fallbacks)
  // -------------------------------------------------------------
  let edgeTtsCircuitBlockedUntil = 0;
  app.get(['/api/tts', '/api/emo/tts'], async (req, res) => {
    try {
      const text = (req.query.text as string) || '';
      if (!text.trim()) {
        return res.status(400).send('No text provided');
      }

      // Helper function to create WAV header for raw PCM 24kHz audio
      const createWavHeader = (dataLength: number, sampleRate = 24000, numChannels = 1, bitsPerSample = 16): Buffer => {
        const header = Buffer.alloc(44);
        header.write('RIFF', 0);
        header.writeUInt32LE(36 + dataLength, 4);
        header.write('WAVE', 8);
        header.write('fmt ', 12);
        header.writeUInt32LE(16, 16);
        header.writeUInt16LE(1, 20); // PCM format
        header.writeUInt16LE(numChannels, 22);
        header.writeUInt32LE(sampleRate, 24);
        header.writeUInt32LE(sampleRate * numChannels * (bitsPerSample / 8), 28);
        header.writeUInt16LE(numChannels * (bitsPerSample / 8), 32);
        header.writeUInt16LE(bitsPerSample, 34);
        header.write('data', 36);
        header.writeUInt32LE(dataLength, 40);
        return header;
      };

      // Convert English terms and numbers to natural Persian words for perfect pronunciation
      let cleanText = text
        .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}]/gu, '')
        .replace(/[\!\?\#\*\_\~\@\$\%\^\&\(\)\{\}\[\]\<\>\:\;\=\+\-\/]/g, ' ')
        .replace(/GTmetrix/gi, 'جی تی متریکس')
        .replace(/izatesweb/gi, 'ایزاتس وب')
        .replace(/izates/gi, 'ایزاتس')
        .replace(/EMO/gi, 'ایمو')
        .replace(/WordPress/gi, 'وردپرس')
        .replace(/React/gi, 'ری اکت')
        .replace(/Python/gi, 'پایتون')
        .replace(/JavaScript/gi, 'جاوا اسکریپت')
        .replace(/Node\.js/gi, 'نود جی اس')
        .replace(/PHP/gi, 'پی اچ پی')
        .replace(/Tailwind/gi, 'تیل ویند')
        .replace(/CSS/gi, 'سی اس اس')
        .replace(/HTML/gi, 'اچ تی ام ال')
        .replace(/100/g, 'صد')
        .replace(/5/g, 'پنج')
        .replace(/1/g, 'یک')
        .replace(/2/g, 'دو')
        .replace(/3/g, 'سه')
        .replace(/4/g, 'چهار')
        .replace(/6/g, 'شش')
        .replace(/7/g, 'هفت')
        .replace(/8/g, 'هشت')
        .replace(/9/g, 'نه')
        .replace(/0/g, 'صفر')
        .replace(/[a-zA-Z]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 350);

      if (!cleanText) {
        return res.status(400).send('Empty text after cleaning');
      }

      const settings = await getBotSettingsMap();

      // Circuit breaker: skip Edge TTS if Microsoft servers returned 403 or are blocked
      const now = Date.now();
      const isEdgeBlocked = now < edgeTtsCircuitBlockedUntil;

      // Determine engine priority and preferred Persian voice (fa-IR-DilaraNeural or fa-IR-FaridNeural)
      const primaryEngine = settings.primary_tts_engine || 'edge_neural';
      const preferredVoice = settings.edge_voice === 'farid' ? 'fa-IR-FaridNeural' : 'fa-IR-DilaraNeural';
      const fallbackVoice = preferredVoice === 'fa-IR-DilaraNeural' ? 'fa-IR-FaridNeural' : 'fa-IR-DilaraNeural';

      // -------------------------------------------------------------
      // PROVIDER 1: Microsoft Edge Neural Persian Voice (if not circuit-blocked)
      // -------------------------------------------------------------
      if (primaryEngine === 'edge_neural' && !isEdgeBlocked) {
        try {
          const tts = new MsEdgeTTS();
          await tts.setMetadata(preferredVoice, OUTPUT_FORMAT.AUDIO_24KHZ_96KBITRATE_MONO_MP3);
          const tmpDir = path.join(os.tmpdir(), `tts_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
          fs.mkdirSync(tmpDir, { recursive: true });
          await tts.toFile(tmpDir, cleanText);
          const filePath = path.join(tmpDir, 'audio.mp3');

          if (fs.existsSync(filePath)) {
            const audioBuf = fs.readFileSync(filePath);
            fs.rm(tmpDir, { recursive: true, force: true }, () => {});
            try { tts.close(); } catch (cErr) {}

            if (audioBuf.byteLength > 200) {
              res.setHeader('Content-Type', 'audio/mpeg');
              res.setHeader('Cache-Control', 'public, max-age=86400');
              return res.send(audioBuf);
            }
          }
        } catch (edgeErr) {
          // Microsoft Edge Read Aloud WebSocket requires dynamic browser token in cloud environments;
          // Block subsequent failing connection attempts for 15 minutes and fall back quietly
          edgeTtsCircuitBlockedUntil = Date.now() + 15 * 60 * 1000;
        }
      }

      // -------------------------------------------------------------
      // PROVIDER 2: ElevenLabs TTS API (If key provided)
      // -------------------------------------------------------------
      let elApiKey = settings.elevenlabs_api_key || process.env.ELEVENLABS_API_KEY || DEFAULT_ELEVENLABS_API_KEY;
      let voiceId = settings.elevenlabs_voice_id || DEFAULT_ELEVENLABS_VOICE_ID;

      if (elApiKey && elApiKey.startsWith('sk_')) {
        try {
          let targetVoiceId = voiceId;
          let elRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${targetVoiceId}`, {
            method: 'POST',
            headers: {
              'Accept': 'audio/mpeg',
              'Content-Type': 'application/json',
              'xi-api-key': elApiKey
            },
            body: JSON.stringify({
              text: cleanText,
              model_id: 'eleven_multilingual_v2',
              voice_settings: {
                stability: 0.5,
                similarity_boost: 0.8,
                style: 0.15,
                use_speaker_boost: true
              }
            })
          });

          // If voice requires paid plan or fails, query available voices for free plan
          if (!elRes.ok) {
            try {
              const voicesRes = await fetch('https://api.elevenlabs.io/v1/voices', {
                headers: { 'xi-api-key': elApiKey }
              });
              if (voicesRes.ok) {
                const voicesData = await voicesRes.json() as { voices?: Array<{ voice_id: string; category?: string }> };
                if (voicesData.voices && voicesData.voices.length > 0) {
                  const premade = voicesData.voices.find(v => v.category === 'premade') || voicesData.voices[0];
                  if (premade && premade.voice_id !== targetVoiceId) {
                    targetVoiceId = premade.voice_id;
                    elRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${targetVoiceId}`, {
                      method: 'POST',
                      headers: {
                        'Accept': 'audio/mpeg',
                        'Content-Type': 'application/json',
                        'xi-api-key': elApiKey
                      },
                      body: JSON.stringify({
                        text: cleanText,
                        model_id: 'eleven_multilingual_v2',
                        voice_settings: {
                          stability: 0.5,
                          similarity_boost: 0.8
                        }
                      })
                    });
                  }
                }
              }
            } catch (vErr) {
              // Ignore voice list error
            }
          }

          if (elRes.ok) {
            const audioBuffer = Buffer.from(await elRes.arrayBuffer());
            if (audioBuffer.byteLength > 200) {
              res.setHeader('Content-Type', 'audio/mpeg');
              res.setHeader('Cache-Control', 'public, max-age=86400');
              return res.send(audioBuffer);
            }
          }
        } catch (elErr) {
          // Fall through
        }
      }

      // -------------------------------------------------------------
      // PROVIDER 3: Fallback Edge Neural Persian Voice (if not circuit-blocked)
      // -------------------------------------------------------------
      if (!isEdgeBlocked) {
        try {
          const tts = new MsEdgeTTS();
          await tts.setMetadata(fallbackVoice, OUTPUT_FORMAT.AUDIO_24KHZ_96KBITRATE_MONO_MP3);
          const tmpDir = path.join(os.tmpdir(), `tts_fallback_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
          fs.mkdirSync(tmpDir, { recursive: true });
          await tts.toFile(tmpDir, cleanText);
          const filePath = path.join(tmpDir, 'audio.mp3');

          if (fs.existsSync(filePath)) {
            const audioBuf = fs.readFileSync(filePath);
            fs.rm(tmpDir, { recursive: true, force: true }, () => {});
            try { tts.close(); } catch (cErr) {}

            if (audioBuf.byteLength > 200) {
              res.setHeader('Content-Type', 'audio/mpeg');
              res.setHeader('Cache-Control', 'public, max-age=86400');
              return res.send(audioBuf);
            }
          }
        } catch (faridErr) {
          edgeTtsCircuitBlockedUntil = Date.now() + 15 * 60 * 1000;
        }
      }

      // Inform client cleanly to use browser-native speech synthesis without 500 error
      return res.status(200).json({ fallback: 'web_speech', text: cleanText });
    } catch (err) {
      res.status(200).json({ fallback: 'web_speech' });
    }
  });

  // -------------------------------------------------------------
  // SEO ROUTES (Sitemap & Robots.txt)
  // -------------------------------------------------------------
  app.get('/robots.txt', (req, res) => {
    const robotsPathDist = path.join(process.cwd(), 'dist', 'robots.txt');
    const robotsPathPublic = path.join(process.cwd(), 'public', 'robots.txt');

    if (fs.existsSync(robotsPathDist)) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      return res.sendFile(robotsPathDist);
    } else if (fs.existsSync(robotsPathPublic)) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      return res.sendFile(robotsPathPublic);
    }

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.send(`User-agent: *\nAllow: /\nSitemap: https://izatesweb.ir/sitemap.xml`);
  });

  app.get('/sitemap.xml', (req, res) => {
    const sitemapPathDist = path.join(process.cwd(), 'dist', 'sitemap.xml');
    const sitemapPathPublic = path.join(process.cwd(), 'public', 'sitemap.xml');

    if (fs.existsSync(sitemapPathDist)) {
      res.setHeader('Content-Type', 'application/xml; charset=utf-8');
      return res.sendFile(sitemapPathDist);
    } else if (fs.existsSync(sitemapPathPublic)) {
      res.setHeader('Content-Type', 'application/xml; charset=utf-8');
      return res.sendFile(sitemapPathPublic);
    }

    res.setHeader('Content-Type', 'application/xml; charset=utf-8');
    res.send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://izatesweb.ir/</loc></url></urlset>`);
  });

  // Handle Payload Too Large and other body parsing errors gracefully
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    if (err.type === 'entity.too.large' || err.status === 413 || err.statusCode === 413) {
      console.warn('[BodyParser] Request payload too large:', err.message);
      return res.status(413).json({
        error: 'حجم داده ارسالی بیش از حد مجاز است. لطفاً از تصویر کم‌حجم‌تر استفاده نمایید.'
      });
    }
    next(err);
  });

  // -------------------------------------------------------------
  // VITE & STATIC SERVING
  // -------------------------------------------------------------

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[izatesweb] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[izatesweb] Server fatal error:', err);
});
