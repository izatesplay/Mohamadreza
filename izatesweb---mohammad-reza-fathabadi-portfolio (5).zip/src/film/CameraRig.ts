import * as THREE from 'three';
import { getCameraSpine, calculateCameraSwing } from './WebCorridor';
import { clamp01 } from './types';

// Rodrigues rotation: rotates vector v around unit axis k by angle theta
function rodriguesRotate(v: THREE.Vector3, k: THREE.Vector3, theta: number): THREE.Vector3 {
  const cosTheta = Math.cos(theta);
  const sinTheta = Math.sin(theta);
  const kCrossV = new THREE.Vector3().crossVectors(k, v);
  const kDotV = k.dot(v);

  return new THREE.Vector3()
    .copy(v).multiplyScalar(cosTheta)
    .addScaledVector(kCrossV, sinTheta)
    .addScaledVector(k, kDotV * (1.0 - cosTheta));
}

export class CameraRig {
  public camera: THREE.PerspectiveCamera;
  public lookTarget: THREE.Vector3 = new THREE.Vector3();
  private baseUp: THREE.Vector3 = new THREE.Vector3(0, 1, 0);

  constructor() {
    this.camera = new THREE.PerspectiveCamera(54, window.innerWidth / window.innerHeight, 0.1, 1200);
    // Prompt: "Set camera.rotation.order = 'YXZ'; the default XYZ leaks visible roll the moment both axes are non-zero."
    this.camera.rotation.order = 'YXZ';
  }

  public update(sp: number, p: number, reducedMotion: boolean, fog: THREE.Fog | null, mouseX: number = 0, mouseY: number = 0) {
    // 1. Evaluate base camera spine (gear changes 300 -> 150 -> 360)
    const spinePos = getCameraSpine(sp);

    // 2. Evaluate swing positional offset and bank angle from the shared table
    // Lateral side * 3.2 * sin(pi*u), 1.5 dip, 0.15 rad bank into turn
    const { offset: swingOffset, bank: bankAngle } = calculateCameraSwing(sp, reducedMotion);

    // 3. Subtle organic mouse tilt parallax
    const mouseInfluence = reducedMotion ? 0 : 0.45;
    const mouseOffset = new THREE.Vector3(mouseX * mouseInfluence, mouseY * mouseInfluence * 0.35, 0);

    // Prompt: "Add it to POSITION ONLY, never to the look target: the camera then
    // rotates to hold the axis while it translates, which is what makes an offset read as an arc."
    this.camera.position.copy(spinePos).add(swingOffset).add(mouseOffset);

    // 3. Compute look target along the spine axis ahead of the camera
    if (sp <= 0.16) {
      // Act 1: Look directly at the figure's chest/face at (0, 9, 0)
      this.lookTarget.set(0, 9.0, 0);
    } else {
      // Corridor look target: projects ahead along spine without swing offset
      const lookAheadSp = Math.min(1.0, sp + 0.045);
      const aheadSpine = getCameraSpine(lookAheadSp);
      this.lookTarget.set(0, aheadSpine.y - 0.2, aheadSpine.z - 24.0);
    }

    // 4. View direction vector for Rodrigues banking
    const viewDir = new THREE.Vector3().subVectors(this.lookTarget, this.camera.position).normalize();

    // Guard near-vertical case
    const dotUp = Math.abs(viewDir.dot(this.baseUp));
    let referenceUp = this.baseUp;
    if (dotUp > 0.99) {
      referenceUp = new THREE.Vector3(0, 0, -1);
    }

    // Bank by rotating the UP VECTOR about the view axis (Rodrigues) on a sin envelope,
    // out to ~15deg (0.26 rad) mid-drop and BACK UPRIGHT by arrival.
    // Clamp to avoid extreme roll
    const clampedBank = Math.max(-0.28, Math.min(0.28, bankAngle));
    const rotatedUp = rodriguesRotate(referenceUp, viewDir, clampedBank);

    this.camera.up.copy(rotatedUp);
    this.camera.lookAt(this.lookTarget);

    // 5. Act 6 Closing Wipe on real p:
    // "Fog far closes for the wipe so the far end dissolves instead of showing an end wall."
    if (fog) {
      if (p > 0.82) {
        const wipeT = clamp01((p - 0.82) / 0.18);
        fog.near = 5.0 * (1.0 - wipeT) + 0.1;
        fog.far = 450.0 * (1.0 - wipeT * 0.94) + 18.0; // Dissolves down to 18 units!
      } else {
        fog.near = 50.0;
        fog.far = 520.0;
      }
    }
  }
}
