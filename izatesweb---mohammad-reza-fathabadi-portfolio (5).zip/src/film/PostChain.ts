import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { VignetteShader } from 'three/addons/shaders/VignetteShader.js';

// Display-Space Film Grain Shader (Sits AFTER OutputPass in display space)
const FilmGrainShader = {
  name: 'FilmGrainShader',
  uniforms: {
    tDiffuse: { value: null },
    time: { value: 0.0 },
    amount: { value: 0.045 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float time;
    uniform float amount;
    varying vec2 vUv;

    // High frequency procedural noise in display space
    float rand(vec2 co) {
      return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
    }

    void main() {
      vec4 color = texture2D(tDiffuse, vUv);
      float noise = (rand(vUv + fract(time)) - 0.5) * amount;
      color.rgb += noise;
      gl_FragColor = color;
    }
  `,
};

export class PostChain {
  public composer: EffectComposer;
  private bloomPass: UnrealBloomPass;
  private vignettePass: ShaderPass;
  private outputPass: OutputPass;
  private grainPass: ShaderPass;

  constructor(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera) {
    const width = window.innerWidth;
    const height = window.innerHeight;

    // Render target with half-float support
    const renderTarget = new THREE.WebGLRenderTarget(width, height, {
      type: THREE.HalfFloatType,
      format: THREE.RGBAFormat,
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      samples: 2,
    });

    this.composer = new EffectComposer(renderer, renderTarget);

    // 1. Render Scene Pass
    const renderPass = new RenderPass(scene, camera);
    this.composer.addPass(renderPass);

    // 2. Bloom Pass:
    // "Bloom strength 0.55, radius 0.45, threshold 1.15, and set highPassUniforms.smoothWidth to 0.35"
    this.bloomPass = new UnrealBloomPass(new THREE.Vector2(width, height), 0.55, 0.45, 1.15);
    if ((this.bloomPass as any).highPassUniforms && (this.bloomPass as any).highPassUniforms.smoothWidth) {
      (this.bloomPass as any).highPassUniforms.smoothWidth.value = 0.35;
    }
    this.composer.addPass(this.bloomPass);

    // 3. Vignette Pass:
    // "VIGNETTE: darkness 1.0 and NOT ABOVE. Shape falloff with offset (1.3) instead."
    this.vignettePass = new ShaderPass(VignetteShader);
    this.vignettePass.uniforms['darkness'].value = 1.0;
    this.vignettePass.uniforms['offset'].value = 1.3;
    this.composer.addPass(this.vignettePass);

    // 4. Tone Map (OutputPass): converts linear/ACES to sRGB
    this.outputPass = new OutputPass();
    this.composer.addPass(this.outputPass);

    // 5. Grain Pass:
    // "Grain sits AFTER the output pass, in display space, which is where film grain actually lands"
    this.grainPass = new ShaderPass(FilmGrainShader);
    this.composer.addPass(this.grainPass);
  }

  public setSize(width: number, height: number) {
    this.composer.setSize(width, height);
    this.bloomPass.setSize(width, height);
  }

  public render(time: number) {
    this.grainPass.uniforms['time'].value = time;
    this.composer.render();
  }
}
