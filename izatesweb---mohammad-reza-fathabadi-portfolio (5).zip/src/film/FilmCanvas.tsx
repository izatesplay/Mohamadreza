import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RAW_COLORS, clamp01 } from './types';
import { scrollState } from './scrollState';
import { updateActGates } from './ActManager';
import { LatticeCage } from './LatticeCage';
import { GridRoom } from './GridRoom';
import { WebCorridor } from './WebCorridor';
import { CameraRig } from './CameraRig';
import { PostChain } from './PostChain';
import { soundEngine } from './SoundEngine';

export const FilmCanvas: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Check prefers-reduced-motion
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    scrollState.reducedMotion = mediaQuery.matches;
    const handleMotionChange = (e: MediaQueryListEvent) => {
      scrollState.reducedMotion = e.matches;
    };
    mediaQuery.addEventListener('change', handleMotionChange);

    // Prompt: "Clamp DPR (1.0 on mobile, 1.5 desktop)"
    const isMobile = window.innerWidth < 768;
    const dpr = Math.min(window.devicePixelRatio || 1, isMobile ? 1.0 : 1.5);

    // 1. WebGL Renderer
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true,
    });
    renderer.setPixelRatio(dpr);
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;

    // 2. Scene with RED black (#150406) background and fog
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(RAW_COLORS.ink950);
    const fog = new THREE.Fog(RAW_COLORS.ink950, 50, 520);
    scene.fog = fog;

    // 3. Camera Rig
    const cameraRig = new CameraRig();
    cameraRig.camera.aspect = window.innerWidth / window.innerHeight;
    cameraRig.camera.updateProjectionMatrix();

    // 4. Scene Objects
    const latticeCage = new LatticeCage();
    scene.add(latticeCage.mesh);

    const gridRoom = new GridRoom();
    scene.add(gridRoom.group);

    const webCorridor = new WebCorridor(isMobile);
    scene.add(webCorridor.group);

    // 5. Post Processing Chain: bloom -> vignette -> output -> grain
    const postChain = new PostChain(renderer, scene, cameraRig.camera);

    // Track scroll target without triggering React re-renders
    const onScroll = () => {
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      const rawP = scrollHeight > 0 ? window.scrollY / scrollHeight : 0;
      scrollState.targetP = clamp01(rawP);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    // Initialize initial scroll position immediately
    onScroll();
    scrollState.p = scrollState.targetP;
    scrollState.sp = clamp01(scrollState.p / 0.82);
    updateActGates(scrollState.sp, scrollState.p);

    // Mouse movement tracking for cursor tilt
    const onMouseMove = (e: MouseEvent) => {
      scrollState.mouseX = (e.clientX / window.innerWidth) * 2 - 1;
      scrollState.mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
    };
    window.addEventListener('mousemove', onMouseMove, { passive: true });

    // Resize handling
    const onResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const currentMobile = w < 768;
      const currentDpr = Math.min(window.devicePixelRatio || 1, currentMobile ? 1.0 : 1.5);

      renderer.setPixelRatio(currentDpr);
      renderer.setSize(w, h);
      cameraRig.camera.aspect = w / h;
      cameraRig.camera.updateProjectionMatrix();

      postChain.setSize(w, h);
      webCorridor.setResolution(w, h);
    };
    window.addEventListener('resize', onResize);

    // Pure deterministic render loop with 60-120fps buttery momentum interpolation
    let animId: number;
    let clock = new THREE.Clock();

    const frameLoop = () => {
      const elapsedTime = clock.getElapsedTime();

      // Fluid exponential damping: converts discrete scroll notches into liquid motion with zero lag
      const lerpFactor = scrollState.reducedMotion ? 1.0 : 0.22;
      const delta = scrollState.targetP - scrollState.p;
      if (Math.abs(delta) < 0.00003) {
        scrollState.p = scrollState.targetP;
      } else {
        scrollState.p += delta * lerpFactor;
      }

      scrollState.velocity = scrollState.p - scrollState.lastP;
      scrollState.lastP = scrollState.p;
      scrollState.sp = clamp01(scrollState.p / 0.82);

      const p = scrollState.p;
      const sp = scrollState.sp;

      updateActGates(sp, p);

      const mouseX = scrollState.mouseX;
      const mouseY = scrollState.mouseY;
      const reducedMotion = scrollState.reducedMotion;

      // Update sound engine
      soundEngine.update(sp, scrollState.velocity);

      // Camera Rig update with smooth mouse parallax
      cameraRig.update(sp, p, reducedMotion, fog, mouseX, mouseY);

      // Lattice Cage update (ONE scalar weaves and unweaves it)
      latticeCage.update(sp);

      // Grid Room update (counter-rotating cobalt cylinders)
      gridRoom.update(sp);

      // Web Corridor update (FAT lines, catenary sagging & wave)
      webCorridor.update(sp, cameraRig.camera.position);

      // Post Chain render
      postChain.render(elapsedTime);

      animId = requestAnimationFrame(frameLoop);
    };

    animId = requestAnimationFrame(frameLoop);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', onResize);
      mediaQuery.removeEventListener('change', handleMotionChange);
      renderer.dispose();
    };
  }, []);

  return (
    <div ref={containerRef} className="fixed inset-0 w-full h-full pointer-events-none z-10">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
