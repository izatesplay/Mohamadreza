import { smoothstep, clamp01 } from './types';
import { scrollState } from './scrollState';

export function calculateActGates(sp: number, p: number): [number, number, number, number, number, number] {
  // Act 1: 0.00 -> 0.22 (peaks 0.00-0.10, ramp down 0.10-0.22)
  const g1 = 1.0 - smoothstep(0.10, 0.22, sp);

  // Act 2: 0.14 -> 0.42 (overlaps Act 1 by 0.08)
  const g2In = smoothstep(0.14, 0.22, sp);
  const g2Out = 1.0 - smoothstep(0.34, 0.42, sp);
  const g2 = g2In * g2Out;

  // Act 3: 0.34 -> 0.62 (overlaps Act 2 by 0.08)
  const g3In = smoothstep(0.34, 0.42, sp);
  const g3Out = 1.0 - smoothstep(0.54, 0.62, sp);
  const g3 = g3In * g3Out;

  // Act 4: 0.54 -> 0.80 (overlaps Act 3 by 0.08)
  const g4In = smoothstep(0.54, 0.62, sp);
  const g4Out = 1.0 - smoothstep(0.72, 0.80, sp);
  const g4 = g4In * g4Out;

  // Act 5: 0.72 -> 1.00 (overlaps Act 4 by 0.08)
  const g5In = smoothstep(0.72, 0.80, sp);
  // Act 5 fades as Act 6 takes over on real p
  const g5Out = 1.0 - smoothstep(0.82, 0.94, p);
  const g5 = g5In * g5Out;

  // Act 6: Closing wipe runs on real p (0.76 -> 1.00, overlaps Act 5 by 0.06 on real p)
  const g6 = smoothstep(0.76, 0.88, p);

  return [g1, g2, g3, g4, g5, g6];
}

export function updateActGates(sp: number, p: number) {
  const gates = calculateActGates(sp, p);
  scrollState.gates = gates;
  if (typeof window !== 'undefined') {
    (window as any).__BRAND_NEW_DAY_GATES__ = gates;
  }
  return gates;
}
