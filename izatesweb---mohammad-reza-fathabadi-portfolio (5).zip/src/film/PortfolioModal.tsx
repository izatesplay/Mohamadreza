import React from 'react';
import { X } from 'lucide-react';

interface PortfolioModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  maxWidth?: string;
  containerClassName?: string;
}

export const PortfolioModal: React.FC<PortfolioModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  maxWidth = 'max-w-5xl',
  containerClassName = '',
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-xl animate-fade-in overflow-y-auto">
      {/* Background click dismiss */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Modal Container */}
      <div className={`relative w-full ${maxWidth} bg-[#0d0f17] border border-[#D4AF37]/30 rounded-2xl shadow-[0_25px_70px_rgba(0,0,0,0.95)] overflow-hidden my-auto z-10 max-h-[96vh] sm:max-h-[92vh] flex flex-col ${containerClassName}`}>
        {/* Header */}
        <div className="flex items-center justify-between px-3.5 sm:px-6 py-3 sm:py-4 border-b border-[#1e2436] bg-[#08090E]/95 backdrop-blur-xl shrink-0">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0 pr-2">
            <div className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full bg-[#D4AF37] shadow-[0_0_10px_#D4AF37] shrink-0" />
            <h2 className="text-xs sm:text-base md:text-lg font-bold text-[#F8FAFC] tracking-wide font-['Vazirmatn'] truncate">
              <bdi>{title}</bdi>
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 rounded-full hover:bg-[#141824] text-[#94A3B8] hover:text-[#F3E5AB] transition-colors cursor-pointer shrink-0"
            aria-label="بستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 md:p-8 custom-scrollbar bg-[#0d0f17]">
          {children}
        </div>
      </div>
    </div>
  );
};
