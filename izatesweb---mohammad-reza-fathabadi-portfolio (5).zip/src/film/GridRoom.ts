import * as THREE from 'three';
import { RAW_COLORS } from './types';
import { scrollState } from './scrollState';

export class GridRoom {
  public group: THREE.Group;
  private shell1: THREE.LineSegments;
  private shell2: THREE.LineSegments;
  private shell3: THREE.LineSegments;
  private horizonBar: THREE.Mesh;
  private materials: THREE.LineBasicMaterial[] = [];

  constructor() {
    this.group = new THREE.Group();

    // Cylinders at r 9 / 13.95 / 19.8
    const radii = [9, 13.95, 19.8];
    const length = 1600; // Deep down -Z
    const radialSegments = 24;
    const heightSegments = 80;

    const shells: THREE.LineSegments[] = [];

    radii.forEach((radius) => {
      const geom = new THREE.CylinderGeometry(radius, radius, length, radialSegments, heightSegments, true);
      // rotateX(PI/2) so the cylinder axis runs down -Z
      geom.rotateX(Math.PI / 2);
      // Shift center so it extends down -Z from 0 to -length
      geom.translate(0, 0, -length * 0.45);

      const wireframeGeom = new THREE.WireframeGeometry(geom);
      const mat = new THREE.LineBasicMaterial({
        color: RAW_COLORS.cobalt500,
        transparent: true,
        opacity: 0.22,
        depthWrite: false,
      });

      this.materials.push(mat);
      const shell = new THREE.LineSegments(wireframeGeom, mat);
      shells.push(shell);
      this.group.add(shell);
    });

    this.shell1 = shells[0];
    this.shell2 = shells[1];
    this.shell3 = shells[2];

    // One thin horizon bar only — no finite ground plane (fog replaces floor)
    const horizonGeo = new THREE.PlaneGeometry(160, 0.12);
    const horizonMat = new THREE.MeshBasicMaterial({
      color: RAW_COLORS.cobalt500,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });
    this.horizonBar = new THREE.Mesh(horizonGeo, horizonMat);
    this.horizonBar.position.set(0, 0, -1100);
    this.group.add(this.horizonBar);
  }

  // Pure function update: rotation drift per shell
  // Drift 0.055 / -0.03 / 0.014 — the far shell COUNTER-rotates
  public update(sp: number) {
    const angleBase = sp * Math.PI * 4;
    this.shell1.rotation.z = angleBase * 0.055;
    this.shell2.rotation.z = angleBase * -0.03;
    this.shell3.rotation.z = angleBase * 0.014;

    // Visibility & opacity ramp across acts (Act 2 through 5)
    // Grid room emerges at sp > 0.12 and stays throughout the flight
    const entryFade = Math.min(1.0, Math.max(0, (sp - 0.10) / 0.08));
    const isWireframe = scrollState.wireframeMode;
    this.materials.forEach(mat => {
      if (isWireframe) {
        mat.color.setHex(RAW_COLORS.cyan500);
        mat.opacity = 0.65 * entryFade;
      } else {
        mat.color.setHex(RAW_COLORS.cobalt500);
        mat.opacity = 0.22 * entryFade;
      }
    });
    (this.horizonBar.material as THREE.MeshBasicMaterial).opacity = 0.45 * entryFade;
  }
}
