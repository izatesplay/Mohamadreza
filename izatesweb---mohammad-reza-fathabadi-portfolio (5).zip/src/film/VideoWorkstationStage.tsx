import React, { useEffect, useRef, useState } from 'react';
import { scrollState } from './scrollState';
import { clamp01 } from './types';

const TOTAL_FRAMES = 82;

function getFramePath(idx: number): string {
  const pad = String(idx).padStart(3, '0');
  return `/frames/frame_${pad}.jpg`;
}

export const VideoWorkstationStage: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imagesRef = useRef<(HTMLImageElement | null)[]>(new Array(TOTAL_FRAMES + 1).fill(null));
  const currentRenderedFrameRef = useRef<number>(-1);
  const [, setInitialFrameLoaded] = useState(false);

  // Progressive Preloading of Frames into Memory
  useEffect(() => {
    let isCancelled = false;
    const images = imagesRef.current;

    // 1. Immediately load Frame 1 for zero-delay instant display
    const firstImg = new Image();
    firstImg.src = getFramePath(1);
    firstImg.onload = () => {
      if (isCancelled) return;
      images[1] = firstImg;
      setInitialFrameLoaded(true);

      // Render first frame immediately
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          canvas.width = firstImg.naturalWidth || 1280;
          canvas.height = firstImg.naturalHeight || 720;
          ctx.drawImage(firstImg, 0, 0, canvas.width, canvas.height);
          currentRenderedFrameRef.current = 1;
        }
      }
    };

    // 2. Preload priority milestone frames (every 3rd frame)
    for (let i = 2; i <= TOTAL_FRAMES; i += 3) {
      const img = new Image();
      img.src = getFramePath(i);
      img.onload = () => {
        if (!isCancelled) images[i] = img;
      };
    }

    // 3. Preload remaining frames in idle chunks
    let cur = 2;
    const loadBatch = () => {
      if (isCancelled || cur > TOTAL_FRAMES) return;
      const end = Math.min(cur + 4, TOTAL_FRAMES);
      for (let i = cur; i <= end; i++) {
        if (!images[i]) {
          const img = new Image();
          img.src = getFramePath(i);
          img.onload = () => {
            if (!isCancelled) images[i] = img;
          };
        }
      }
      cur = end + 1;
      if (cur <= TOTAL_FRAMES) {
        if ('requestIdleCallback' in window) {
          (window as any).requestIdleCallback(loadBatch);
        } else {
          setTimeout(loadBatch, 16);
        }
      }
    };

    const timer = setTimeout(loadBatch, 80);

    return () => {
      isCancelled = true;
      clearTimeout(timer);
    };
  }, []);

  // Frame Scrubbing Animation Loop
  useEffect(() => {
    let animId: number;

    const render = () => {
      const sp = scrollState.sp;

      if (!containerRef.current || !canvasRef.current) {
        animId = requestAnimationFrame(render);
        return;
      }

      // Visible during Act 1 intro (sp = 0.0 to 0.20)
      if (sp > 0.20) {
        if (containerRef.current.style.visibility !== 'hidden') {
          containerRef.current.style.visibility = 'hidden';
          containerRef.current.style.opacity = '0';
        }
        animId = requestAnimationFrame(render);
        return;
      }

      if (containerRef.current.style.visibility !== 'visible') {
        containerRef.current.style.visibility = 'visible';
      }

      // Normalized progress u from 0 to 1 over sp 0.0 -> 0.17
      const u = clamp01(sp / 0.17);

      // Smooth cinematic fadeout into Act II web corridor (u > 0.82)
      let stageOpacity = 1.0;
      if (u > 0.82) {
        stageOpacity = Math.max(0, 1.0 - (u - 0.82) / 0.18);
      }
      containerRef.current.style.opacity = `${stageOpacity.toFixed(3)}`;

      // Calculate Target Frame Index (1 to TOTAL_FRAMES)
      const targetFrame = Math.min(TOTAL_FRAMES, Math.max(1, Math.round(1 + u * (TOTAL_FRAMES - 1))));

      // Find exact or closest available frame via fast O(1) neighboring search
      const images = imagesRef.current;
      let frameToDraw: HTMLImageElement | null = images[targetFrame];

      if (!frameToDraw) {
        // Fast local search within +/- 5 frames
        for (let d = 1; d <= 8; d++) {
          if (targetFrame - d >= 1 && images[targetFrame - d]) {
            frameToDraw = images[targetFrame - d];
            break;
          }
          if (targetFrame + d <= TOTAL_FRAMES && images[targetFrame + d]) {
            frameToDraw = images[targetFrame + d];
            break;
          }
        }
        if (!frameToDraw) frameToDraw = images[1];
      }

      if (frameToDraw && currentRenderedFrameRef.current !== targetFrame) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (ctx && frameToDraw.complete && frameToDraw.naturalWidth > 0) {
          if (canvas.width !== frameToDraw.naturalWidth) {
            canvas.width = frameToDraw.naturalWidth;
            canvas.height = frameToDraw.naturalHeight;
          }
          ctx.drawImage(frameToDraw, 0, 0, canvas.width, canvas.height);
          currentRenderedFrameRef.current = targetFrame;
        }
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-15 overflow-hidden flex items-center justify-center select-none bg-[#08090E]"
      style={{ willChange: 'opacity, transform' }}
    >
      {/* High-Resolution Frame Canvas */}
      <canvas
        ref={canvasRef}
        className="w-full h-full object-cover sm:object-contain drop-shadow-[0_0_80px_rgba(0,0,0,0.95)]"
      />

      {/* Luxury Obsidian Studio Vignette (Blends video seamlessly into dark theme) */}
      <div className="absolute inset-0 pointer-events-none bg-radial from-transparent via-[#08090E]/20 to-[#08090E]/80" />

      {/* Subtle Bottom Glow blending into 3D Space */}
      <div className="absolute bottom-0 left-0 right-0 h-28 bg-gradient-to-t from-[#08090E] via-[#08090E]/60 to-transparent pointer-events-none" />

      {/* Subtle Top Gradient for HUD readability */}
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-[#08090E]/90 via-[#08090E]/40 to-transparent pointer-events-none" />
    </div>
  );
};
