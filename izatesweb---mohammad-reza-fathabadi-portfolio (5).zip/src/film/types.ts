export interface StrandEntry {
  at: number;
  span: number;
  side: 1 | -1;
  lead: number;
  radius: number;
  lift: number;
}

export interface ScrollState {
  p: number; // Interpolated smooth scroll scalar 0 -> 1
  targetP: number; // Raw target scroll scalar 0 -> 1
  sp: number; // Act axis = clamp01(p / 0.82)
  velocity: number;
  lastP: number;
  reducedMotion: boolean;
  mouseX: number;
  mouseY: number;
  gates: [number, number, number, number, number, number];
  soundEnabled: boolean;
  wireframeMode: boolean;
}

// LUXURY COLOR PRIMITIVES: Obsidian Titanium, Champagne Gold & Cyber Cyan
export const RAW_COLORS = {
  ink950: 0x08090e, // Pure deep obsidian night canvas
  ink900: 0x0d0f17, // Deep titanium glass / card surface
  ink800: 0x141824, // Refined container borders
  ink700: 0x1e2436, // Muted geometric dividers
  bone50: 0xf8fafc,  // Crisp starlight platinum
  bone400: 0x94a3b8, // Refined silver slate
  bone500: 0x64748b, // Deep titanium caption
  // Luxury Champagne Gold & Radiant Light
  gold500: 0xd4af37, // Royal champagne gold
  gold300: 0xf3e5ab, // Radiant soft gold
  // Precision Ice Cyan & Electric Azure
  cyan500: 0x00f0ff, // Electric cyan
  cyan300: 0x38bdf8, // Soft crystal ice
  cobalt500: 0x38bdf8, // Refined cyber ice blue
  // Aliases for seamless backward compatibility
  scarlet500: 0xd4af37, // mapped to royal gold
  scarlet300: 0xf3e5ab, // mapped to radiant gold
};

export const RAW_HEX = {
  ink950: '#08090e',
  ink900: '#0d0f17',
  ink800: '#141824',
  ink700: '#1e2436',
  bone50: '#f8fafc',
  bone400: '#94a3b8',
  bone500: '#64748b',
  gold500: '#d4af37',
  gold300: '#f3e5ab',
  cyan500: '#00f0ff',
  cyan300: '#38bdf8',
  cobalt500: '#38bdf8',
  scarlet500: '#d4af37',
  scarlet300: '#f3e5ab',
};

// Math utilities
export function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

export function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = clamp01((x - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}
