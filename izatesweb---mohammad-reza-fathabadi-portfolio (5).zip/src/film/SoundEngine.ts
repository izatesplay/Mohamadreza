import { STRAND_TABLE } from './WebCorridor';
import { scrollState } from './scrollState';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private initialized = false;
  private lastFiredStrands = new Set<number>();

  public init() {
    if (this.initialized) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.001, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.filterNode = this.ctx.createBiquadFilter();
      this.filterNode.type = 'lowpass';
      this.filterNode.frequency.setValueAtTime(180, this.ctx.currentTime);
      this.filterNode.Q.setValueAtTime(1.5, this.ctx.currentTime);
      this.filterNode.connect(this.masterGain);

      // Deep cinematic ambient drone oscs
      this.droneOsc1 = this.ctx.createOscillator();
      this.droneOsc1.type = 'triangle'; // Warm cinematic sub
      this.droneOsc1.frequency.setValueAtTime(65.41, this.ctx.currentTime); // C2

      this.droneOsc2 = this.ctx.createOscillator();
      this.droneOsc2.type = 'sine'; // Pure fundamental
      this.droneOsc2.frequency.setValueAtTime(130.81, this.ctx.currentTime); // C3

      this.droneOsc1.connect(this.filterNode);
      this.droneOsc2.connect(this.filterNode);

      this.droneOsc1.start();
      this.droneOsc2.start();

      this.initialized = true;
    } catch (e) {
      console.warn('AudioContext not supported or blocked', e);
    }
  }

  public setEnabled(enabled: boolean) {
    scrollState.soundEnabled = enabled;
    if (enabled && !this.initialized) {
      this.init();
    }
    if (this.ctx && this.masterGain) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      const targetGain = enabled ? 0.22 : 0.0001;
      this.masterGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 0.2);
    }
  }

  // Update audio parameters based on scroll velocity and strand tension
  public update(sp: number, velocity: number) {
    if (!this.initialized || !this.ctx || !this.filterNode || !scrollState.soundEnabled) return;

    const absVel = Math.min(1.0, Math.abs(velocity) * 15.0);
    const targetFreq = 120 + absVel * 900 + sp * 350;
    this.filterNode.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.08);

    // Trigger subtle kinetic tension pluck when crossing a strand anchor
    STRAND_TABLE.forEach((strand, idx) => {
      if (Math.abs(sp - strand.at) < 0.008 && !this.lastFiredStrands.has(idx)) {
        this.lastFiredStrands.add(idx);
        this.playPluck(strand.side, idx);
      } else if (Math.abs(sp - strand.at) > 0.03) {
        this.lastFiredStrands.delete(idx);
      }
    });
  }

  private playPluck(side: number, index: number) {
    if (!this.ctx || !this.masterGain || !scrollState.soundEnabled) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    // Pentatonic frequencies
    const freqs = [220, 277.18, 329.63, 440, 554.37, 659.25];
    const freq = freqs[index % freqs.length];

    osc.type = side > 0 ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.45, this.ctx.currentTime + 0.35);

    gain.gain.setValueAtTime(0.28, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.38);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.4);
  }

  // Micro-interaction hover chime
  public playHover() {
    if (!this.initialized || !this.ctx || !this.masterGain || !scrollState.soundEnabled) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1200, this.ctx.currentTime + 0.06);
      gain.gain.setValueAtTime(0.04, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.07);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.08);
    } catch (e) {
      // safe fallback
    }
  }

  // Tactile click feedback
  public playClick() {
    if (!this.initialized || !this.ctx || !this.masterGain || !scrollState.soundEnabled) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(140, this.ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.09);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.1);
    } catch (e) {
      // safe fallback
    }
  }

  // High-speed warp swoosh when jumping between acts
  public playWarp() {
    if (!this.initialized || !this.ctx || !this.masterGain || !scrollState.soundEnabled) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(240, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(960, this.ctx.currentTime + 0.25);
      osc.frequency.exponentialRampToValueAtTime(320, this.ctx.currentTime + 0.5);
      gain.gain.setValueAtTime(0.001, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.18, this.ctx.currentTime + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.52);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.55);
    } catch (e) {
      // safe fallback
    }
  }
}

export const soundEngine = new SoundEngine();
