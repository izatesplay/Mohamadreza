import React, { useState, useEffect } from 'react';
import { scrollState } from './scrollState';
import { soundEngine } from './SoundEngine';
import { Volume2, VolumeX, Shield, Sparkles, FolderGit2, Mail, User, Wind, Bot, Boxes } from 'lucide-react';

interface FilmHUDProps {
  onOpenProjects: () => void;
  onOpenOrder: () => void;
  onOpenAbout: () => void;
  onOpenContact: () => void;
  onOpenAdmin: () => void;
  onOpenEmo?: () => void;
}

const ACT_NAMES = [
  { roman: 'I', name: 'THE ARCHITECT', fa: 'معمار وب', targetSp: 0.05 },
  { roman: 'II', name: 'IZATES STUDIO', fa: 'استودیو طراحی', targetSp: 0.25 },
  { roman: 'III', name: 'FULL-STACK', fa: 'توسعه فرانت‌اند', targetSp: 0.44 },
  { roman: 'IV', name: 'SPEED & SEO', fa: 'سرعت و سئو', targetSp: 0.65 },
  { roman: 'V', name: 'GROWTH', fa: 'رشد تجاری', targetSp: 0.82 },
  { roman: 'VI', name: 'LAUNCH', fa: 'همکاری و آغاز', targetSp: 0.98 },
];

export const FilmHUD: React.FC<FilmHUDProps> = ({
  onOpenProjects,
  onOpenOrder,
  onOpenAbout,
  onOpenContact,
  onOpenAdmin,
  onOpenEmo,
}) => {
  const [telemetry, setTelemetry] = useState({ p: 0, sp: 0, activeAct: 0, percent: 0 });
  const [soundOn, setSoundOn] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [wireframeOn, setWireframeOn] = useState(false);

  useEffect(() => {
    let animId: number;
    let lastAct = -1;
    let lastPercent = -1;

    const tick = () => {
      const p = scrollState.p;
      const sp = scrollState.sp;
      const percent = Math.round(p * 100);

      let activeAct = 0;
      if (sp < 0.16) activeAct = 0;
      else if (sp < 0.36) activeAct = 1;
      else if (sp < 0.54) activeAct = 2;
      else if (sp < 0.72) activeAct = 3;
      else if (sp < 0.88) activeAct = 4;
      else activeAct = 5;

      // Only trigger React state update when act or percentage changes
      if (activeAct !== lastAct || percent !== lastPercent) {
        lastAct = activeAct;
        lastPercent = percent;
        setTelemetry({ p, sp, activeAct, percent });
      }

      animId = requestAnimationFrame(tick);
    };

    animId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animId);
  }, []);

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    soundEngine.setEnabled(next);
    if (next) soundEngine.playClick();
  };

  const toggleReducedMotion = () => {
    soundEngine.playClick();
    const next = !reducedMotion;
    setReducedMotion(next);
    scrollState.reducedMotion = next;
  };

  const toggleWireframe = () => {
    soundEngine.playWarp();
    const next = !wireframeOn;
    setWireframeOn(next);
    scrollState.wireframeMode = next;
  };

  const jumpToAct = (targetSp: number) => {
    soundEngine.playWarp();
    const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
    const targetP = targetSp * 0.82;
    window.scrollTo({
      top: targetP * scrollHeight,
      behavior: 'smooth',
    });
  };

  return (
    <>
      {/* Top Floating Header */}
      <header className="fixed top-0 left-0 right-0 z-30 pointer-events-none p-2.5 sm:p-4 md:p-6 flex items-center justify-between gap-2">
        {/* Brand & Creator Identity - Explicit dir="ltr" for Latin typography */}
        <div className="pointer-events-auto flex items-center gap-2 sm:gap-3.5 bg-[#0d0f17]/90 backdrop-blur-xl border border-[#1e2436] px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-full shadow-[0_8px_30px_rgba(0,0,0,0.6)] shrink-0">
          <div className="relative flex items-center justify-center">
            <span className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full bg-[#D4AF37] animate-ping absolute" />
            <span className="w-1.5 sm:w-2 h-1.5 sm:h-2 rounded-full bg-[#D4AF37] shadow-[0_0_10px_#D4AF37]" />
          </div>
          <div dir="ltr" className="flex flex-col text-left font-['Plus_Jakarta_Sans']">
            <span className="text-[10px] sm:text-[11px] tracking-wider sm:tracking-widest text-[#F8FAFC] font-bold">MOHAMMAD REZA FATHABADI</span>
            <span dir="rtl" className="text-[8px] sm:text-[9px] tracking-wider text-[#D4AF37] font-medium font-['Vazirmatn'] hidden xs:inline">استودیو طراحی وب ایزاتس‌وب</span>
          </div>
        </div>

        {/* Acts Navigation & Telemetry Dock */}
        <div className="pointer-events-auto hidden md:flex items-center gap-1.5 bg-[#0d0f17]/90 backdrop-blur-xl border border-[#1e2436] p-1.5 rounded-full shadow-lg">
          {ACT_NAMES.map((item, idx) => {
            const isActive = telemetry.activeAct === idx;
            return (
              <button
                key={item.roman}
                onClick={() => jumpToAct(item.targetSp)}
                onMouseEnter={() => soundEngine.playHover()}
                className={`px-3 py-1.5 rounded-full text-xs font-mono transition-all duration-300 flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#E5C07B] text-[#08090E] shadow-[0_0_18px_rgba(212,175,55,0.4)] font-bold'
                    : 'text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#141824]'
                }`}
                title={`${item.name} (${item.fa})`}
              >
                <span dir="ltr">{item.roman}</span>
                {isActive && <span className="text-[10px] tracking-wider hidden lg:inline font-['Vazirmatn']">{item.fa}</span>}
              </button>
            );
          })}
        </div>

        {/* Telemetry & Quick Action Controls */}
        <div className="pointer-events-auto flex items-center gap-1 sm:gap-2 shrink-0">
          {/* Cyber Wireframe / Hologram X-Ray Mode Toggle */}
          <button
            onClick={toggleWireframe}
            className={`p-2 sm:p-2.5 rounded-full border transition-all duration-300 cursor-pointer ${
              wireframeOn
                ? 'bg-cyan-500/25 border-cyan-400 text-cyan-300 shadow-[0_0_20px_rgba(0,242,254,0.4)] ring-2 ring-cyan-400/30'
                : 'bg-[#0d0f17]/85 border-[#1e2436] text-[#64748b] hover:text-[#38BDF8]'
            }`}
            title={wireframeOn ? 'خروج از حالت اسکن وایر‌فریم مهندسی' : 'فعال‌سازی حالت اسکن سه‌بعدی وایر‌فریم (Cyber Matrix Mode)'}
          >
            <Boxes className={`w-3.5 sm:w-4 h-3.5 sm:h-4 ${wireframeOn ? 'animate-pulse text-cyan-300' : ''}`} />
          </button>

          {/* EMO AI Robot Trigger Button */}
          {onOpenEmo && (
            <button
              onClick={() => { soundEngine.playClick(); onOpenEmo(); }}
              onMouseEnter={() => soundEngine.playHover()}
              className="relative p-2 sm:p-2.5 rounded-full bg-gradient-to-r from-[#00f2fe]/20 to-[#4facfe]/20 hover:from-[#00f2fe]/30 hover:to-[#4facfe]/30 border border-cyan-500/40 text-cyan-300 hover:text-white transition-all duration-300 cursor-pointer shadow-[0_0_15px_rgba(0,242,254,0.25)] hover:shadow-[0_0_22px_rgba(0,242,254,0.45)] group"
              title="گفتگو با دستیار هوشمند و سخنگوی سایت (ربات ایمو - EMO)"
            >
              <Bot className="w-3.5 sm:w-4 h-3.5 sm:h-4 transition-transform group-hover:scale-110 group-hover:rotate-6 text-cyan-400" />
              <span className="absolute -top-1 -right-1 flex h-2 sm:h-2.5 w-2 sm:w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 sm:h-2.5 w-2 sm:w-2.5 bg-cyan-500"></span>
              </span>
            </button>
          )}

          {/* Sound Synthesizer Toggle */}
          <button
            onClick={toggleSound}
            className={`p-2 sm:p-2.5 rounded-full border transition-all duration-300 cursor-pointer ${
              soundOn
                ? 'bg-[#D4AF37]/20 border-[#D4AF37] text-[#F3E5AB] shadow-[0_0_15px_rgba(212,175,55,0.3)]'
                : 'bg-[#0d0f17]/85 border-[#1e2436] text-[#64748b] hover:text-[#F8FAFC]'
            }`}
            title={soundOn ? 'غیرفعال‌سازی صدای فضایی' : 'فعال‌سازی صدای فضایی سه بعدی (Web Audio)'}
          >
            {soundOn ? <Volume2 className="w-3.5 sm:w-4 h-3.5 sm:h-4" /> : <VolumeX className="w-3.5 sm:w-4 h-3.5 sm:h-4" />}
          </button>

          {/* Reduced Motion Toggle */}
          <button
            onClick={toggleReducedMotion}
            className={`p-2 sm:p-2.5 rounded-full border transition-all duration-300 cursor-pointer ${
              reducedMotion
                ? 'bg-[#38BDF8]/20 border-[#38BDF8] text-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.3)]'
                : 'bg-[#0d0f17]/85 border-[#1e2436] text-[#64748b] hover:text-[#F8FAFC]'
            }`}
            title={reducedMotion ? 'حرکت کامل دوربین فعال شود' : 'حالت کاهش حرکت (Reduced Motion)'}
          >
            <Wind className="w-3.5 sm:w-4 h-3.5 sm:h-4" />
          </button>

          {/* Admin Panel Toggle */}
          <button
            onClick={onOpenAdmin}
            className="p-2 sm:p-2.5 rounded-full bg-[#0d0f17]/85 hover:bg-[#141824] border border-[#1e2436] text-[#64748b] hover:text-[#D4AF37] transition-all duration-300 cursor-pointer shadow-md"
            title="پنل مدیریت پورتفولیو"
          >
            <Shield className="w-3.5 sm:w-4 h-3.5 sm:h-4" />
          </button>
        </div>
      </header>

      {/* Interactive Cinematic Flight Scrubber Track */}
      <div className="fixed bottom-14 sm:bottom-20 left-1/2 -translate-x-1/2 z-30 pointer-events-auto flex flex-col items-center select-none w-[90%] max-w-md">
        <div
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const clickRatio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
            window.scrollTo({
              top: clickRatio * scrollHeight,
              behavior: 'smooth',
            });
            soundEngine.playWarp();
          }}
          className="group relative w-full h-1.5 sm:h-2 bg-[#141824]/80 hover:h-2.5 rounded-full overflow-hidden cursor-pointer backdrop-blur-md border border-[#1e2436] transition-all duration-200 shadow-[0_0_15px_rgba(0,0,0,0.6)]"
          title="نشانگر پرواز فضایی: با کلیک روی هر نقطه، دوربین سریعاً در امتداد محور وب به آن پرده سفر می‌کند"
        >
          {/* Active Radiant Gold Beam */}
          <div
            className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-[#D4AF37] via-[#F3E5AB] to-[#38BDF8] shadow-[0_0_12px_#D4AF37]"
            style={{ width: `${Math.min(100, Math.max(0, telemetry.p * 100))}%` }}
          />
        </div>

        {/* Milestone Node Dots */}
        <div className="flex justify-between w-full px-1 mt-1 text-[8px] sm:text-[9px] font-mono text-[#64748b]">
          {ACT_NAMES.map((act, i) => (
            <button
              key={act.roman}
              onClick={() => jumpToAct(act.targetSp)}
              onMouseEnter={() => soundEngine.playHover()}
              className={`hover:text-[#F3E5AB] transition-colors cursor-pointer ${
                telemetry.activeAct === i ? 'text-[#D4AF37] font-bold scale-110' : ''
              }`}
            >
              {act.roman}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Floating Hub for Portfolio Modules */}
      <nav className="fixed bottom-2.5 sm:bottom-5 left-1/2 -translate-x-1/2 z-30 pointer-events-auto max-w-[calc(100vw-1rem)] px-1">
        <div className="flex items-center gap-1 sm:gap-2 p-1.5 sm:p-2 bg-[#0d0f17]/95 backdrop-blur-2xl border border-[#1e2436] rounded-full shadow-[0_12px_40px_rgba(0,0,0,0.8)] overflow-x-auto scrollbar-none max-w-full">
          <button
            onClick={() => { soundEngine.playClick(); onOpenProjects(); }}
            onMouseEnter={() => soundEngine.playHover()}
            className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-xs font-medium text-[#F8FAFC] hover:bg-[#141824] hover:text-[#F3E5AB] transition-all cursor-pointer shrink-0"
          >
            <FolderGit2 className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>پروژه‌ها</span>
          </button>

          <button
            onClick={() => { soundEngine.playClick(); onOpenOrder(); }}
            onMouseEnter={() => soundEngine.playHover()}
            className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-xs font-bold bg-gradient-to-r from-[#D4AF37] via-[#F3E5AB] to-[#C5A059] text-[#08090E] hover:brightness-110 shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all cursor-pointer shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#08090E]" />
            <span className="hidden sm:inline">سفارش طراحی سایت</span>
            <span className="sm:hidden">ثبت سفارش</span>
          </button>

          <button
            onClick={() => { soundEngine.playClick(); onOpenAbout(); }}
            onMouseEnter={() => soundEngine.playHover()}
            className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-xs font-medium text-[#F8FAFC] hover:bg-[#141824] hover:text-[#F3E5AB] transition-all cursor-pointer shrink-0"
          >
            <User className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>درباره من</span>
          </button>

          <button
            onClick={() => { soundEngine.playClick(); onOpenContact(); }}
            onMouseEnter={() => soundEngine.playHover()}
            className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-xs font-medium text-[#94A3B8] hover:bg-[#141824] hover:text-[#F8FAFC] transition-all cursor-pointer shrink-0"
          >
            <Mail className="w-3.5 h-3.5 text-[#94A3B8]" />
            <span className="hidden sm:inline">تماس و مشاوره</span>
            <span className="sm:hidden">تماس</span>
          </button>

          {onOpenEmo && (
            <button
              onClick={() => { soundEngine.playClick(); onOpenEmo(); }}
              onMouseEnter={() => soundEngine.playHover()}
              className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-xs font-semibold text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 hover:border-cyan-400/60 shadow-[0_0_15px_rgba(0,242,254,0.2)] transition-all cursor-pointer shrink-0"
              title="گفتگو با ربات هوشمند ایمو (EMO)"
            >
              <Bot className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span className="hidden sm:inline">ربات ایمو</span>
              <span className="sm:hidden">ایمو</span>
            </button>
          )}
        </div>
      </nav>
    </>
  );
};
