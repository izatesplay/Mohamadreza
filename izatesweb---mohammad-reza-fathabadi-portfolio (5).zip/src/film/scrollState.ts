import { ScrollState } from './types';

// The Plain Mutable Object read by every frame loop without triggering React renders
export const scrollState: ScrollState = {
  p: 0,
  targetP: 0,
  sp: 0,
  velocity: 0,
  lastP: 0,
  reducedMotion: false,
  mouseX: 0,
  mouseY: 0,
  gates: [1, 0, 0, 0, 0, 0],
  soundEnabled: false,
  wireframeMode: false,
};

// Expose on window for runtime verification and dev testing
if (typeof window !== 'undefined') {
  (window as any).__BRAND_NEW_DAY_SCROLL__ = scrollState;
  (window as any).__BRAND_NEW_DAY_GATES__ = scrollState.gates;
}
