import * as THREE from 'three';
import { clamp01 } from './types';

// Convert RGB (0-1) to HSL (0-1)
function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / d + 2) / 6;
        break;
      case b:
        h = ((r - g) / d + 4) / 6;
        break;
    }
  }
  return [h, s, l];
}

// Convert HSL (0-1) to RGB (0-1)
function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  if (s === 0) {
    return [l, l, l];
  }
  const hue2rgb = (p: number, q: number, t: number) => {
    let vt = t;
    if (vt < 0) vt += 1;
    if (vt > 1) vt -= 1;
    if (vt < 1 / 6) return p + (q - p) * 6 * vt;
    if (vt < 1 / 2) return q;
    if (vt < 2 / 3) return p + (q - p) * (2 / 3 - vt) * 6;
    return p;
  };
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  return [hue2rgb(p, q, h + 1 / 3), hue2rgb(p, q, h), hue2rgb(p, q, h - 1 / 3)];
}

// Shortest angle difference on [0, 1) circle
function shortestHueArc(current: number, target: number): number {
  let diff = target - current;
  while (diff < -0.5) diff += 1.0;
  while (diff > 0.5) diff -= 1.0;
  return diff;
}

// Procedural high-contrast masked portrait plate of the Web Architect & Developer (Mohammad Reza Fathabadi)
function generatePortraitImageData(width: number, height: number): ImageData {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, width, height);

  const cx = width * 0.5;
  const cy = height * 0.48;

  // 1. Floating Holographic Browser Window & Wireframe in background/midground
  // Top browser header
  const winW = width * 0.78;
  const winH = height * 0.42;
  const winX = cx - winW * 0.5;
  const winY = height * 0.12;

  // Window frame border
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)'; // soft cyan
  ctx.lineWidth = 2.0;
  ctx.strokeRect(winX, winY, winW, winH);

  // Top header bar
  ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
  ctx.fillRect(winX, winY, winW, 20);

  // 3 Browser Window Dots
  ctx.fillStyle = 'rgba(239, 68, 68, 0.9)'; // red
  ctx.beginPath(); ctx.arc(winX + 16, winY + 10, 4, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = 'rgba(234, 179, 8, 0.9)'; // yellow
  ctx.beginPath(); ctx.arc(winX + 30, winY + 10, 4, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = 'rgba(34, 197, 94, 0.9)'; // green
  ctx.beginPath(); ctx.arc(winX + 44, winY + 10, 4, 0, Math.PI * 2); ctx.fill();

  // Search/URL bar in holographic window
  ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
  ctx.fillRect(winX + 60, winY + 5, winW - 80, 10);

  // Wireframe UI grid cards inside window
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
  ctx.strokeRect(winX + 18, winY + 34, winW * 0.28, winH * 0.65);
  ctx.strokeRect(winX + winW * 0.35, winY + 34, winW * 0.60, winH * 0.30);
  ctx.strokeRect(winX + winW * 0.35, winY + winH * 0.46, winW * 0.60, winH * 0.45);

  // Code brackets floating: </ >
  ctx.font = 'bold 22px monospace';
  ctx.fillStyle = 'rgba(212, 175, 55, 0.95)'; // Luxury Champagne Gold accent
  ctx.fillText('</>', winX + winW * 0.78, winY + 70);
  ctx.fillStyle = 'rgba(56, 189, 248, 0.95)'; // Electric Cyan accent
  ctx.fillText('{ ; }', winX + winW * 0.12, winY + winH * 0.7);

  // 2. Creative Developer Figure: Head, Hair, Glasses, Face, Tech Headphones, Blazer
  const headY = height * 0.26;
  const headR = width * 0.11;

  // Neck
  const neckGrad = ctx.createLinearGradient(cx - headR * 0.5, headY, cx + headR * 0.5, headY + height * 0.15);
  neckGrad.addColorStop(0, 'rgba(217, 119, 6, 0.9)');
  neckGrad.addColorStop(0.5, 'rgba(251, 191, 36, 0.95)');
  neckGrad.addColorStop(1, 'rgba(180, 83, 9, 0.9)');
  ctx.fillStyle = neckGrad;
  ctx.beginPath();
  ctx.moveTo(cx - headR * 0.45, headY + headR * 0.8);
  ctx.lineTo(cx + headR * 0.45, headY + headR * 0.8);
  ctx.lineTo(cx + headR * 0.6, headY + headR * 2.0);
  ctx.lineTo(cx - headR * 0.6, headY + headR * 2.0);
  ctx.closePath();
  ctx.fill();

  // Head Silhouette (Realistic human facial shape)
  const faceGrad = ctx.createRadialGradient(cx - headR * 0.2, headY - headR * 0.2, headR * 0.1, cx, headY, headR * 1.2);
  faceGrad.addColorStop(0, 'rgba(254, 215, 170, 1)'); // Warm soft natural skin tone
  faceGrad.addColorStop(0.4, 'rgba(251, 191, 36, 0.95)');
  faceGrad.addColorStop(0.75, 'rgba(217, 119, 6, 0.9)');
  faceGrad.addColorStop(1, 'rgba(146, 64, 14, 0.85)');
  ctx.fillStyle = faceGrad;
  ctx.beginPath();
  ctx.ellipse(cx, headY + headR * 0.1, headR * 0.82, headR * 1.05, 0, 0, Math.PI * 2);
  ctx.fill();

  // Modern styled hair (dark espresso/charcoal with highlights)
  const hairGrad = ctx.createLinearGradient(cx, headY - headR * 1.3, cx, headY);
  hairGrad.addColorStop(0, 'rgba(30, 20, 18, 1)');
  hairGrad.addColorStop(0.7, 'rgba(45, 25, 20, 0.95)');
  hairGrad.addColorStop(1, 'rgba(20, 15, 15, 0.8)');
  ctx.fillStyle = hairGrad;
  ctx.beginPath();
  ctx.ellipse(cx, headY - headR * 0.35, headR * 0.88, headR * 0.75, 0, Math.PI, Math.PI * 2);
  ctx.fill();

  // Side hair volume & fade
  ctx.beginPath();
  ctx.moveTo(cx - headR * 0.86, headY + headR * 0.1);
  ctx.bezierCurveTo(cx - headR * 0.95, headY - headR * 0.8, cx + headR * 0.95, headY - headR * 0.8, cx + headR * 0.86, headY + headR * 0.1);
  ctx.bezierCurveTo(cx + headR * 0.75, headY - headR * 0.2, cx - headR * 0.75, headY - headR * 0.2, cx - headR * 0.86, headY + headR * 0.1);
  ctx.fill();

  // Modern Designer Glasses / Spectacles
  ctx.strokeStyle = 'rgba(241, 245, 249, 0.95)'; // Platinum frame
  ctx.lineWidth = 2.5;
  // Left lens
  ctx.beginPath();
  ctx.roundRect(cx - headR * 0.72, headY - headR * 0.15, headR * 0.58, headR * 0.42, 6);
  ctx.stroke();
  ctx.fillStyle = 'rgba(56, 189, 248, 0.3)'; // blue lens tint
  ctx.fill();
  // Right lens
  ctx.beginPath();
  ctx.roundRect(cx + headR * 0.14, headY - headR * 0.15, headR * 0.58, headR * 0.42, 6);
  ctx.stroke();
  ctx.fillStyle = 'rgba(56, 189, 248, 0.3)';
  ctx.fill();
  // Glasses bridge
  ctx.beginPath();
  ctx.moveTo(cx - headR * 0.14, headY + headR * 0.02);
  ctx.lineTo(cx + headR * 0.14, headY + headR * 0.02);
  ctx.stroke();

  // Tech Headphones around neck
  ctx.fillStyle = 'rgba(30, 41, 59, 0.98)'; // dark matte earcups
  // Left earcup
  ctx.beginPath();
  ctx.ellipse(cx - headR * 0.88, headY + headR * 1.35, headR * 0.26, headR * 0.42, -0.3, 0, Math.PI * 2);
  ctx.fill();
  // Right earcup
  ctx.beginPath();
  ctx.ellipse(cx + headR * 0.88, headY + headR * 1.35, headR * 0.26, headR * 0.42, 0.3, 0, Math.PI * 2);
  ctx.fill();
  // Headphone band with champagne gold accent line
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.95)';
  ctx.lineWidth = 3.0;
  ctx.beginPath();
  ctx.arc(cx, headY + headR * 0.9, headR * 1.05, 0.4, Math.PI - 0.4);
  ctx.stroke();

  // 3. Torso: Modern Tailored Techwear Jacket / Dark Blazer over creative tee
  const torsoGrad = ctx.createLinearGradient(cx, headY + headR * 1.8, cx, height * 0.92);
  torsoGrad.addColorStop(0, 'rgba(20, 24, 36, 0.98)'); // slate-900 obsidian
  torsoGrad.addColorStop(0.35, 'rgba(13, 15, 23, 0.95)'); 
  torsoGrad.addColorStop(0.7, 'rgba(10, 12, 18, 0.92)'); 
  torsoGrad.addColorStop(1, 'rgba(7, 8, 12, 0.88)');
  ctx.fillStyle = torsoGrad;

  // Shoulders & Chest
  ctx.beginPath();
  ctx.moveTo(cx - width * 0.42, height * 0.90);
  ctx.bezierCurveTo(cx - width * 0.40, height * 0.52, cx - width * 0.28, headY + headR * 1.8, cx - headR * 0.65, headY + headR * 1.9);
  ctx.lineTo(cx + headR * 0.65, headY + headR * 1.9);
  ctx.bezierCurveTo(cx + width * 0.28, headY + headR * 1.8, cx + width * 0.40, height * 0.52, cx + width * 0.42, height * 0.90);
  ctx.bezierCurveTo(cx + width * 0.2, height * 0.95, cx - width * 0.2, height * 0.95, cx - width * 0.42, height * 0.90);
  ctx.closePath();
  ctx.fill();

  // Blazer Lapels & Pure Gold Edge Piping
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.85)';
  ctx.lineWidth = 2.5;
  // Left lapel
  ctx.beginPath();
  ctx.moveTo(cx - headR * 0.55, headY + headR * 1.9);
  ctx.lineTo(cx - width * 0.08, height * 0.65);
  ctx.stroke();
  // Right lapel
  ctx.beginPath();
  ctx.moveTo(cx + headR * 0.55, headY + headR * 1.9);
  ctx.lineTo(cx + width * 0.08, height * 0.65);
  ctx.stroke();

  // Subtle developer badge on chest (IzatesWeb glyph in radiant gold)
  ctx.fillStyle = 'rgba(243, 229, 171, 0.98)';
  ctx.beginPath();
  ctx.arc(cx - width * 0.16, height * 0.56, 5, 0, Math.PI * 2);
  ctx.fill();

  // 4. Glowing Holographic Laptop / Workstation in Front of Architect
  const lapW = width * 0.46;
  const lapH = height * 0.18;
  const lapX = cx - lapW * 0.5;
  const lapY = height * 0.74;

  // Laptop display back glow
  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)'; // electric cyan edge
  ctx.lineWidth = 2.0;
  ctx.beginPath();
  ctx.roundRect(lapX, lapY, lapW, lapH, 6);
  ctx.fill();
  ctx.stroke();

  // Screen interior glowing with code lines
  ctx.fillStyle = 'rgba(6, 182, 212, 0.15)';
  ctx.fillRect(lapX + 8, lapY + 8, lapW - 16, lapH - 16);

  // Glowing code lines on screen
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.85)';
  ctx.lineWidth = 2.0;
  for (let r = 0; r < 4; r++) {
    const ly = lapY + 16 + r * 14;
    ctx.beginPath();
    ctx.moveTo(lapX + 16, ly);
    ctx.lineTo(lapX + 30 + (r % 3) * 35, ly);
    ctx.stroke();
  }

  // Hands on keyboard / hovering
  const handGrad = ctx.createRadialGradient(cx - lapW * 0.3, lapY + lapH * 0.8, 5, cx - lapW * 0.3, lapY + lapH * 0.8, 25);
  handGrad.addColorStop(0, 'rgba(254, 215, 170, 0.95)');
  handGrad.addColorStop(1, 'rgba(217, 119, 6, 0.8)');
  ctx.fillStyle = handGrad;
  // Left hand
  ctx.beginPath(); ctx.ellipse(cx - lapW * 0.32, lapY + lapH * 0.75, width * 0.05, height * 0.03, -0.2, 0, Math.PI * 2); ctx.fill();
  // Right hand
  ctx.beginPath(); ctx.ellipse(cx + lapW * 0.32, lapY + lapH * 0.75, width * 0.05, height * 0.03, 0.2, 0, Math.PI * 2); ctx.fill();

  return ctx.getImageData(0, 0, width, height);
}

export class FigureCloud {
  public group: THREE.Group;
  public instancedMesh: THREE.InstancedMesh;
  public totalBeads = 40000;
  private dummy = new THREE.Object3D();
  private basePositions: Float32Array;

  constructor() {
    this.group = new THREE.Group();
    // Centred at (0, 9, 0), 14 world units tall
    this.group.position.set(0, 9, 0);

    const imgWidth = 256;
    const imgHeight = 256;
    const imgData = generatePortraitImageData(imgWidth, imgHeight);
    const data = imgData.data;

    // Collect candidate alpha pixels
    const candidates: { x: number; y: number; r: number; g: number; b: number; a: number }[] = [];
    for (let py = 0; py < imgHeight; py++) {
      for (let px = 0; px < imgWidth; px++) {
        const idx = (py * imgWidth + px) * 4;
        const a = data[idx + 3];
        if (a > 32) {
          candidates.push({
            x: (px / imgWidth - 0.5) * 7.0, // width ~ 7 units
            y: (1.0 - py / imgHeight - 0.5) * 14.0, // height = 14 units, centered at 0 local
            r: data[idx] / 255,
            g: data[idx + 1] / 255,
            b: data[idx + 2] / 255,
            a: a / 255,
          });
        }
      }
    }

    // Instanced spheres (r 0.042, 8x6 segments)
    const sphereGeo = new THREE.SphereGeometry(0.042, 8, 6);
    const sphereMat = new THREE.MeshBasicMaterial({
      transparent: true,
      opacity: 0.92,
      depthWrite: true,
    });

    this.instancedMesh = new THREE.InstancedMesh(sphereGeo, sphereMat, this.totalBeads);
    this.basePositions = new Float32Array(this.totalBeads * 3);

    const lightDir = new THREE.Vector3(0.5, 0.8, 0.4).normalize();
    const formNormal = new THREE.Vector3();
    const beadColor = new THREE.Color();

    const candidateCount = candidates.length;
    for (let i = 0; i < this.totalBeads; i++) {
      // Stratified pseudorandom sampling over candidates
      const candIdx = Math.floor((i / this.totalBeads) * candidateCount);
      const cand = candidates[candIdx] || candidates[0];

      // Depth offset: cylindrical envelope with jitter
      const xNorm = Math.abs(cand.x) / 3.5;
      const depthEnvelope = Math.sqrt(Math.max(0, 1 - xNorm * xNorm)) * 1.8;
      const zJitter = (Math.random() - 0.5) * 0.45;
      const z = (Math.random() > 0.5 ? 1 : -0.3) * depthEnvelope * 0.85 + zJitter;
      const x = cand.x + (Math.random() - 0.5) * 0.12;
      const y = cand.y + (Math.random() - 0.5) * 0.12;

      this.basePositions[i * 3 + 0] = x;
      this.basePositions[i * 3 + 1] = y;
      this.basePositions[i * 3 + 2] = z;

      this.dummy.position.set(x, y, z);
      this.dummy.scale.setScalar(0.75 + Math.random() * 0.5);
      this.dummy.updateMatrix();
      this.instancedMesh.setMatrixAt(i, this.dummy.matrix);

      // Prompt: "The form normal is the bead's offset from the FIGURE'S OWN axis (n.set(x, y*0.15, z).normalize()),
      // never from the world origin — subtract the centre from itself and you get a degenerate radial and the whole cloud shades flat."
      formNormal.set(x, y * 0.15, z).normalize();
      const diffuse = Math.max(0.18, formNormal.dot(lightDir));

      // Intelligent color grading for Web Architect:
      // Preserves realistic warm skin tones, crisp holographic cyans, and deep obsidian techwear
      const [h, s, l] = rgbToHsl(cand.r, cand.g, cand.b);
      let finalR = cand.r;
      let finalG = cand.g;
      let finalB = cand.b;

      // If it's a holographic cyan/blue or code element (h ~ 0.5 - 0.7)
      if (h >= 0.48 && h <= 0.68) {
        // Boost cyan/cobalt vibrance for holographic UI
        const [rh, gh, bh] = hslToRgb(h, Math.min(1.0, s * 1.3 + 0.2), Math.min(0.95, l * 1.1));
        finalR = rh;
        finalG = gh;
        finalB = bh;
      } else if (h >= 0.04 && h <= 0.16 && l > 0.35) {
        // Warm natural skin tone: keep rich, radiant, and warm (not red spandex!)
        const [rh, gh, bh] = hslToRgb(h, Math.min(0.65, s * 0.95), Math.min(0.9, l));
        finalR = rh;
        finalG = gh;
        finalB = bh;
      } else if (s > 0.25 && (h > 0.88 || h < 0.18)) {
        // Luxury Champagne Gold accent
        const [rh, gh, bh] = hslToRgb(0.12, 0.88, Math.min(0.9, l * 1.15));
        finalR = rh;
        finalG = gh;
        finalB = bh;
      }

      // Bake shading once into instanceColor with subtle rim light
      const rimLight = Math.pow(1.0 - Math.abs(formNormal.z), 2.0) * 0.25;
      const shade = (diffuse + rimLight) * (0.85 + l * 0.35);
      beadColor.setRGB(
        Math.min(1.0, finalR * shade),
        Math.min(1.0, finalG * shade),
        Math.min(1.0, finalB * shade)
      );

      this.instancedMesh.setColorAt(i, beadColor);
    }

    if (this.instancedMesh.instanceColor) {
      this.instancedMesh.instanceColor.needsUpdate = true;
    }
    this.instancedMesh.instanceMatrix.needsUpdate = true;

    this.group.add(this.instancedMesh);
  }

  // Pure function update: idle float + cursor tilt, compensating pivot at (0, 9, 0)
  public update(sp: number, mouseX: number, mouseY: number, reducedMotion: boolean) {
    // Whole-figure float
    const floatAmplitude = reducedMotion ? 0.0 : 0.28;
    const floatY = Math.sin(sp * Math.PI * 4.0) * floatAmplitude * (1.0 - sp * 1.5);

    // Cursor tilt with pivot compensation
    const tiltX = reducedMotion ? 0.0 : -mouseY * 0.12;
    const tiltY = reducedMotion ? 0.0 : mouseX * 0.16;

    // Compensating translation keeping pivot at (0, 9, 0)
    this.group.position.set(0, 9 + floatY, 0);
    this.group.rotation.set(tiltX, tiltY, 0);

    // Fade cloud as act 1 yields to act 2 (around sp 0.18 -> 0.32)
    const actFade = 1.0 - clamp01((sp - 0.16) / 0.16);
    (this.instancedMesh.material as THREE.MeshBasicMaterial).opacity = 0.92 * actFade;
    this.instancedMesh.visible = actFade > 0.005;
  }
}
