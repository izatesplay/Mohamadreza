import React, { useEffect, useRef } from 'react';
import { scrollState } from './scrollState';
import { clamp01 } from './types';

export const WorkstationStage: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const zoomStageRef = useRef<HTMLDivElement>(null);
  const screenPortalRef = useRef<HTMLDivElement>(null);
  const developerBodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let animId: number;

    const updateStage = () => {
      const sp = scrollState.sp;

      if (!containerRef.current || !zoomStageRef.current) {
        animId = requestAnimationFrame(updateStage);
        return;
      }

      // Workstation is active from sp = 0.0 to sp = 0.18
      if (sp > 0.18) {
        containerRef.current.style.visibility = 'hidden';
        containerRef.current.style.opacity = '0';
        animId = requestAnimationFrame(updateStage);
        return;
      }

      containerRef.current.style.visibility = 'visible';

      // Normalized zoom progress u from 0 to 1 over sp 0.0 -> 0.15
      const u = clamp01(sp / 0.14);

      // Smooth cubic bezier easing for camera push-in
      const easeZoom = Math.pow(u, 2.4);

      // Scale up by up to 7.8x into the laptop screen
      const scale = 1.0 + easeZoom * 7.5;

      // Overall container opacity fades out at the very end of the dive (u > 0.85)
      let stageOpacity = 1.0;
      if (u > 0.82) {
        stageOpacity = 1.0 - (u - 0.82) / 0.18;
      }
      containerRef.current.style.opacity = `${stageOpacity.toFixed(3)}`;

      // Zoom stage transform centered on the laptop screen (50% X, 58% Y)
      zoomStageRef.current.style.transform = `scale(${scale.toFixed(4)})`;

      // Developer body dolly parallax: moves downwards and fades out so camera pushes past shoulders
      if (developerBodyRef.current) {
        const bodyDriftY = easeZoom * 160;
        const bodyOpacity = clamp01(1.0 - Math.pow(u, 1.4) * 1.1);
        developerBodyRef.current.style.transform = `translate3d(0, ${bodyDriftY.toFixed(1)}px, 0)`;
        developerBodyRef.current.style.opacity = `${bodyOpacity.toFixed(3)}`;
      }

      // Screen glow portal effect as camera gets very close (u > 0.65)
      if (screenPortalRef.current) {
        const portalGlow = u > 0.55 ? (u - 0.55) / 0.45 : 0;
        screenPortalRef.current.style.opacity = `${(portalGlow * 0.85).toFixed(3)}`;
      }

      animId = requestAnimationFrame(updateStage);
    };

    animId = requestAnimationFrame(updateStage);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-15 overflow-hidden flex items-center justify-center select-none"
      style={{ willChange: 'opacity, transform' }}
    >
      {/* Zoom container with transform origin precisely aligned with laptop screen */}
      <div
        ref={zoomStageRef}
        className="relative w-full h-full max-w-[1920px] max-h-[1080px] flex items-center justify-center origin-[50%_57%] will-change-transform"
      >
        {/* Background Atmosphere: Luxury Dark Studio with Subtle Rim Light */}
        <div className="absolute inset-0 bg-radial from-[#141824]/90 via-[#0a0c13]/95 to-[#08090e] pointer-events-none" />

        {/* Ambient Screen Light Bloom on the environment */}
        <div className="absolute top-[48%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[750px] h-[550px] bg-gradient-to-b from-[#38bdf8]/15 via-[#d4af37]/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        {/* Minimalist Studio Desk */}
        <div className="absolute bottom-0 left-0 right-0 h-[38%] bg-gradient-to-t from-[#06070a] via-[#0d0f17] to-[#141824]/40 border-t border-[#1e2436]/60 backdrop-blur-sm">
          {/* Subtle reflection on desk surface */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[520px] h-32 bg-gradient-to-b from-[#38bdf8]/10 via-[#d4af37]/5 to-transparent blur-xl" />
        </div>

        {/* =========================================================================
            THE LAPTOP & CRISP VISUAL STUDIO CODE WORKSTATION (The Centerpiece)
           ========================================================================= */}
        <div className="relative z-10 w-[720px] max-w-[92vw] flex flex-col items-center top-[-1%]">
          {/* Laptop Display Lid Frame */}
          <div className="relative w-full rounded-t-2xl p-[7px] pb-0 bg-gradient-to-b from-[#2a3042] via-[#1a1d29] to-[#0f1118] shadow-[0_15px_60px_rgba(0,0,0,0.95)] border border-[#374151]/50">
            {/* Top Bezel Webcam */}
            <div className="absolute top-[3px] left-1/2 -translate-x-1/2 flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-[#0a0d14] border border-[#334155]/60 flex items-center justify-center">
                <div className="w-0.5 h-0.5 rounded-full bg-[#38bdf8]/80 animate-pulse" />
              </div>
            </div>

            {/* THE VISUAL STUDIO CODE SCREEN (Ultra-Crisp Vector & DOM Rendering) */}
            <div className="relative w-full h-[410px] bg-[#0c0e14] rounded-t-xl overflow-hidden border border-[#1e2436] flex flex-col shadow-inner font-mono text-left">
              {/* VS Code Title Bar */}
              <div className="h-8 bg-[#08090e] border-b border-[#1e2436] px-3 flex items-center justify-between text-xs text-[#94a3b8] select-none">
                {/* macOS Window Controls */}
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#ef4444]/90 shadow-[0_0_6px_rgba(239,68,68,0.5)]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]/90 shadow-[0_0_6px_rgba(245,158,11,0.5)]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-[#10b981]/90 shadow-[0_0_6px_rgba(16,185,129,0.5)]" />
                </div>

                {/* Workspace Title */}
                <div className="text-[11px] font-medium tracking-wide text-[#cbd5e1] flex items-center gap-2">
                  <span className="text-[#38bdf8]">izatesweb</span>
                  <span className="text-white/20">—</span>
                  <span className="text-[#f3e5ab]">Mohammad Reza Fathabadi (Creative Architect)</span>
                </div>

                {/* Layout controls */}
                <div className="flex items-center gap-2 text-[10px] text-[#64748b]">
                  <span className="px-1.5 py-0.5 rounded bg-[#141824] border border-[#1e2436]">v2026.4</span>
                </div>
              </div>

              {/* VS Code Editor Main Body: Sidebar + Active Code Canvas */}
              <div className="flex-1 flex overflow-hidden">
                {/* Left Activity Bar */}
                <div className="w-11 bg-[#08090e] border-r border-[#1e2436] flex flex-col items-center py-3 gap-4 text-[#64748b]">
                  <div className="text-[#38bdf8] p-1 rounded bg-[#141824]/80 border border-[#38bdf8]/30">
                    {/* Explorer Icon */}
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                    </svg>
                  </div>
                  <div className="hover:text-[#cbd5e1] cursor-pointer">
                    {/* Search Icon */}
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
                    </svg>
                  </div>
                  <div className="hover:text-[#cbd5e1] cursor-pointer relative">
                    {/* Git Icon */}
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="18" cy="18" r="3" /><circle cx="6" cy="6" r="3" /><path d="M18 9a9 9 0 0 1-9 9" />
                    </svg>
                    <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#d4af37]" />
                  </div>
                  <div className="hover:text-[#cbd5e1] cursor-pointer">
                    {/* Debug Icon */}
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="m8 2 1.88 1.88M14.12 3.88 16 2M9 7.13v4.87a3 3 0 0 0 6 0V7.13" /><rect width="8" height="14" x="8" y="5" rx="4" />
                    </svg>
                  </div>
                </div>

                {/* Left File Explorer Panel */}
                <div className="w-44 bg-[#0a0c13] border-r border-[#1e2436] p-2 text-[10px] text-[#94a3b8] flex flex-col gap-1 hidden sm:flex">
                  <div className="text-[9px] font-bold tracking-wider uppercase text-[#64748b] px-1 py-1">EXPLORER</div>
                  <div className="flex items-center gap-1.5 px-1 py-0.5 rounded bg-[#141824] text-[#f8fafc] font-semibold border-l-2 border-[#d4af37]">
                    <span className="text-[#38bdf8]">TSX</span>
                    <span>App.tsx</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-1 py-0.5 hover:text-[#f8fafc]">
                    <span className="text-[#38bdf8]">TS</span>
                    <span>CameraRig.ts</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-1 py-0.5 hover:text-[#f8fafc]">
                    <span className="text-[#38bdf8]">TS</span>
                    <span>WebCorridor.ts</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-1 py-0.5 hover:text-[#f8fafc]">
                    <span className="text-[#eab308]">JSON</span>
                    <span>izates.config.json</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-1 py-0.5 hover:text-[#f8fafc]">
                    <span className="text-[#10b981]">CSS</span>
                    <span>index.css</span>
                  </div>
                </div>

                {/* Center Code Editor Area */}
                <div className="flex-1 flex flex-col bg-[#0c0e14] overflow-hidden">
                  {/* File Tabs */}
                  <div className="h-7 bg-[#08090e] border-b border-[#1e2436] flex items-center px-1 text-[11px]">
                    <div className="flex items-center gap-2 px-3 py-1 bg-[#0c0e14] text-[#f8fafc] border-t-2 border-[#d4af37] border-r border-[#1e2436]">
                      <span className="text-[#38bdf8] font-bold">⚛</span>
                      <span>App.tsx</span>
                      <span className="text-[#64748b] hover:text-white cursor-pointer ml-1">×</span>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-1 text-[#64748b] hover:text-[#cbd5e1] border-r border-[#1e2436]">
                      <span>CameraRig.ts</span>
                    </div>
                  </div>

                  {/* Active Code Lines (Vibrant Syntax Highlighting) */}
                  <div className="flex-1 p-3 text-[11px] leading-[1.65] overflow-hidden flex gap-3">
                    {/* Line Numbers */}
                    <div className="text-[#475569] select-none text-right flex flex-col pr-2 border-r border-[#1e2436]/60">
                      <span>01</span><span>02</span><span>03</span><span>04</span><span>05</span>
                      <span>06</span><span>07</span><span>08</span><span>09</span><span>10</span>
                      <span>11</span><span>12</span><span>13</span><span>14</span><span>15</span>
                      <span>16</span>
                    </div>

                    {/* Code Syntax */}
                    <div className="flex-1 flex flex-col text-left">
                      <div>
                        <span className="text-[#c084fc]">import</span> <span className="text-[#f8fafc]">{'{'}</span> <span className="text-[#38bdf8]">CreativeDeveloper</span><span className="text-[#f8fafc]">,</span> <span className="text-[#38bdf8]">WebGLMatrix</span> <span className="text-[#f8fafc]">{'}'}</span> <span className="text-[#c084fc]">from</span> <span className="text-[#f3e5ab]">'@izatesweb/core'</span><span className="text-[#f8fafc]">;</span>
                      </div>
                      <div>
                        <span className="text-[#c084fc]">import</span> <span className="text-[#f8fafc]">{'{'}</span> <span className="text-[#38bdf8]">MohammadRezaFathabadi</span> <span className="text-[#f8fafc]">{'}'}</span> <span className="text-[#c084fc]">from</span> <span className="text-[#f3e5ab]">'./architect'</span><span className="text-[#f8fafc]">;</span>
                      </div>
                      <div className="h-2" />
                      <div>
                        <span className="text-[#64748b] italic">// IzatesWeb: High-Performance 3D Scroll Masterpiece</span>
                      </div>
                      <div>
                        <span className="text-[#c084fc]">export const</span> <span className="text-[#d4af37] font-bold">BuildDigitalMasterpiece</span> <span className="text-[#f8fafc]">= () =&gt; {'{'}</span>
                      </div>
                      <div className="pl-4">
                        <span className="text-[#c084fc]">const</span> <span className="text-[#38bdf8]">architect</span> <span className="text-[#f8fafc]">=</span> <span className="text-[#f3e5ab]">"محمد رضا فتح آبادی"</span><span className="text-[#f8fafc]">;</span>
                      </div>
                      <div className="pl-4">
                        <span className="text-[#c084fc]">const</span> <span className="text-[#38bdf8]">vision</span> <span className="text-[#f8fafc]">=</span> <span className="text-[#f3e5ab]">"Next-Gen 3D Interactive Web Experiences"</span><span className="text-[#f8fafc]">;</span>
                      </div>
                      <div className="pl-4">
                        <span className="text-[#c084fc]">const</span> <span className="text-[#38bdf8]">speedScore</span> <span className="text-[#f8fafc]">=</span> <span className="text-[#f97316]">100</span><span className="text-[#f8fafc]">;</span>
                      </div>
                      <div className="h-1" />
                      <div className="pl-4">
                        <span className="text-[#c084fc]">return</span> <span className="text-[#f8fafc]">(</span>
                      </div>
                      <div className="pl-8">
                        <span className="text-[#38bdf8]">&lt;</span><span className="text-[#ef4444]">DigitalCorridor</span> <span className="text-[#d4af37]">architect</span><span className="text-[#f8fafc]">=</span><span className="text-[#38bdf8]">{'{architect}'}</span> <span className="text-[#d4af37]">fps</span><span className="text-[#f8fafc]">=</span><span className="text-[#f97316]">60</span>
                      </div>
                      <div className="pl-12">
                        <span className="text-[#d4af37]">theme</span><span className="text-[#f8fafc]">=</span><span className="text-[#f3e5ab]">"Obsidian & Champagne Gold"</span>
                      </div>
                      <div className="pl-12">
                        <span className="text-[#d4af37]">status</span><span className="text-[#f8fafc]">=</span><span className="text-[#f3e5ab]">"ACTIVE_LAUNCH"</span>
                      </div>
                      <div className="pl-8">
                        <span className="text-[#38bdf8]">&gt;</span>
                      </div>
                      <div className="pl-12 flex items-center">
                        <span className="text-[#38bdf8]">&lt;</span><span className="text-[#ef4444]">WormholePortal</span> <span className="text-[#d4af37]">dive</span><span className="text-[#f8fafc]">=</span><span className="text-[#c084fc]">true</span> <span className="text-[#38bdf8]">/&gt;</span>
                        {/* Glowing Active Cursor */}
                        <span className="w-2 h-4 bg-[#d4af37] animate-pulse ml-1 inline-block shadow-[0_0_10px_#d4af37]" />
                      </div>
                      <div className="pl-8">
                        <span className="text-[#38bdf8]">&lt;/</span><span className="text-[#ef4444]">DigitalCorridor</span><span className="text-[#38bdf8]">&gt;</span>
                      </div>
                      <div className="pl-4">
                        <span className="text-[#f8fafc]">);</span>
                      </div>
                      <div>
                        <span className="text-[#f8fafc]">{'}'};</span>
                      </div>
                    </div>
                  </div>

                  {/* VS Code Bottom Status Bar */}
                  <div className="h-5 bg-[#08090e] border-t border-[#1e2436] px-3 flex items-center justify-between text-[9px] text-[#94a3b8] select-none">
                    <div className="flex items-center gap-3">
                      <span className="text-[#38bdf8] flex items-center gap-1">
                        <span>⑂</span> main*
                      </span>
                      <span>0 errors, 0 warnings</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-[#d4af37]">TypeScript React</span>
                      <span>UTF-8</span>
                      <span className="text-[#10b981]">Prettier: ✓</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Portal Glow Overlay: Illuminates during zoom into screen */}
            <div
              ref={screenPortalRef}
              className="absolute inset-[7px] pb-0 bg-gradient-to-b from-[#38bdf8]/30 via-[#d4af37]/40 to-[#38bdf8]/60 rounded-t-xl pointer-events-none opacity-0 transition-opacity duration-150"
            />
          </div>

          {/* Laptop Base / Keyboard Deck */}
          <div className="relative w-[780px] max-w-[98vw] h-6 bg-gradient-to-b from-[#1a1d28] via-[#12141c] to-[#0a0c12] rounded-b-xl border-t border-[#334155]/60 shadow-[0_20px_40px_rgba(0,0,0,0.95)] flex items-center justify-center">
            {/* Display opening thumb notch */}
            <div className="w-20 h-1.5 bg-[#06070a] rounded-full border border-[#1e2436]" />
          </div>
        </div>

        {/* =========================================================================
            MOHAMMAD REZA FATHABADI & ERGONOMIC CHAIR (Matching Uploaded Photo)
            - Styled dark hair with texture
            - High-neck ribbed black knit collar (matching photo)
            - Forearm with detailed tattoo art
            - Ergonomic designer studio chair
           ========================================================================= */}
        <div
          ref={developerBodyRef}
          className="absolute z-20 pointer-events-none flex flex-col items-center bottom-[-8%] w-[680px] max-w-[95vw] will-change-transform"
        >
          {/* Developer Head, Hair & High-Neck Sweater Collar */}
          <div className="relative flex flex-col items-center">
            {/* Styled Hair with Natural Texture & Soft Highlights */}
            <div className="relative w-28 h-28 -mb-5 z-20">
              {/* Hair Base */}
              <div className="w-28 h-24 bg-gradient-to-b from-[#121010] via-[#1c1919] to-[#0d0c0c] rounded-t-full shadow-lg" />
              {/* Natural Styled Hair Texture Waves & Subtle Top Sheen */}
              <div className="absolute top-1 left-4 w-20 h-12 bg-gradient-to-tr from-transparent via-[#2d2828]/50 to-transparent rounded-full rotate-6" />
              <div className="absolute top-2 right-4 w-12 h-10 bg-gradient-to-tl from-transparent via-[#2d2828]/40 to-transparent rounded-full -rotate-6" />
              {/* Ears with soft rim light */}
              <div className="absolute top-14 -left-1.5 w-3.5 h-6 bg-[#3b2820] rounded-l-full border-l border-[#d4af37]/30" />
              <div className="absolute top-14 -right-1.5 w-3.5 h-6 bg-[#3b2820] rounded-r-full border-r border-[#38bdf8]/30" />
            </div>

            {/* Neck & High-Neck Ribbed Collar (Exact Style from User Photo) */}
            <div className="relative w-24 h-16 bg-[#16171b] -mb-4 z-10 flex flex-col items-center rounded-t-lg border-t-2 border-[#2b2e38]">
              {/* Vertical ribbed knit texture */}
              <div className="w-full h-full flex justify-around opacity-40 px-2 pt-1">
                {[...Array(9)].map((_, i) => (
                  <div key={i} className="w-[1.5px] h-full bg-[#374151]" />
                ))}
              </div>
              {/* Center collar zipper notch */}
              <div className="absolute top-1 w-1.5 h-6 bg-[#475569] rounded-sm shadow-sm" />
            </div>

            {/* Shoulders, Arms, and Back (Black Knit Sweater & Forearm Tattoo) */}
            <div className="relative w-[560px] max-w-[90vw] flex items-center justify-center">
              {/* Black Knit Sweater Body (Sculpted Anatomical Shape) */}
              <svg
                viewBox="0 0 560 320"
                className="w-full h-auto drop-shadow-[0_20px_50px_rgba(0,0,0,0.9)]"
                fill="none"
              >
                <defs>
                  {/* Sweater Deep Obsidian Knit Gradient */}
                  <linearGradient id="sweaterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#1a1c24" />
                    <stop offset="35%" stopColor="#12131a" />
                    <stop offset="70%" stopColor="#0c0d12" />
                    <stop offset="100%" stopColor="#08090d" />
                  </linearGradient>

                  {/* Left Rim Light (Champagne Gold Studio Accent) */}
                  <linearGradient id="goldRimGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#d4af37" stopOpacity="0.85" />
                    <stop offset="8%" stopColor="#d4af37" stopOpacity="0" />
                  </linearGradient>

                  {/* Right Rim Light (Cyber Cyan Screen Reflection) */}
                  <linearGradient id="cyanRimGrad" x1="100%" y1="0%" x2="0%" y2="0%">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.85" />
                    <stop offset="8%" stopColor="#38bdf8" stopOpacity="0" />
                  </linearGradient>

                  {/* Tattoo Ink Gradient for Right Forearm */}
                  <linearGradient id="tattooGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#2e374d" />
                    <stop offset="50%" stopColor="#1a202c" />
                    <stop offset="100%" stopColor="#111827" />
                  </linearGradient>
                </defs>

                {/* Main Back & Shoulders Contour */}
                <path
                  d="M 120 320 C 130 180 180 60 230 45 L 330 45 C 380 60 430 180 440 320 Z"
                  fill="url(#sweaterGrad)"
                />

                {/* Left Arm & Forearm reaching forward to typing position */}
                <path
                  d="M 120 320 C 100 230 140 140 220 80 L 250 140 C 190 180 170 250 160 320 Z"
                  fill="#151720"
                />

                {/* Right Arm & Forearm reaching forward to keyboard/trackpad */}
                <path
                  d="M 440 320 C 460 230 420 140 340 80 L 310 140 C 370 180 390 250 400 320 Z"
                  fill="#151720"
                />

                {/* High-Neck Sweater Ribbed Seam Lines */}
                <path d="M 230 45 Q 280 65 330 45" stroke="#374151" strokeWidth="2.5" />
                <path d="M 220 70 Q 280 92 340 70" stroke="#2a3042" strokeWidth="2" opacity="0.6" />
                <path d="M 210 100 Q 280 125 350 100" stroke="#1f2433" strokeWidth="2" opacity="0.5" />

                {/* Left Rim Light Stroke */}
                <path
                  d="M 120 320 C 130 180 180 60 230 45"
                  stroke="url(#goldRimGrad)"
                  strokeWidth="3.5"
                />

                {/* Right Rim Light Stroke */}
                <path
                  d="M 330 45 C 380 60 430 180 440 320"
                  stroke="url(#cyanRimGrad)"
                  strokeWidth="3.5"
                />

                {/* Right Forearm Tattoo Artwork (Inspired by User Photo's Tattoo) */}
                <g opacity="0.85">
                  {/* Forearm skin base tone */}
                  <path d="M 380 230 Q 395 270 410 320 L 440 320 Q 425 260 405 220 Z" fill="#422e26" />
                  {/* Detailed tattoo linework overlay */}
                  <path d="M 390 240 Q 405 275 415 310" stroke="url(#tattooGrad)" strokeWidth="3" />
                  <path d="M 398 250 Q 412 280 425 315" stroke="url(#tattooGrad)" strokeWidth="2.5" />
                  <circle cx="405" cy="270" r="8" stroke="url(#tattooGrad)" strokeWidth="2" fill="none" />
                  <path d="M 400 260 Q 415 265 410 280" stroke="url(#tattooGrad)" strokeWidth="2" />
                  <path d="M 392 285 Q 410 290 420 305" stroke="url(#tattooGrad)" strokeWidth="2" />
                </g>
              </svg>
            </div>
          </div>

          {/* Ergonomic Designer Studio Chair Backrest (Framing the Developer) */}
          <div className="absolute -bottom-8 w-[640px] max-w-[96vw] h-48 -z-10 flex items-center justify-center pointer-events-none opacity-90">
            {/* Mesh Chair Spine & Lateral Support Frame */}
            <div className="relative w-full h-full flex items-center justify-center">
              {/* Outer Graphite Curved Shell */}
              <div className="w-[520px] h-44 rounded-t-[70px] bg-gradient-to-b from-[#181a24] via-[#0e1017] to-[#07080c] border border-[#272d3d] shadow-[0_30px_70px_rgba(0,0,0,0.98)] p-3">
                {/* Breathable Technical Mesh Texture */}
                <div className="w-full h-full rounded-t-[60px] bg-[#0c0e14] opacity-50 border border-[#1e2436]/40 flex flex-col justify-around overflow-hidden">
                  {[...Array(12)].map((_, i) => (
                    <div key={i} className="w-full h-[1px] bg-gradient-to-r from-transparent via-[#334155]/40 to-transparent" />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
