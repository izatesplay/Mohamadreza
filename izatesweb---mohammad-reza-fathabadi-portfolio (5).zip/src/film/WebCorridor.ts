import * as THREE from 'three';
import { LineSegments2 } from 'three/addons/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { StrandEntry, clamp01, lerp } from './types';

// ONE TABLE DRIVES BOTH THE STRANDS AND THE CAMERA
// Spacing tightening across the run: (0.045, 0.045, 0.038, 0.035, 0.031) of the act axis
export const STRAND_TABLE: StrandEntry[] = [
  { at: 0.320, span: 0.090, side: 1,  radius: 4.2, lead: 4.2 * 3.8, lift: 2.1 },
  { at: 0.365, span: 0.086, side: -1, radius: 4.4, lead: 4.4 * 3.8, lift: 2.3 },
  { at: 0.410, span: 0.080, side: 1,  radius: 4.6, lead: 4.6 * 3.8, lift: 2.5 },
  { at: 0.448, span: 0.075, side: -1, radius: 4.8, lead: 4.8 * 3.8, lift: 2.7 },
  { at: 0.483, span: 0.070, side: 1,  radius: 5.0, lead: 5.0 * 3.8, lift: 2.9 },
  { at: 0.514, span: 0.065, side: -1, radius: 5.2, lead: 5.2 * 3.8, lift: 3.1 },
];

// Continuous Camera Spine: evaluates camera center without swing offset
export function getCameraSpine(sp: number): THREE.Vector3 {
  // sp 0 -> 0.16: Act 1 figure overview
  if (sp <= 0.16) {
    const t = sp / 0.16;
    return new THREE.Vector3(0, lerp(9.0, 5.0, t), lerp(36.0, 0.0, t));
  }

  // Gear changes: 300 -> 150 -> 360 units per unit of sp
  // Step 1: sp 0.16 -> 0.36 (speed 300)
  // Step 2: sp 0.36 -> 0.48 (speed 150 - first strands catch and pull taut)
  // Step 3: sp 0.48 -> 0.72 (speed 360 - corridor accelerates into next act)
  // Step 4: sp 0.72 -> 1.00 (cruising rate 260 into act 5 convergence)
  let z = 0;
  if (sp <= 0.36) {
    z = -(sp - 0.16) * 300;
  } else if (sp <= 0.48) {
    const z1 = -(0.36 - 0.16) * 300; // -60
    z = z1 - (sp - 0.36) * 150;
  } else if (sp <= 0.72) {
    const z1 = -(0.36 - 0.16) * 300; // -60
    const z2 = z1 - (0.48 - 0.36) * 150; // -78
    z = z2 - (sp - 0.48) * 360;
  } else {
    const z1 = -(0.36 - 0.16) * 300; // -60
    const z2 = z1 - (0.48 - 0.36) * 150; // -78
    const z3 = z2 - (0.72 - 0.48) * 360; // -164.4
    z = z3 - (sp - 0.72) * 260;
  }

  return new THREE.Vector3(0, 2.0, z);
}

// Calculate Anchors derived from spine(at) + (side*radius, lift, -lead)
export const STRAND_ANCHORS: THREE.Vector3[] = STRAND_TABLE.map((entry) => {
  const baseSpine = getCameraSpine(entry.at);
  return new THREE.Vector3(
    baseSpine.x + entry.side * entry.radius,
    baseSpine.y + entry.lift,
    baseSpine.z - entry.lead
  );
});

// Calculate camera swing offset and banking from the shared table
// Lateral side * 3.2 * sin(pi*u), 1.5 dip, 0.15 rad bank
// u runs 0.08 - 0.82 of each strand's life so consecutive windows OVERLAP
export function calculateCameraSwing(sp: number, reducedMotion: boolean): { offset: THREE.Vector3; bank: number } {
  if (reducedMotion) {
    return { offset: new THREE.Vector3(0, 0, 0), bank: 0 };
  }

  let totalLateral = 0;
  let totalDip = 0;
  let totalBank = 0;

  for (let i = 0; i < STRAND_TABLE.length; i++) {
    const entry = STRAND_TABLE[i];
    const localT = (sp - entry.at) / entry.span;

    // Window u runs 0.08 - 0.82
    if (localT >= 0.08 && localT <= 0.82) {
      const u = (localT - 0.08) / (0.82 - 0.08);
      const envelope = Math.sin(Math.PI * u); // Exactly zero at both ends

      totalLateral += entry.side * 3.2 * envelope;
      totalDip += -1.5 * envelope; // Dip so camera passes under anchor
      totalBank += 0.15 * entry.side * envelope;
    }
  }

  return {
    offset: new THREE.Vector3(totalLateral, totalDip, 0),
    bank: totalBank,
  };
}

export class WebCorridor {
  public group: THREE.Group;
  private lineMesh: LineSegments2;
  private geometry: LineSegmentsGeometry;
  private material: LineMaterial;
  private segmentsPerStrand: number;
  private totalSegments: number;
  private positionsBuffer: Float32Array;
  private colorsBuffer: Float32Array;

  constructor(isMobile: boolean = false) {
    this.group = new THREE.Group();

    // Prompt requirement: "Fewer SEGMENTS per strand on mobile, never fewer strands"
    this.segmentsPerStrand = isMobile ? 24 : 48;
    this.totalSegments = STRAND_TABLE.length * this.segmentsPerStrand;

    // LineSegmentsGeometry's internal buffer of stride 6 per segment: [x1,y1,z1, x2,y2,z2]
    this.positionsBuffer = new Float32Array(this.totalSegments * 6);
    this.colorsBuffer = new Float32Array(this.totalSegments * 6);

    this.geometry = new LineSegmentsGeometry();
    this.geometry.setPositions(this.positionsBuffer);
    this.geometry.setColors(this.colorsBuffer);

    // Prompt: FAT lines. WebGL ignores linewidth on LineBasicMaterial.
    // linewidth 2.4 screen-space, additive blending so vertex fade to zero is absent (not black)
    this.material = new LineMaterial({
      linewidth: 2.4,
      vertexColors: true,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.material.resolution.set(window.innerWidth, window.innerHeight);

    this.lineMesh = new LineSegments2(this.geometry, this.material);
    this.group.add(this.lineMesh);
  }

  public setResolution(width: number, height: number) {
    this.material.resolution.set(width, height);
  }

  // Update strands in-place every frame from pure scalar sp
  public update(sp: number, cameraPos: THREE.Vector3) {
    let globalSegIdx = 0;

    for (let sIdx = 0; sIdx < STRAND_TABLE.length; sIdx++) {
      const entry = STRAND_TABLE[sIdx];
      const anchor = STRAND_ANCHORS[sIdx];
      const localT = (sp - entry.at) / entry.span;

      // Shooter origin follows camera / web shooter rig (side offset relative to camera)
      const shooterOrigin = new THREE.Vector3(
        cameraPos.x + entry.side * 0.42,
        cameraPos.y - 0.28,
        cameraPos.z - 0.5
      );

      const isActive = localT >= 0.0 && localT <= 1.0;

      // Strand phases on its own local t:
      // FIRE 0 - 0.12 (free end runs out to the anchor)
      // TAUT 0.12 - 0.55 (near-zero sag — that is what taut means)
      // RELEASE 0.55 - 0.80 (sag grows, a wave travels it)
      // FADE 0.80 - 1.0 (fade to absent)
      let reach = 1.0;
      let sagScale = 0.0;
      let waveParam = 0.0;
      let alphaFade = 1.0;
      let impulseMix = 0.0;

      if (!isActive) {
        reach = 0.0;
        alphaFade = 0.0;
      } else if (localT < 0.12) {
        // FIRE phase
        reach = localT / 0.12;
        sagScale = 0.08 * (1.0 - reach);
        impulseMix = 1.0 - (localT / 0.12); // Scarlet impulse at firing edge
        alphaFade = 1.0;
      } else if (localT <= 0.55) {
        // TAUT phase: near-zero sag
        reach = 1.0;
        sagScale = 0.05;
        alphaFade = 1.0;
      } else if (localT <= 0.80) {
        // RELEASE phase: sag grows, wave travels
        reach = 1.0;
        const relT = (localT - 0.55) / 0.25;
        sagScale = 0.05 + relT * 1.85;
        waveParam = relT * Math.PI * 6.0;
        alphaFade = 1.0 - relT * 0.25;
      } else {
        // FADE phase
        reach = 1.0;
        const fadeT = (localT - 0.80) / 0.20;
        sagScale = 1.9 + fadeT * 0.5;
        alphaFade = 1.0 - fadeT;
      }

      // Calculate sample points along the catenary / sag curve
      const effectiveTarget = new THREE.Vector3().lerpVectors(shooterOrigin, anchor, reach);

      for (let seg = 0; seg < this.segmentsPerStrand; seg++) {
        const u1 = seg / this.segmentsPerStrand;
        const u2 = (seg + 1) / this.segmentsPerStrand;

        // Position 1
        const p1 = new THREE.Vector3().lerpVectors(shooterOrigin, effectiveTarget, u1);
        if (isActive && sagScale > 0) {
          const sag1 = Math.sin(Math.PI * u1) * sagScale;
          const wave1 = Math.sin(u1 * Math.PI * 3.0 - waveParam) * 0.22 * sagScale;
          p1.y -= sag1;
          p1.x += wave1 * entry.side;
        }

        // Position 2
        const p2 = new THREE.Vector3().lerpVectors(shooterOrigin, effectiveTarget, u2);
        if (isActive && sagScale > 0) {
          const sag2 = Math.sin(Math.PI * u2) * sagScale;
          const wave2 = Math.sin(u2 * Math.PI * 3.0 - waveParam) * 0.22 * sagScale;
          p2.y -= sag2;
          p2.x += wave2 * entry.side;
        }

        const bufOffset = globalSegIdx * 6;

        if (isActive && reach > 0.01 && alphaFade > 0.005) {
          this.positionsBuffer[bufOffset + 0] = p1.x;
          this.positionsBuffer[bufOffset + 1] = p1.y;
          this.positionsBuffer[bufOffset + 2] = p1.z;

          this.positionsBuffer[bufOffset + 3] = p2.x;
          this.positionsBuffer[bufOffset + 4] = p2.y;
          this.positionsBuffer[bufOffset + 5] = p2.z;

          // Strand colour: pure starlight platinum at gain 1.25 (over bloom threshold)
          const baseR = 1.22 * alphaFade;
          const baseG = 1.22 * alphaFade;
          const baseB = 1.25 * alphaFade;

          // Tip luxury gold impulse mix factor
          const tipMix = impulseMix * Math.max(0, u2 - 0.7) / 0.3;
          const r = lerp(baseR, 1.15 * alphaFade, tipMix); // gold R
          const g = lerp(baseG, 0.92 * alphaFade, tipMix); // gold G
          const b = lerp(baseB, 0.38 * alphaFade, tipMix); // gold B

          this.colorsBuffer[bufOffset + 0] = r;
          this.colorsBuffer[bufOffset + 1] = g;
          this.colorsBuffer[bufOffset + 2] = b;

          this.colorsBuffer[bufOffset + 3] = r;
          this.colorsBuffer[bufOffset + 4] = g;
          this.colorsBuffer[bufOffset + 5] = b;
        } else {
          // Inactive: collapse segment and zero color
          this.positionsBuffer[bufOffset + 0] = 0;
          this.positionsBuffer[bufOffset + 1] = 0;
          this.positionsBuffer[bufOffset + 2] = 0;

          this.positionsBuffer[bufOffset + 3] = 0;
          this.positionsBuffer[bufOffset + 4] = 0;
          this.positionsBuffer[bufOffset + 5] = 0;

          this.colorsBuffer[bufOffset + 0] = 0;
          this.colorsBuffer[bufOffset + 1] = 0;
          this.colorsBuffer[bufOffset + 2] = 0;

          this.colorsBuffer[bufOffset + 3] = 0;
          this.colorsBuffer[bufOffset + 4] = 0;
          this.colorsBuffer[bufOffset + 5] = 0;
        }

        globalSegIdx++;
      }
    }

    this.geometry.setPositions(this.positionsBuffer);
    this.geometry.setColors(this.colorsBuffer);
  }
}
