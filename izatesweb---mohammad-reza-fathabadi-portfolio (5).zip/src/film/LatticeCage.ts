import * as THREE from 'three';
import { clamp01, lerp, RAW_COLORS } from './types';
import { scrollState } from './scrollState';

export class LatticeCage {
  public mesh: THREE.LineSegments;
  private geometry: THREE.BufferGeometry;
  private baseStarts: Float32Array;
  private baseEnds: Float32Array;
  private sharedRandoms: Float32Array;
  private currentPositions: Float32Array;
  private segmentCount: number;

  constructor() {
    // Generate polygonal cage surrounding the figure at (0, 9, 0)
    // Wireframe output is non-indexed vertex PAIRS
    const segments: { p1: THREE.Vector3; p2: THREE.Vector3; rand: number }[] = [];

    const cageRadius = 5.2;
    const cageHeight = 16.0;
    const rings = 12;
    const radialSegs = 16;

    const vertices: THREE.Vector3[][] = [];
    for (let r = 0; r <= rings; r++) {
      const ringY = 9.0 + (r / rings - 0.5) * cageHeight;
      // Barrel radius shaping
      const normY = (r / rings - 0.5) * 2;
      const rScale = Math.sqrt(Math.max(0.1, 1 - normY * normY * 0.45));
      const ringRadius = cageRadius * rScale;

      const ringVerts: THREE.Vector3[] = [];
      for (let s = 0; s < radialSegs; s++) {
        const theta = (s / radialSegs) * Math.PI * 2;
        ringVerts.push(new THREE.Vector3(
          Math.cos(theta) * ringRadius,
          ringY,
          Math.sin(theta) * ringRadius
        ));
      }
      vertices.push(ringVerts);
    }

    // Add ring segments
    for (let r = 0; r <= rings; r++) {
      for (let s = 0; s < radialSegs; s++) {
        const p1 = vertices[r][s];
        const p2 = vertices[r][(s + 1) % radialSegs];
        segments.push({ p1, p2, rand: Math.random() });
      }
    }

    // Add vertical ribs
    for (let r = 0; r < rings; r++) {
      for (let s = 0; s < radialSegs; s++) {
        const p1 = vertices[r][s];
        const p2 = vertices[r + 1][s];
        segments.push({ p1, p2, rand: Math.random() });
      }
    }

    // Add diagonal bracing
    for (let r = 0; r < rings; r++) {
      for (let s = 0; s < radialSegs; s++) {
        const p1 = vertices[r][s];
        const p2 = vertices[r + 1][(s + 1) % radialSegs];
        segments.push({ p1, p2, rand: Math.random() });
      }
    }

    this.segmentCount = segments.length;
    this.baseStarts = new Float32Array(this.segmentCount * 3);
    this.baseEnds = new Float32Array(this.segmentCount * 3);
    this.sharedRandoms = new Float32Array(this.segmentCount);
    this.currentPositions = new Float32Array(this.segmentCount * 6); // 2 verts per segment * 3 coords

    for (let i = 0; i < this.segmentCount; i++) {
      const seg = segments[i];
      this.baseStarts[i * 3 + 0] = seg.p1.x;
      this.baseStarts[i * 3 + 1] = seg.p1.y;
      this.baseStarts[i * 3 + 2] = seg.p1.z;

      this.baseEnds[i * 3 + 0] = seg.p2.x;
      this.baseEnds[i * 3 + 1] = seg.p2.y;
      this.baseEnds[i * 3 + 2] = seg.p2.z;

      this.sharedRandoms[i] = seg.rand;
    }

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.currentPositions, 3));

    const material = new THREE.LineBasicMaterial({
      color: RAW_COLORS.scarlet500,
      transparent: true,
      opacity: 0.75,
      depthWrite: false,
    });

    this.mesh = new THREE.LineSegments(this.geometry, material);
  }

  // ONE scalar weaves it and un-weaves it
  public update(sp: number) {
    // Build scalar: weaves in from sp 0.0 to 0.10, holds, then unweaves from 0.14 to 0.24
    let buildScalar = 0;
    if (sp < 0.12) {
      buildScalar = clamp01(sp / 0.10);
    } else {
      buildScalar = clamp01(1.0 - (sp - 0.12) / 0.12);
    }

    const posAttr = this.geometry.attributes.position as THREE.BufferAttribute;
    const posArray = posAttr.array as Float32Array;

    for (let i = 0; i < this.segmentCount; i++) {
      const rand = this.sharedRandoms[i];
      // Segment draws itself from one end as build scalar passes its own staggered threshold
      const segThreshold = rand * 0.65;
      const progress = clamp01((buildScalar - segThreshold) / 0.35);

      const x1 = this.baseStarts[i * 3 + 0];
      const y1 = this.baseStarts[i * 3 + 1];
      const z1 = this.baseStarts[i * 3 + 2];

      const x2 = this.baseEnds[i * 3 + 0];
      const y2 = this.baseEnds[i * 3 + 1];
      const z2 = this.baseEnds[i * 3 + 2];

      // Vertex 1: start point
      posArray[i * 6 + 0] = x1;
      posArray[i * 6 + 1] = y1;
      posArray[i * 6 + 2] = z1;

      // Vertex 2: draws out to lerp(start, end, progress)
      posArray[i * 6 + 3] = lerp(x1, x2, progress);
      posArray[i * 6 + 4] = lerp(y1, y2, progress);
      posArray[i * 6 + 5] = lerp(z1, z2, progress);
    }
    posAttr.needsUpdate = true;
    const mat = this.mesh.material as THREE.LineBasicMaterial;
    if (scrollState.wireframeMode) {
      mat.color.setHex(RAW_COLORS.cyan500);
      mat.opacity = 0.95 * clamp01(buildScalar * 1.5);
    } else {
      mat.color.setHex(RAW_COLORS.scarlet500);
      mat.opacity = 0.75 * clamp01(buildScalar * 1.5);
    }
    this.mesh.visible = buildScalar > 0.001;
  }
}
