import React, { useEffect, useRef } from 'react';
import { scrollState } from './scrollState';
import { clamp01 } from './types';
import { ArrowUpRight, Sparkles, Layers, MessageSquare, Code2, CheckCircle2, Bot } from 'lucide-react';

interface OverlayConfig {
  act: number;
  spStart: number;
  spEnd: number;
  tagRoman: string;
  tagCategory: string;
  persianTitle: string;
  englishTitle: string;
  persianDescription: string;
  highlights: string[];
  showAction?: boolean;
}

const OVERLAY_CONFIGS: OverlayConfig[] = [
  {
    act: 1,
    spStart: 0.00,
    spEnd: 0.18,
    tagRoman: 'ACT I',
    tagCategory: 'معمار وب و کدنویسی خلاق',
    persianTitle: 'محمدرضا فتح‌آبادی',
    englishTitle: 'MOHAMMAD REZA FATHABADI',
    persianDescription: 'طراحی وب‌سایت‌های مدرن، اختصاصی و سه‌بعدی با استانداردهای جهانی و بالاترین ظرافت مهندسی',
    highlights: ['کدنویسی اختصاصی', 'طراحی سه‌بعدی با Three.js', 'تجربه کاربری منحصربه‌فرد'],
  },
  {
    act: 2,
    spStart: 0.16,
    spEnd: 0.38,
    tagRoman: 'ACT II',
    tagCategory: 'استودیو تخصصی طراحی وب',
    persianTitle: 'استودیو ایزاتس‌وب؛ تلاقی هنر و فناوری',
    englishTitle: 'IZATESWEB DIGITAL STUDIO',
    persianDescription: 'خلق هویت‌های آنلاین لوکس و ماندگار که نگاه‌ها را مجذوب و جایگاه برند شما را تثبیت می‌کنند',
    highlights: ['هویت بصری لوکس', 'طراحی رابط کاربری UI/UX', 'توسعه وردپرس و ری‌اکت'],
  },
  {
    act: 3,
    spStart: 0.34,
    spEnd: 0.58,
    tagRoman: 'ACT III',
    tagCategory: 'توسعه فرانت‌اند و سیستم‌های مقیاس‌پذیر',
    persianTitle: 'معماری مقیاس‌پذیر و وب تعاملی',
    englishTitle: 'SCALABLE ARCHITECTURE & INTERACTIVITY',
    persianDescription: 'اجرای دقیق‌ترین تعاملات کاربری و انیمیشن‌های روان با وسواس میلی‌متری بر روی هر پیکسل',
    highlights: ['کدنویسی تمیز و ساختاریافته', 'انیمیشن‌های نرم و ۶۰ فریم', 'واکنش‌گرایی کامل در موبایل'],
  },
  {
    act: 4,
    spStart: 0.54,
    spEnd: 0.76,
    tagRoman: 'ACT IV',
    tagCategory: 'سرعت خارق‌العاده و سئوی برتر',
    persianTitle: 'لود زیر یک ثانیه و صدرنشینی در گوگل',
    englishTitle: 'HIGH PERFORMANCE & DOMINANT SEO',
    persianDescription: 'بهینه‌سازی حداکثری سرعت بارگذاری و پیاده‌سازی سئوی فنی جهت جذب بالاترین ترافیک هدفمند',
    highlights: ['امتیاز ۱۰۰ در تست‌های سرعت', 'سئوی تکنیکال و پایدار', 'امنیت نفوذناپذیر'],
  },
  {
    act: 5,
    spStart: 0.72,
    spEnd: 0.92,
    tagRoman: 'ACT V',
    tagCategory: 'رشد تجاری و پرستیژ برند',
    persianTitle: 'تبدیل بازدیدکننده به خریدار و همراه وفادار',
    englishTitle: 'MAXIMUM CONVERSION & BRAND VALUE',
    persianDescription: 'طراحی هدفمند برای بالا بردن اعتبار تجاری شما و تبدیل هر بازدید به فرصت ارزشمند فروش',
    highlights: ['طراحی فروش‌محور', 'روانشناسی رفتار کاربر', 'مشاوره استراتژیک توسعه'],
  },
  {
    act: 6,
    spStart: 0.88,
    spEnd: 1.05,
    tagRoman: 'ACT VI',
    tagCategory: 'همکاری و آغاز پروژه',
    persianTitle: 'آماده‌اید وب‌سایت استثنایی خود را بسازید؟',
    englishTitle: 'LET’S CRAFT YOUR DIGITAL FUTURE',
    persianDescription: 'از ایده اولیه تا پیاده‌سازی نهایی، همراه مطمئن شما در خلق تجربه‌ای بی‌رقیب خواهیم بود',
    highlights: ['مشاوره رایگان تخصصی', 'برآورد هوشمند بودجه', 'پشتیبانی فنی اختصاصی'],
    showAction: true,
  },
];

interface FilmOverlaysProps {
  onOpenProjects: () => void;
  onOpenOrder: () => void;
  onOpenContact: () => void;
  onOpenAbout: () => void;
  onOpenEmo?: () => void;
}

export const FilmOverlays: React.FC<FilmOverlaysProps> = ({
  onOpenProjects,
  onOpenOrder,
  onOpenContact,
  onOpenAbout,
  onOpenEmo,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const overlayElementsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    let animId: number;

    const updateDOM = () => {
      // Act axis (sp)
      const sp = scrollState.sp;

      OVERLAY_CONFIGS.forEach((cfg, idx) => {
        const el = overlayElementsRef.current[idx];
        if (!el) return;

        if (sp < cfg.spStart || sp > cfg.spEnd) {
          if (el.style.visibility !== 'hidden') {
            el.style.visibility = 'hidden';
            el.style.opacity = '0';
            el.style.transform = 'translate3d(0, 20px, 0)';
          }
          return;
        }

        const u = (sp - cfg.spStart) / (cfg.spEnd - cfg.spStart);

        // Smooth entry & exit envelope
        let opacity = 1.0;
        let translateY = 0;
        let blur = 0;

        if (u < 0.28) {
          const entryProgress = clamp01(u / 0.28);
          // Ease in cubic
          opacity = entryProgress * entryProgress;
          translateY = (1.0 - entryProgress) * 28;
          blur = (1.0 - entryProgress) * 8;
        } else if (u > 0.72) {
          const exitProgress = clamp01((u - 0.72) / 0.28);
          opacity = 1.0 - exitProgress * exitProgress;
          translateY = -exitProgress * 28;
          blur = exitProgress * 8;
        }

        if (opacity < 0.01) {
          if (el.style.visibility !== 'hidden') {
            el.style.visibility = 'hidden';
            el.style.opacity = '0';
          }
          return;
        }

        el.style.visibility = 'visible';
        el.style.opacity = `${opacity.toFixed(3)}`;
        el.style.transform = `translate3d(0, ${translateY.toFixed(1)}px, 0)`;
        el.style.filter = blur > 0.1 ? `blur(${blur.toFixed(1)}px)` : 'none';
      });

      animId = requestAnimationFrame(updateDOM);
    };

    animId = requestAnimationFrame(updateDOM);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-20 overflow-hidden flex items-center justify-center select-none px-4"
    >
      {OVERLAY_CONFIGS.map((cfg, idx) => (
        <div
          key={cfg.act}
          ref={(el) => {
            overlayElementsRef.current[idx] = el;
          }}
          className={`absolute inset-0 flex flex-col items-center p-3 sm:p-6 text-center max-w-4xl mx-auto will-change-[transform,opacity,filter] ${
            cfg.act === 1 ? 'justify-start pt-14 sm:pt-20' : 'justify-center'
          }`}
          style={{ visibility: 'hidden', opacity: 0 }}
        >
          {/* Top Luxury Pill Badge */}
          <div className="inline-flex items-center gap-2 sm:gap-2.5 px-3 sm:px-4 py-1 sm:py-1.5 rounded-full bg-[#0d0f17]/90 border border-[#D4AF37]/35 backdrop-blur-xl shadow-[0_0_20px_rgba(212,175,55,0.2)] mb-3 sm:mb-5">
            <span className="w-1.5 sm:w-2 h-1.5 sm:h-2 rounded-full bg-[#D4AF37] animate-ping" />
            <span className="w-1 sm:w-1.5 h-1 sm:h-1.5 rounded-full bg-[#D4AF37] shadow-[0_0_8px_#D4AF37]" />
            <span dir="ltr" className="text-[10px] sm:text-[11px] font-mono tracking-widest text-[#D4AF37] font-bold uppercase">
              {cfg.tagRoman}
            </span>
            <span className="text-white/20 text-xs">•</span>
            <span className="text-[11px] sm:text-xs font-medium text-[#F3E5AB]">
              {cfg.tagCategory}
            </span>
          </div>

          {/* Persian Primary Title: Monumental, Pristine & High-Contrast */}
          <h1 className="text-2xl sm:text-4xl md:text-5xl lg:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-b from-[#FFFFFF] via-[#F8FAFC] to-[#CBD5E1] tracking-tight mb-2 sm:mb-3 leading-[1.3] drop-shadow-[0_4px_30px_rgba(0,0,0,0.9)] font-['Vazirmatn']">
            {cfg.persianTitle}
          </h1>

          {/* English Luxury Architecture Subtitle - Solid LTR Text Container: guarantees 100% correct character order */}
          <div
            dir="ltr"
            style={{ direction: 'ltr', unicodeBidi: 'normal' }}
            className="text-center text-[10px] sm:text-xs md:text-sm lg:text-base font-['Cinzel'] tracking-[0.2em] sm:tracking-[0.28em] text-[#D4AF37] uppercase font-bold mb-3 sm:mb-4 drop-shadow-[0_2px_15px_rgba(212,175,55,0.35)] select-none"
          >
            {cfg.englishTitle}
          </div>

          {/* Persian Descriptive Paragraph */}
          <p className="text-xs sm:text-base md:text-lg lg:text-xl font-light text-[#E2E8F0] max-w-2xl leading-relaxed mb-4 sm:mb-6 font-['Vazirmatn'] drop-shadow-[0_2px_10px_rgba(0,0,0,0.7)] px-2 sm:px-0">
            {cfg.persianDescription}
          </p>

          {/* Key Feature Highlight Badges */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2.5 max-w-xl px-1">
            {cfg.highlights.map((item, hIdx) => (
              <div
                key={hIdx}
                className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-full bg-[#141824]/75 border border-[#1e2436] backdrop-blur-md text-[10px] sm:text-xs font-normal text-[#94A3B8] hover:text-[#F3E5AB] hover:border-[#D4AF37]/30 transition-all duration-300"
              >
                <CheckCircle2 className="w-3 sm:w-3.5 h-3 sm:h-3.5 text-[#D4AF37]" />
                <span>{item}</span>
              </div>
            ))}
          </div>

          {/* Act 1 Special Cue: Scroll to dive into the laptop */}
          {cfg.act === 1 && (
            <div className="mt-3 sm:mt-5 flex items-center gap-2 px-3 sm:px-4 py-1 sm:py-1.5 rounded-full bg-[#0d0f17]/90 border border-[#D4AF37]/30 text-[11px] sm:text-xs font-['Vazirmatn'] text-[#F3E5AB] shadow-[0_0_15px_rgba(212,175,55,0.2)] animate-pulse">
              <span className="text-[#38BDF8]">↓</span>
              <span>اسکرول کنید تا دوربین به عمق صفحه مانیتور و کدهای ایزاتس‌وب وارد شود</span>
              <span className="text-[#38BDF8]">↓</span>
            </div>
          )}

          {/* Act VI Convergence CTAs (Re-enables pointer events only on buttons) */}
          {cfg.showAction && (
            <div className="mt-5 sm:mt-8 flex flex-wrap items-center justify-center gap-2 sm:gap-4 pointer-events-auto max-w-lg mx-auto">
              <button
                onClick={onOpenOrder}
                className="group flex items-center gap-2 sm:gap-2.5 px-4 sm:px-7 py-2.5 sm:py-3.5 rounded-full bg-gradient-to-r from-[#D4AF37] via-[#F3E5AB] to-[#C5A059] text-[#08090E] font-bold text-xs sm:text-sm tracking-wide shadow-[0_0_35px_rgba(212,175,55,0.4)] hover:shadow-[0_0_50px_rgba(212,175,55,0.6)] hover:scale-105 transition-all duration-300 cursor-pointer"
              >
                <Sparkles className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-[#08090E] transition-transform group-hover:rotate-12" />
                <span>ثبت سفارش و برآورد آنلاین</span>
                <ArrowUpRight className="w-3.5 sm:w-4 h-3.5 sm:h-4" />
              </button>

              <button
                onClick={onOpenProjects}
                className="flex items-center gap-2 sm:gap-2.5 px-4 sm:px-6 py-2.5 sm:py-3.5 rounded-full bg-[#0d0f17]/90 hover:bg-[#141824] border border-[#D4AF37]/40 text-[#F8FAFC] hover:text-[#F3E5AB] font-medium text-xs sm:text-sm transition-all duration-300 shadow-[0_4px_20px_rgba(0,0,0,0.5)] cursor-pointer"
              >
                <Layers className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-[#38BDF8]" />
                <span>بررسی نمونه‌کارها</span>
              </button>

              <button
                onClick={onOpenContact}
                className="flex items-center gap-1.5 sm:gap-2.5 px-3.5 sm:px-5 py-2.5 sm:py-3.5 rounded-full bg-[#0d0f17]/80 hover:bg-[#141824] border border-[#1e2436] text-[#94A3B8] hover:text-white text-xs sm:text-sm transition-all duration-300 cursor-pointer"
              >
                <MessageSquare className="w-3.5 sm:w-4 h-3.5 sm:h-4" />
                <span>ارتباط مستقیم</span>
              </button>

              {onOpenEmo && (
                <button
                  onClick={onOpenEmo}
                  className="flex items-center gap-2 sm:gap-2.5 px-4 sm:px-6 py-2.5 sm:py-3.5 rounded-full bg-gradient-to-r from-cyan-600/30 to-blue-600/30 hover:from-cyan-600/50 hover:to-blue-600/50 border border-cyan-400/50 text-cyan-200 hover:text-white font-medium text-xs sm:text-sm transition-all duration-300 shadow-[0_0_25px_rgba(6,182,212,0.3)] hover:shadow-[0_0_35px_rgba(6,182,212,0.5)] hover:scale-105 cursor-pointer"
                >
                  <Bot className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-cyan-400 animate-pulse" />
                  <span>صحبت با ربات ایمو (EMO)</span>
                </button>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};
