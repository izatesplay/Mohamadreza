import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'fa' | 'en';

interface LanguageContextType {
  language: Language;
  direction: 'rtl' | 'ltr';
  toggleLanguage: () => void;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  fa: {
    // Brand & General
    brandName: 'izatesweb',
    designerName: 'محمد رضا فتح آبادی',
    officialBadge: 'برند رسمی izatesweb — کیفیت بدون سازش',
    
    // Nav
    navHome: 'خانه',
    navAbout: 'درباره من',
    navProjects: 'نمونه کارها',
    navTeam: 'تیم',
    navOrder: 'سفارش پروژه',
    navContact: 'تماس با ما',
    adminLogin: 'ورود ادمین',
    adminPanel: 'پنل ادمین',
    backToSite: 'بازگشت به سایت',
    adminMobile: 'ادمین',
    siteMobile: 'سایت',
    callNow: 'تماس مستقیم',
    orderProjectHeader: 'ثبت سفارش پروژه جدید',
    
    // Hero
    title1: 'طراح سایت وردپرسی و اختصاصی',
    title2: 'متخصص بهینه‌سازی سرعت و سئو',
    title3: 'طراحی وب‌سایت‌های لوکس شرکتی و فروشگاهی',
    title4: 'توسعه‌دهنده فرانت‌اند و وب پلتفرم',
    heroDesc: 'طراحی و توسعه انواع وب‌سایت‌های قدرتمند، فوق‌العاده سریع و استاندارد با جدیدترین متدولوژی‌های وردپرس اختصاصی و کدنویسی مدرن. تبدیل ایده شما به پلتفرم آنلاین لوکس و درآمدزا.',
    heroOrderBtn: 'ثبت سفارش پروژه',
    heroProjectsBtn: 'مشاهده نمونه‌کارها',
    botBanner: 'با دستیار رباتی زنده ایزاتس‌وب صحبت کن!',
    stat1Label: 'پروژه موفق',
    stat2Label: 'سال سابقه تخصصی',
    stat3Label: 'رضایت مشتریان',
    stat4Label: 'امتیاز سرعت گوگل',

    // About
    aboutBadge: 'درباره izatesweb',
    aboutHeading: 'درباره محمد رضا فتح آبادی',
    aboutSubheading: 'طراح و توسعه‌دهنده ارشد وب با هدف خلق وب‌سایت‌های مدرن، سریع و کارآمد که کسب‌وکار شما را در فضای دیجیتال متمایز می‌کند.',
    aboutBioTitle: 'خلق زیبایی، سرعت و درآمدزایی در دنیای وب',
    aboutBio1: 'من محمد رضا فتح آبادی هستم. با بیش از ۵ سال تجربه درزمینه طراحی سایت‌های وردپرسی و توسعه اختصاصی وب، به برندها و کسب‌وکارهای مختلف کمک می‌کنم حضور دیجیتالی درخشان و پربازدهی داشته باشند.',
    aboutBio2: 'در برند izatesweb، اعتقاد ما بر این است که یک وب‌سایت فقط یک صفحه اینترنتی نیست؛ بلکه ویترین اصلی و ماشین فروش کسب‌وکار شماست. به همین دلیل تمامی پروژه‌ها با رعایت بالاترین استانداردهای کدنویسی، امنیت بالا، واکنش‌گرایی کامل در تمامی نمایشگرها و سرعت لود فوق‌العاده طراحی می‌شوند.',
    aboutReadyTitle: 'آماده پذیرش پروژه‌های جدید',
    aboutReadySub: 'طراحی اختصاصی و وردپرسی حرفه‌ای',
    aboutCheck1: 'تضمین امتیاز بالای سرعت در GTmetrix',
    aboutCheck2: 'طراحی ۱۰۰٪ ریسپانسو برای موبایل و تبلت',
    aboutCheck3: 'تحویل کاملاً آن‌تایم و طبق جدول زمان‌بندی',
    aboutCheck4: 'پشتیبانی رایگان و مشاوره آنلاین تخصصی',
    feat1Title: 'وردپرس کاملاً اختصاصی و بهینه',
    feat1Desc: 'کدنویسی تمیز بدون افزونه‌های سنگین و اضافی جهت دست‌یابی به حداکثر سرعت، پایداری و امنیت بالا.',
    feat2Title: 'طراحی مدرن و رابط کاربری جذاب',
    feat2Desc: 'رابط کاربری چشم‌نواز مطابق با روانشناسی رنگ و اصول جدید UI/UX برای جذب بالاترین میزان مشتری.',
    feat3Title: 'سئوی استاندارد و آماده رتبه ۱ گوگل',
    feat3Desc: 'ساختار فنی وب‌سایت کاملاً منطبق بر آخرین الگوریتم‌های گوگل، Schema و متاتگ‌های پیشرفته.',
    feat4Title: 'پشتیبانی فنی و آموزشی کامل',
    feat4Desc: 'ارائه آموزش کامل ویدئویی مدیریت وب‌سایت به همراه پشتیبانی مستقیم و سریع پس از تحویل پروژه.',

    // Projects
    projectsBadge: 'نمونه‌کارهای izatesweb',
    projectsHeading: 'آخرین پروژه‌ها و نمونه‌کارهای اجرا شده',
    projectsSubheading: 'مجموعه‌ای از بهترین وب‌سایت‌های وردپرسی و اختصاصی طراحی شده توسط محمد رضا فتح آبادی با بالاترین کیفیت و رضایت کارفرمایان.',
    catAll: 'همه',
    catWordPress: 'وردپرس',
    catStore: 'فروشگاهی',
    catCorporate: 'شرکتی',
    catCustom: 'اختصاصی',
    noProjectsFound: 'پروژه‌ای در این دسته‌بندی یافت نشد.',
    detailsBtn: 'جزئیات',
    liveDemoBtn: 'پیش‌نمایش زنده',
    categoryLabel: 'دسته‌بندی:',
    techUsedLabel: 'تکنولوژی‌های استفاده شده:',
    closeBtn: 'بستن',
    visitLiveSite: 'مشاهده سایت زنده',

    // Team
    teamBadge: 'تیم متخصص izatesweb',
    teamHeading: 'تیم با انگیزه و حرفه‌ای ما',
    teamSubheading: 'اعضای تیم izatesweb متشکل از طراحان، برنامه‌نویسان و متخصصان سئو با هدایت محمد رضا فتح آبادی.',

    // Order Form
    orderBadge: 'مشاوره و استعلام قیمت رایگان',
    orderHeading: 'سفارش آنلاین پروژه شما با izatesweb',
    orderSubheading: 'فرم زیر را تکمیل کنید تا در کوتاه‌ترین زمان ممکن، پروپوزال فنی و تخمین دقیق زمان و هزینه ساخت وب‌سایت برای شما ارسال شود.',
    orderHilite1Title: 'مشاوره فنی پیش از شروع',
    orderHilite1Desc: 'بررسی نیازها و ارائه بهترین تکنولوژی متناسب با بودجه شما',
    orderHilite2Title: 'تضمین کیفیت و پشتیبانی',
    orderHilite2Desc: 'پشتیبانی کامل پس از تحویل و آموزش رایگان پنل مدیریت',
    formTitle: 'فرم درخواست پروژه',
    fullNameLabel: 'نام و نام خانوادگی',
    fullNamePlaceholder: 'مثلاً: علی رضایی',
    phoneLabel: 'شماره همراه (جهت تماس و واتساپ)',
    phonePlaceholder: '09123456789',
    projectTypeLabel: 'نوع پروژه مد نظر شما',
    projectDescLabel: 'توضیحات پروژه و قابلیت‌های مورد نیاز',
    projectDescPlaceholder: 'خلاصه‌ای از فعالیت کسب‌وکار، امکانات درخواستی و ایده‌های خود را بنویسید...',
    submitOrderBtn: 'ثبت نهایی درخواست پروژه',
    submittingText: 'در حال ثبت اطلاعات...',
    successOrderMsg: 'سفارش شما با موفقیت ثبت شد! محمد رضا فتح آبادی به‌زودی با شما تماس خواهد گرفت.',
    requiredFieldError: 'لطفاً تمامی فیلدهای نام، شماره تماس و توضیحات پروژه را تکمیل فرمایید.',
    networkError: 'خطا در ارتباط با سرور. لطفاً از اتصال اینترنت خود اطمینان حاصل فرمایید.',
    opt1: 'سایت فروشگاهی وردپرس',
    opt2: 'سایت شرکتی و پرتال تجاری',
    opt3: 'طراحی وب‌سایت اختصاصی (React / Node.js)',
    opt4: 'پورتفولیو و وب‌سایت شخصی',
    opt5: 'سئو و بهینه‌سازی سرعت تخصصی',
    opt6: 'پشتیبانی و بازطراحی وب‌سایت موجود',

    // Contact
    contactBadge: 'ارتباط مستقیم با محمد رضا فتح آبادی',
    contactHeading: 'راه‌های ارتباطی با izatesweb',
    contactSubheading: 'جهت دریافت مشاوره رایگان، استعلام قیمت پروژه‌ها یا برنامه‌ریزی جلسات کاری می‌توانید با ما در ارتباط باشید.',
    contact1Title: 'شماره تماس مستقیم',
    contact1Value: '0992 175 8505',
    contact1Sub: 'پاسخگویی روزهای کاری ۹ الی ۲۰',
    contact2Title: 'ایمیل پشتیبانی و مکاتبات',
    contact2Sub: 'ارسال پروپوزال و نیازمندی‌ها',
    contact3Title: 'دفتر کاری و آدرس',
    contact3Value: 'تهران، تهران',
    contact3Sub: 'امکان هماهنگی جلسات حضوری',
    bannerBadge: 'پاسخگویی سریع در تلگرام و ایتا',
    bannerTitle: 'نیاز به پاسخ فوری یا مشاوره تلفنی دارید؟',
    bannerDesc: 'همین الان پیام دهید یا با شماره 09921758505 تماس بگیرید.',
    directCallBtn: 'تماس تلفنی مستقیم',
    telegramMsgBtn: 'ارسال پیام در تلگرام',

    // Footer
    footerSubtitle: 'طراحی سایت وردپرسی و اختصاصی — محمد رضا فتح آبادی',
    footerDesc: 'طراحی و راه اندازی انواع وب‌سایت‌های مدرن، لوکس و بهینه‌سازی شده برای گوگل با بالاترین استانداردها و پشتیبانی ۲۴ ساعته.',
    quickLinks: 'دسترسی سریع',
    contactInfo: 'اطلاعات تماس',
    copyright: 'تمامی حقوق متعلق به محمد رضا فتح آبادی می‌باشد.',
    backToTop: 'بازگشت به بالا',
  },
  en: {
    // Brand & General
    brandName: 'izatesweb',
    designerName: 'Mohammad Reza Fathabadi',
    officialBadge: 'Official izatesweb Brand — Quality Without Compromise',
    
    // Nav
    navHome: 'Home',
    navAbout: 'About Me',
    navProjects: 'Portfolio',
    navTeam: 'Team',
    navOrder: 'Order Project',
    navContact: 'Contact Us',
    adminLogin: 'Admin Login',
    adminPanel: 'Admin Panel',
    backToSite: 'Back to Site',
    adminMobile: 'Admin',
    siteMobile: 'Site',
    callNow: 'Direct Call',
    orderProjectHeader: 'Order a New Project',

    // Hero
    title1: 'Custom & WordPress Web Designer',
    title2: 'Speed & SEO Optimization Specialist',
    title3: 'Luxury Corporate & E-Commerce Web Design',
    title4: 'Frontend & Web Platform Developer',
    heroDesc: 'Design and development of powerful, super-fast, and standardized websites using custom WordPress and modern coding. Turn your ideas into luxury, high-converting digital platforms.',
    heroOrderBtn: 'Order a Project',
    heroProjectsBtn: 'View Portfolio',
    botBanner: 'Talk to izatesweb live AI Robot Assistant!',
    stat1Label: 'Successful Projects',
    stat2Label: 'Years Experience',
    stat3Label: 'Client Satisfaction',
    stat4Label: 'Google Speed Score',

    // About
    aboutBadge: 'About izatesweb',
    aboutHeading: 'About Mohammad Reza Fathabadi',
    aboutSubheading: 'Senior web designer and developer aiming to create modern, fast, and efficient websites that make your business stand out in the digital space.',
    aboutBioTitle: 'Crafting Beauty, Speed, and Growth in the Digital World',
    aboutBio1: 'I am Mohammad Reza Fathabadi. With over 5 years of experience in custom WordPress design and full-stack web development, I help brands establish a brilliant, high-converting online presence.',
    aboutBio2: 'At izatesweb, we believe a website is not just a page on the internet; it is your main storefront and sales engine. That is why every project is built with top coding standards, robust security, full responsiveness, and blazing fast loading speed.',
    aboutReadyTitle: 'Available for New Projects',
    aboutReadySub: 'Professional Custom & WordPress Web Design',
    aboutCheck1: 'GTmetrix High Speed Score Guarantee',
    aboutCheck2: '100% Mobile & Tablet Responsive',
    aboutCheck3: 'On-time Delivery According to Schedule',
    aboutCheck4: 'Free Technical Support & Expert Advice',
    feat1Title: 'Optimized Custom WordPress',
    feat1Desc: 'Clean, plugin-light code to achieve maximum speed, stability, and high security.',
    feat2Title: 'Modern & Attractive UI/UX',
    feat2Desc: 'Eye-catching user interface designed with color psychology and modern UI/UX principles to convert visitors.',
    feat3Title: 'Google Rank-1 Ready Technical SEO',
    feat3Desc: 'Technical web structure fully aligned with Google algorithms, Schema markup, and advanced meta tags.',
    feat4Title: 'Full Technical & Educational Support',
    feat4Desc: 'Complete video training for website administration along with direct technical support after project handover.',

    // Projects
    projectsBadge: 'izatesweb Showcase',
    projectsHeading: 'Latest Completed Projects & Portfolio',
    projectsSubheading: 'A showcase of top custom and WordPress websites crafted by Mohammad Reza Fathabadi with the highest quality and client satisfaction.',
    catAll: 'All',
    catWordPress: 'WordPress',
    catStore: 'E-Commerce',
    catCorporate: 'Corporate',
    catCustom: 'Custom Code',
    noProjectsFound: 'No projects found in this category.',
    detailsBtn: 'Details',
    liveDemoBtn: 'Live Demo',
    categoryLabel: 'Category:',
    techUsedLabel: 'Technologies Used:',
    closeBtn: 'Close',
    visitLiveSite: 'Visit Live Site',

    // Team
    teamBadge: 'izatesweb Experts',
    teamHeading: 'Our Passionate & Professional Team',
    teamSubheading: 'izatesweb team members comprising designers, developers, and SEO specialists led by Mohammad Reza Fathabadi.',

    // Order Form
    orderBadge: 'Free Price Quote & Consultation',
    orderHeading: 'Order Your Project Online with izatesweb',
    orderSubheading: 'Fill out the form below to receive a technical proposal, timeline, and cost estimate for your website.',
    orderHilite1Title: 'Pre-project Technical Consultation',
    orderHilite1Desc: 'Needs analysis and matching the best technology to your budget',
    orderHilite2Title: 'Quality Guarantee & Support',
    orderHilite2Desc: 'Full post-handover technical support & free management dashboard training',
    formTitle: 'Project Request Form',
    fullNameLabel: 'Full Name',
    fullNamePlaceholder: 'e.g., John Doe',
    phoneLabel: 'Mobile / WhatsApp Number',
    phonePlaceholder: '+98 992 175 8505',
    projectTypeLabel: 'Select Project Type',
    projectDescLabel: 'Project Details & Required Features',
    projectDescPlaceholder: 'Write a brief summary of your business, required features, and ideas...',
    submitOrderBtn: 'Submit Project Request',
    submittingText: 'Submitting request...',
    successOrderMsg: 'Your order was successfully registered! Mohammad Reza Fathabadi will contact you shortly.',
    requiredFieldError: 'Please fill in your name, contact number, and project description.',
    networkError: 'Server communication error. Please check your internet connection.',
    opt1: 'WordPress E-Commerce Store',
    opt2: 'Corporate & Business Portal',
    opt3: 'Custom Web Application (React / Node.js)',
    opt4: 'Personal Portfolio & Brand Page',
    opt5: 'Technical SEO & Speed Optimization',
    opt6: 'Website Redesign & Maintenance',

    // Contact
    contactBadge: 'Direct Contact with Mohammad Reza Fathabadi',
    contactHeading: 'Get in Touch with izatesweb',
    contactSubheading: 'Reach out to us for free advice, project quotes, or scheduling business meetings.',
    contact1Title: 'Direct Phone Number',
    contact1Value: '+98 992 175 8505',
    contact1Sub: 'Available Mon-Sat 9 AM - 8 PM',
    contact2Title: 'Support & Official Email',
    contact2Sub: 'Send proposals & project specs',
    contact3Title: 'Office & Location',
    contact3Value: 'Tehran, Iran',
    contact3Sub: 'In-person meetings by appointment',
    bannerBadge: 'Fast Response on Messaging Platforms',
    bannerTitle: 'Need an instant answer or phone consultation?',
    bannerDesc: 'Message us right now on Telegram or call +98 992 175 8505.',
    directCallBtn: 'Direct Phone Call',
    telegramMsgBtn: 'Send Telegram Message',

    // Footer
    footerSubtitle: 'WordPress & Custom Web Design — Mohammad Reza Fathabadi',
    footerDesc: 'Designing and launching modern, luxury websites optimized for Google with the highest standards and 24/7 support.',
    quickLinks: 'Quick Links',
    contactInfo: 'Contact Information',
    copyright: 'All rights reserved by Mohammad Reza Fathabadi.',
    backToTop: 'Back to Top',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('izatesweb_lang');
    return (saved === 'en' || saved === 'fa') ? saved : 'fa';
  });

  const direction: 'rtl' | 'ltr' = language === 'fa' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = direction;
    localStorage.setItem('izatesweb_lang', language);
  }, [language, direction]);

  const toggleLanguage = () => {
    setLanguageState((prev) => (prev === 'fa' ? 'en' : 'fa'));
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): string => {
    if (translations[language] && translations[language][key]) {
      return translations[language][key];
    }
    if (translations.fa[key]) {
      return translations.fa[key];
    }
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, direction, toggleLanguage, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
