import React, { createContext, useContext, useState, useEffect } from 'react';
import { SiteColorsMap } from '../types';

interface ColorContextType {
  colors: SiteColorsMap;
  loading: boolean;
  updateColors: (newColors: SiteColorsMap) => Promise<boolean>;
  resetColors: () => Promise<boolean>;
  refreshColors: () => Promise<void>;
}

export const DEFAULT_COLOR_VALUES: SiteColorsMap = {
  'Background': '#0A0A0F',
  'Surface': '#12121A',
  'Navbar': 'rgba(18, 18, 26, 0.85)',
  'Primary Text': '#F8FAFC',
  'Secondary Text': '#CBD5E1',
  'Muted Text': '#64748B',
  'Primary Accent': '#C9A84C',
  'Hover Accent': '#E2BF5F',
  'Border': '#222232',
  'Success': '#10B981',
  'Error': '#EF4444',
};

export const applyCssVariables = (colorMap: SiteColorsMap) => {
  const root = document.documentElement;
  const bg = colorMap['Background'] || '#0A0A0F';
  if (colorMap['Background']) root.style.setProperty('--color-background', colorMap['Background']);
  if (colorMap['Surface']) root.style.setProperty('--color-surface', colorMap['Surface']);
  if (colorMap['Navbar']) root.style.setProperty('--color-navbar', colorMap['Navbar']);
  if (colorMap['Primary Text']) root.style.setProperty('--color-text-primary', colorMap['Primary Text']);
  if (colorMap['Secondary Text']) root.style.setProperty('--color-text-secondary', colorMap['Secondary Text']);
  if (colorMap['Muted Text']) root.style.setProperty('--color-text-muted', colorMap['Muted Text']);
  if (colorMap['Primary Accent']) root.style.setProperty('--color-accent-primary', colorMap['Primary Accent']);
  if (colorMap['Hover Accent']) root.style.setProperty('--color-accent-hover', colorMap['Hover Accent']);
  if (colorMap['Border']) root.style.setProperty('--color-border', colorMap['Border']);
  if (colorMap['Success']) root.style.setProperty('--color-success', colorMap['Success']);
  if (colorMap['Error']) root.style.setProperty('--color-error', colorMap['Error']);

  // Dynamically update browser toolbar & address bar colors (Chrome, Safari iOS, Android)
  if (typeof document !== 'undefined') {
    const metaTags = ['theme-color', 'msapplication-navbutton-color', 'msapplication-TileColor'];
    metaTags.forEach(name => {
      let meta = document.querySelector(`meta[name="${name}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute('name', name);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', bg);
    });
  }
};

const ColorContext = createContext<ColorContextType>({
  colors: DEFAULT_COLOR_VALUES,
  loading: true,
  updateColors: async () => false,
  resetColors: async () => false,
  refreshColors: async () => {},
});

export const ColorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [colors, setColors] = useState<SiteColorsMap>(DEFAULT_COLOR_VALUES);
  const [loading, setLoading] = useState(true);

  const fetchColors = async () => {
    try {
      const res = await fetch('/api/colors');
      if (res.ok) {
        const data = await res.json();
        setColors(data);
        applyCssVariables(data);
      } else {
        applyCssVariables(DEFAULT_COLOR_VALUES);
      }
    } catch (err) {
      console.warn('Failed to fetch site colors, using default palette.', err);
      applyCssVariables(DEFAULT_COLOR_VALUES);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchColors();
  }, []);

  const updateColors = async (newColors: SiteColorsMap): Promise<boolean> => {
    const token = localStorage.getItem('izatesweb_admin_token');
    try {
      const res = await fetch('/api/colors', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newColors)
      });
      if (res.ok) {
        setColors(newColors);
        applyCssVariables(newColors);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to update site colors:', err);
      return false;
    }
  };

  const resetColors = async (): Promise<boolean> => {
    const token = localStorage.getItem('izatesweb_admin_token');
    try {
      const res = await fetch('/api/colors/reset', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        setColors(DEFAULT_COLOR_VALUES);
        applyCssVariables(DEFAULT_COLOR_VALUES);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to reset site colors:', err);
      return false;
    }
  };

  return (
    <ColorContext.Provider value={{ colors, loading, updateColors, resetColors, refreshColors: fetchColors }}>
      {children}
    </ColorContext.Provider>
  );
};

export const useColors = () => useContext(ColorContext);
