import React, { createContext, useContext, useState, useEffect } from 'react';

interface AuthContextType {
  token: string | null;
  username: string | null;
  isAuthenticated: boolean;
  login: (token: string, username: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  token: null,
  username: null,
  isAuthenticated: false,
  login: () => {},
  logout: () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(localStorage.getItem('izatesweb_admin_token'));
  const [username, setUsername] = useState<string | null>(localStorage.getItem('izatesweb_admin_username'));

  useEffect(() => {
    if (token) {
      // Validate token with backend
      fetch('/api/admin/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      .then(res => {
        if (!res.ok) {
          logout();
        }
      })
      .catch(() => {
        // Network or error
      });
    }
  }, [token]);

  const login = (newToken: string, newUsername: string) => {
    localStorage.setItem('izatesweb_admin_token', newToken);
    localStorage.setItem('izatesweb_admin_username', newUsername);
    setToken(newToken);
    setUsername(newUsername);
  };

  const logout = () => {
    localStorage.removeItem('izatesweb_admin_token');
    localStorage.removeItem('izatesweb_admin_username');
    setToken(null);
    setUsername(null);
  };

  return (
    <AuthContext.Provider value={{ token, username, isAuthenticated: !!token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
