export interface Project {
  id: number;
  title: string;
  category: string;
  description: string;
  image_url: string;
  link: string | null;
  tags: string;
  created_at?: string;
}

export interface TeamMember {
  id: number;
  name: string;
  role: string;
  image_url: string;
  socials_json: string;
  created_at?: string;
}

export interface ContactMessage {
  id: number;
  name: string;
  phone: string;
  project_type: string;
  description: string;
  is_read: number;
  created_at?: string;
}

export interface SiteColorsMap {
  'Background': string;
  'Surface': string;
  'Navbar': string;
  'Primary Text': string;
  'Secondary Text': string;
  'Muted Text': string;
  'Primary Accent': string;
  'Hover Accent': string;
  'Border': string;
  'Success': string;
  'Error': string;
  [key: string]: string;
}

export interface AdminUser {
  id?: number;
  username: string;
}
