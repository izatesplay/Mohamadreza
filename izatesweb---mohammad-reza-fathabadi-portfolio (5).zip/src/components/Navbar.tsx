import React, { useState, useEffect } from 'react';
import { Menu, X, Code, Phone, Shield, ArrowUpLeft, Sparkles, Globe } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

interface NavbarProps {
  onOpenAdmin: () => void;
  isAdminOpen: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAdmin, isAdminOpen }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isAuthenticated } = useAuth();
  const { language, toggleLanguage, t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: t('navHome'), href: '#hero' },
    { name: t('navAbout'), href: '#about' },
    { name: t('navProjects'), href: '#projects' },
    { name: t('navTeam'), href: '#team' },
    { name: t('navOrder'), href: '#order' },
    { name: t('navContact'), href: '#contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    if (isAdminOpen) {
      onOpenAdmin(); // Close admin panel if currently open
    }
    const targetEl = document.querySelector(href);
    if (targetEl) {
      targetEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'py-3 bg-[var(--color-navbar)] backdrop-blur-md border-b border-[var(--color-border)] shadow-2xl shadow-black/50' 
        : 'py-5 bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo */}
          <a 
            href="#hero" 
            onClick={(e) => handleNavClick(e, '#hero')}
            className="flex items-center gap-3 group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[var(--color-accent-primary)] to-[#7C3AED] p-[1px] shadow-lg shadow-[var(--color-accent-primary)]/20 transition-transform duration-300 group-hover:scale-105">
              <div className="w-full h-full bg-[var(--color-background)] rounded-[11px] flex items-center justify-center">
                <Code className="w-5 h-5 text-[var(--color-accent-primary)]" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-tight text-gold-gradient">
                {t('brandName')}
              </span>
              <span className="text-[10px] text-[var(--color-text-muted)] font-medium tracking-wide">
                {t('designerName')}
              </span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-1 bg-[var(--color-surface)]/80 p-1.5 rounded-full border border-[var(--color-border)] backdrop-blur-sm shadow-inner">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-4 py-2 text-sm font-medium text-[var(--color-text-secondary)] hover:text-[var(--color-accent-primary)] rounded-full transition-colors duration-200 hover:bg-white/5"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Action Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Language Toggle */}
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-[var(--color-surface)] text-[var(--color-text-primary)] border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/50 hover:text-[var(--color-accent-primary)] transition-all shadow-sm cursor-pointer"
              title={language === 'fa' ? 'Switch to English' : 'تغییر به زبان فارسی'}
            >
              <Globe className="w-3.5 h-3.5 text-[var(--color-accent-primary)]" />
              <span className="uppercase tracking-wider">{language === 'fa' ? 'English' : 'فارسی'}</span>
            </button>

            <a
              href="tel:09921758505"
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold bg-[var(--color-surface)] text-[var(--color-text-primary)] border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/50 hover:text-[var(--color-accent-primary)] transition-all duration-300 shadow-sm"
            >
              <Phone className="w-4 h-4 text-[var(--color-accent-primary)]" />
              <span dir="ltr">0992 175 8505</span>
            </a>

            <button
              onClick={onOpenAdmin}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-300 ${
                isAdminOpen 
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' 
                  : 'bg-gradient-to-r from-[var(--color-accent-primary)] to-[var(--color-accent-hover)] text-[var(--color-background)] hover:shadow-lg hover:shadow-[var(--color-accent-primary)]/25 hover:scale-[1.02]'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>{isAdminOpen ? t('backToSite') : isAuthenticated ? t('adminPanel') : t('adminLogin')}</span>
            </button>
          </div>

          {/* Mobile Menu Actions */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={toggleLanguage}
              className="p-2 rounded-lg bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-accent-primary)] text-xs font-bold flex items-center gap-1"
              title={language === 'fa' ? 'Switch to English' : 'تغییر به فارسی'}
            >
              <Globe className="w-4 h-4" />
              <span className="uppercase text-[11px]">{language === 'fa' ? 'EN' : 'FA'}</span>
            </button>

            <button
              onClick={onOpenAdmin}
              className="p-2 rounded-lg bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-accent-primary)] text-xs font-semibold flex items-center gap-1"
              title="پنل مدیریت"
            >
              <Shield className="w-4 h-4" />
              <span>{isAdminOpen ? t('siteMobile') : t('adminMobile')}</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text-primary)] hover:text-[var(--color-accent-primary)] transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[var(--color-surface)]/95 border-b border-[var(--color-border)] backdrop-blur-xl px-4 pt-4 pb-6 mt-3 shadow-2xl transition-all">
          <div className="flex flex-col gap-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-4 py-3 rounded-xl text-base font-medium text-[var(--color-text-secondary)] hover:bg-white/5 hover:text-[var(--color-accent-primary)] transition-colors flex items-center justify-between"
              >
                <span>{link.name}</span>
                <ArrowUpLeft className="w-4 h-4 text-[var(--color-text-muted)]" />
              </a>
            ))}

            <div className="pt-4 mt-2 border-t border-[var(--color-border)] flex flex-col gap-3">
              <a
                href="tel:09921758505"
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-[var(--color-background)] border border-[var(--color-border)] text-[var(--color-accent-primary)] font-semibold text-sm"
              >
                <Phone className="w-4 h-4" />
                <span>{t('callNow')}: 0992 175 8505</span>
              </a>

              <a
                href="#order"
                onClick={(e) => handleNavClick(e, '#order')}
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[var(--color-accent-primary)] to-[var(--color-accent-hover)] text-[var(--color-background)] font-bold text-sm shadow-lg shadow-[var(--color-accent-primary)]/20"
              >
                <Sparkles className="w-4 h-4" />
                <span>{t('orderProjectHeader')}</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
