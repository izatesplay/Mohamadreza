import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Zap, Code, Layout, Cpu, CheckCircle, Search, Rocket, Lock } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const About: React.FC = () => {
  const { t } = useLanguage();

  const features = [
    {
      title: t('feat1Title'),
      description: t('feat1Desc'),
      icon: Cpu,
    },
    {
      title: t('feat2Title'),
      description: t('feat2Desc'),
      icon: Layout,
    },
    {
      title: t('feat3Title'),
      description: t('feat3Desc'),
      icon: Search,
    },
    {
      title: t('feat4Title'),
      description: t('feat4Desc'),
      icon: ShieldCheck,
    },
  ];

  const checkItems = [
    t('aboutCheck1'),
    t('aboutCheck2'),
    t('aboutCheck3'),
    t('aboutCheck4'),
  ];

  return (
    <section id="about" className="py-24 relative bg-[var(--color-surface)]/60 border-y border-[var(--color-border)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="text-xs sm:text-sm font-bold text-[var(--color-accent-primary)] uppercase tracking-widest bg-[var(--color-accent-primary)]/10 px-3.5 py-1.5 rounded-full border border-[var(--color-accent-primary)]/20 inline-block mb-3">
            {t('aboutBadge')}
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[var(--color-text-primary)] tracking-tight">
            {t('aboutHeading')}
          </h2>
          <p className="mt-4 text-[var(--color-text-muted)] text-base sm:text-lg leading-relaxed">
            {t('aboutSubheading')}
          </p>
        </motion.div>

        {/* Top Info & Bio Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-20">
          
          {/* Avatar / Brand Graphic */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative mx-auto max-w-md">
              <div className="absolute -inset-2 bg-gradient-to-tr from-[var(--color-accent-primary)] to-[#7C3AED] rounded-3xl blur-xl opacity-30 animate-pulse" />
              <div className="relative glass-panel rounded-3xl p-4 overflow-hidden border border-[var(--color-border)]">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=800&auto=format&fit=crop"
                  alt={t('aboutHeading')}
                  className="w-full h-[420px] object-cover rounded-2xl shadow-2xl filter brightness-95"
                />
                <div className="absolute bottom-8 right-8 left-8 glass-panel p-4 rounded-xl border border-white/10 backdrop-blur-md">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
                    <div>
                      <h4 className="text-[var(--color-text-primary)] font-bold text-sm">{t('aboutReadyTitle')}</h4>
                      <p className="text-[var(--color-text-muted)] text-xs">{t('aboutReadySub')}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Bio Text & Story */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-7 flex flex-col justify-center space-y-6"
          >
            <h3 className="text-2xl sm:text-3xl font-black text-[var(--color-text-primary)] leading-snug">
              {t('aboutBioTitle')}
            </h3>

            <p className="text-[var(--color-text-secondary)] leading-relaxed font-light text-base sm:text-lg">
              {t('aboutBio1')}
            </p>

            <p className="text-[var(--color-text-muted)] leading-relaxed text-sm sm:text-base">
              {t('aboutBio2')}
            </p>

            {/* Quick Skill Tags */}
            <div dir="ltr" className="pt-2 flex flex-wrap gap-2 justify-start">
              {['WordPress', 'WooCommerce', 'Elementor Pro', 'PHP', 'React.js', 'Node.js', 'Tailwind CSS', 'MySQL', 'UI/UX Design', 'SEO & Speed'].map((tag) => (
                <span
                  key={tag}
                  dir="ltr"
                  className="px-3 py-1.5 rounded-lg bg-[var(--color-background)] text-[var(--color-accent-primary)] border border-[var(--color-border)] text-xs font-mono font-semibold hover:border-[var(--color-accent-primary)]/50 transition-colors"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-[var(--color-border)]">
              {checkItems.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2.5 text-[var(--color-text-secondary)] text-sm font-medium">
                  <CheckCircle className="w-4 h-4 text-[var(--color-accent-primary)] shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>

          </motion.div>

        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-30px' }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="glass-card p-6 rounded-2xl border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/40 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-[var(--color-accent-primary)]/10 border border-[var(--color-accent-primary)]/20 flex items-center justify-center text-[var(--color-accent-primary)] mb-4">
                  <Icon className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-[var(--color-text-primary)] mb-2">{feat.title}</h4>
                <p className="text-[var(--color-text-muted)] text-xs sm:text-sm leading-relaxed">{feat.description}</p>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
