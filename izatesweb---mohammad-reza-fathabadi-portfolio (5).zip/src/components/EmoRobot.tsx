import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Send,
  Sparkles,
  Smile,
  Frown,
  Bot,
  Flame,
  Zap,
  MessageSquare,
  HelpCircle,
  Play,
  RotateCcw,
  Heart
} from 'lucide-react';

export type EmoEmotion = 'happy' | 'angry' | 'surprised' | 'thinking' | 'proud' | 'speaking' | 'sleepy';

interface EmoRobotProps {
  className?: string;
}

export const EmoRobot: React.FC<EmoRobotProps> = ({ className = '' }) => {
  const [emotion, setEmotion] = useState<EmoEmotion>('happy');
  const [currentSpeech, setCurrentSpeech] = useState<string>(
    'سلام دوست من! من ایمو (EMO) هستم، ربات هوشمند محمدرضا فتح‌آبادی! آماده‌ام به هر سوالی که داری جواب بدم! 🤖✨'
  );
  const [inputMessage, setInputMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isPetting, setIsPetting] = useState<boolean>(false);
  const [isDancing, setIsDancing] = useState<boolean>(false);

  // Audio & Speech References
  const recognitionRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioUnlockedRef = useRef<boolean>(false);
  const transcriptRef = useRef<string>('');
  const hasSentRef = useRef<boolean>(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);

  const [hasAutoplayBlocked, setHasAutoplayBlocked] = useState<boolean>(false);
  const pendingGreetingRef = useRef<string | null>(null);

  // Unlock mobile browser audio context on user gesture & play pending greeting if blocked
  const unlockAudio = () => {
    if (audioUnlockedRef.current) return;
    audioUnlockedRef.current = true;
    try {
      if (!audioRef.current) {
        audioRef.current = new Audio();
      }
      const silentAudio = new Audio('data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=');
      silentAudio.play().catch(() => {});
      if ('speechSynthesis' in window) {
        window.speechSynthesis.getVoices();
      }
    } catch (e) {}

    // If initial greeting was blocked by browser autoplay policy, play it immediately on user's first gesture!
    if (pendingGreetingRef.current) {
      const msgToPlay = pendingGreetingRef.current;
      pendingGreetingRef.current = null;
      setHasAutoplayBlocked(false);
      setTimeout(() => {
        speakText(msgToPlay);
      }, 100);
    }
  };

  // Attach global unlock listener once
  useEffect(() => {
    const handleGesture = () => unlockAudio();
    window.addEventListener('click', handleGesture, { once: true });
    window.addEventListener('touchstart', handleGesture, { once: true });
    window.addEventListener('pointerdown', handleGesture, { once: true });
    window.addEventListener('scroll', handleGesture, { once: true });
    window.addEventListener('keydown', handleGesture, { once: true });
    return () => {
      window.removeEventListener('click', handleGesture);
      window.removeEventListener('touchstart', handleGesture);
      window.removeEventListener('pointerdown', handleGesture);
      window.removeEventListener('scroll', handleGesture);
      window.removeEventListener('keydown', handleGesture);
    };
  }, []);

  // Direct Persian Audio Fallback (Google Translate Persian Voice Stream)
  const playDirectPersianAudioFallback = (cleanText: string) => {
    if (isMuted || !cleanText) {
      setIsPlayingAudio(false);
      setEmotion('happy');
      return;
    }

    try {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }

      const truncated = cleanText.slice(0, 150);
      const fallbackUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(truncated)}&tl=fa&client=tw-ob`;
      const audio = new Audio(fallbackUrl);
      audioRef.current = audio;

      audio.onplay = () => {
        setIsPlayingAudio(true);
        setEmotion('speaking');
        setHasAutoplayBlocked(false);
      };

      audio.onended = () => {
        setIsPlayingAudio(false);
        setEmotion('happy');
      };

      audio.onerror = () => {
        playWebSpeechFallback(cleanText);
      };

      const p = audio.play();
      if (p !== undefined) {
        p.catch((err) => {
          if (err && (err.name === 'NotAllowedError' || err.message?.includes('user didn\'t interact'))) {
            pendingGreetingRef.current = cleanText;
            setHasAutoplayBlocked(true);
            setIsPlayingAudio(false);
            setEmotion('happy');
          } else {
            playWebSpeechFallback(cleanText);
          }
        });
      }
    } catch (e) {
      playWebSpeechFallback(cleanText);
    }
  };

  // Web Speech Fallback Function (Browser Native Speech)
  const playWebSpeechFallback = (cleanText: string) => {
    if (!('speechSynthesis' in window) || isMuted) {
      setIsPlayingAudio(false);
      setEmotion('happy');
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = 'fa-IR';
      utterance.rate = 1.0;
      utterance.pitch = 1.0;

      const speakNow = () => {
        const voices = window.speechSynthesis.getVoices() || [];
        const faVoice = voices.find(v => 
          v.lang.toLowerCase().includes('fa') || 
          v.name.toLowerCase().includes('persian') || 
          v.name.toLowerCase().includes('farsi') ||
          v.lang.toLowerCase().startsWith('fa')
        );

        if (faVoice) {
          utterance.voice = faVoice;
        } else if (voices.length > 0) {
          utterance.voice = voices[0];
        }

        utterance.onstart = () => {
          setIsPlayingAudio(true);
          setEmotion('speaking');
          setHasAutoplayBlocked(false);
        };

        utterance.onend = () => {
          setIsPlayingAudio(false);
          setEmotion('happy');
        };

        utterance.onerror = () => {
          setIsPlayingAudio(false);
          setEmotion('happy');
        };

        window.speechSynthesis.speak(utterance);
        setIsPlayingAudio(true);
        setEmotion('speaking');
        setHasAutoplayBlocked(false);
      };

      if (window.speechSynthesis.getVoices().length === 0) {
        window.speechSynthesis.onvoiceschanged = () => {
          speakNow();
          window.speechSynthesis.onvoiceschanged = null;
        };
      } else {
        speakNow();
      }
    } catch (e) {
      setIsPlayingAudio(false);
      setEmotion('happy');
    }
  };

  // Persian Speech Synthesis Function using high-quality server audio + Web Speech fallback
  const speakText = (text: string) => {
    if (isMuted) return;

    unlockAudio();

    // Cancel any previous Web Speech synthesis
    if ('speechSynthesis' in window) {
      try { window.speechSynthesis.cancel(); } catch (e) {}
    }

    // Stop previous HTML5 audio
    if (audioRef.current) {
      try {
        audioRef.current.pause();
        audioRef.current = null;
      } catch (e) {}
    }

    // Clean text and transliterate terms and numbers for smooth Persian pronunciation
    const cleanText = text
      .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}]/gu, '')
      .replace(/[\!\?\#\*\_\~\@\$\%\^\&\(\)\{\}\[\]\<\>\:\;\=\+\-\/]/g, ' ')
      .replace(/GTmetrix/gi, 'جی تی متریکس')
      .replace(/izatesweb/gi, 'ایزاتس وب')
      .replace(/izates/gi, 'ایزاتس')
      .replace(/EMO/gi, 'ایمو')
      .replace(/WordPress/gi, 'وردپرس')
      .replace(/React/gi, 'ری اکت')
      .replace(/Python/gi, 'پایتون')
      .replace(/JavaScript/gi, 'جاوا اسکریپت')
      .replace(/Node\.js/gi, 'نود جی اس')
      .replace(/PHP/gi, 'پی اچ پی')
      .replace(/Tailwind/gi, 'تیل ویند')
      .replace(/CSS/gi, 'سی اس اس')
      .replace(/HTML/gi, 'اچ تی ام ال')
      .replace(/100/g, 'صد')
      .replace(/5/g, 'پنج')
      .replace(/1/g, 'یک')
      .replace(/2/g, 'دو')
      .replace(/3/g, 'سه')
      .replace(/4/g, 'چهار')
      .replace(/6/g, 'شش')
      .replace(/7/g, 'هفت')
      .replace(/8/g, 'هشت')
      .replace(/9/g, 'نه')
      .replace(/0/g, 'صفر')
      .replace(/[a-zA-Z]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanText) return;

    // Immediately trigger speaking UI state
    setIsPlayingAudio(true);
    setEmotion('speaking');

    // Load server-side Persian audio generated by ElevenLabs / Gemini / SoundOfText
    const ttsUrl = `/api/tts?text=${encodeURIComponent(cleanText)}`;
    const audio = new Audio(ttsUrl);
    audioRef.current = audio;

    const handleFinish = () => {
      setIsPlayingAudio(false);
      setEmotion('happy');
    };

    const handleError = () => {
      playWebSpeechFallback(cleanText);
    };

    audio.onplay = () => {
      setIsPlayingAudio(true);
      setEmotion('speaking');
      setHasAutoplayBlocked(false);
      try {
        audio.playbackRate = 1.03;
      } catch (e) {}
    };

    audio.onended = handleFinish;
    audio.onerror = handleError;

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch((err) => {
        console.warn('HTML5 Audio play catch:', err);
        if (err && (err.name === 'NotAllowedError' || err.message?.includes('user didn\'t interact'))) {
          pendingGreetingRef.current = cleanText;
          setHasAutoplayBlocked(true);
          setIsPlayingAudio(false);
          setEmotion('happy');
        } else {
          handleError();
        }
      });
    }
  };

  // Fetch public bot settings & Speak initial greeting once on mount
  useEffect(() => {
    let greetingMsg = 'سلام دوست من! من ایمو هستم، ربات هوشمند ایزاتس‌وب!';
    
    fetch('/api/emo/config')
      .then(res => {
        const ct = res.headers.get('content-type');
        if (res.ok && ct && ct.includes('application/json')) {
          return res.json();
        }
        return null;
      })
      .then(data => {
        if (data && data.customGreeting) {
          greetingMsg = data.customGreeting;
          setCurrentSpeech(greetingMsg);
        }
      })
      .catch(() => {});

    const timer = setTimeout(() => {
      speakText(greetingMsg);
    }, 1200);

    return () => {
      clearTimeout(timer);
      if (audioRef.current) {
        audioRef.current.pause();
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Local fallback responder when server API is unreachable or fails
  const getLocalFallbackReply = (message: string): { reply: string; emotion: EmoEmotion } => {
    const text = message.toLowerCase();
    if (text.includes('محمدرضا') || text.includes('فتح آبادی') || text.includes('سازنده') || text.includes('کیه')) {
      return {
        reply: 'محمدرضا فتح‌آبادی سازنده من و مدیر ایزاتس‌وب است! ۵+ سال سابقه طراحی سایت وردپرسی و کدنویسی اختصاصی داره! 😎✨',
        emotion: 'proud'
      };
    }
    if (text.includes('خدمات') || text.includes('قیمت') || text.includes('سفارش') || text.includes('سایت') || text.includes('ایزاتس')) {
      return {
        reply: 'در ایزاتس‌وب طراحی سایت اختصاصی، وردپرس باکیفیت، سئو و بهینه‌سازی سرعت ۱۰۰ GTmetrix ارائه میدیم! همین الان سفارش بده! 🚀',
        emotion: 'happy'
      };
    }
    if (text.includes('پایتون') || text.includes('جاوااسکریپت') || text.includes('زبان')) {
      return {
        reply: 'پایتون برای هوش مصنوعی عالیه ولی جاوااسکریپت سلطان فرانت‌اند و وبه! محمدرضا در هردوشون استاد است! 💻',
        emotion: 'thinking'
      };
    }
    if (text.includes('لطیفه') || text.includes('جوک') || text.includes('خنده') || text.includes('بامزه')) {
      return {
        reply: 'چرا برنامه‌نویس‌ها دوست ندارن برن بیرون؟ چون دنیای واقعی باگ‌های زیادی داره و کامپایل نمیشه! 🤣🤖',
        emotion: 'happy'
      };
    }
    if (text.includes('وردپرس') || text.includes('کد')) {
      return {
        reply: 'وردپرس اختصاصی برای راه‌اندازی سریع و اقتصادی عالیه و ری‌اکت برای پروژه‌های با ترافیک سنگین! ما هر دو رو حرفه‌ای می‌سازیم! ⚡',
        emotion: 'happy'
      };
    }
    return {
      reply: `پیام زیبای شما دریافت شد! من ایمو (EMO) هستم. برای مشاوره تخصصی می‌توانید با محمدرضا فتح‌آبادی در ارتباط باشید! 🤖✨`,
      emotion: 'happy'
    };
  };

  // Handle Send Message to Backend
  const handleSendMessage = async (customMessage?: string) => {
    unlockAudio();
    const msgToSend = customMessage || inputMessage;
    if (!msgToSend.trim() || isLoading) return;

    setInputMessage('');
    setIsLoading(true);
    setEmotion('thinking');

    try {
      const res = await fetch('/api/emo-bot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msgToSend })
      });

      if (res.ok) {
        const data = await res.json();
        if (data && data.reply) {
          setCurrentSpeech(data.reply);
          const newEmotion: EmoEmotion = data.emotion || 'happy';
          setEmotion(newEmotion);
          speakText(data.reply);
          return;
        }
      }

      // If status not ok or data empty, use smart local engine
      const fallback = getLocalFallbackReply(msgToSend);
      setCurrentSpeech(fallback.reply);
      setEmotion(fallback.emotion);
      speakText(fallback.reply);
    } catch (err) {
      console.warn('Network issue calling emo-bot API, using smart local engine:', err);
      const fallback = getLocalFallbackReply(msgToSend);
      setCurrentSpeech(fallback.reply);
      setEmotion(fallback.emotion);
      speakText(fallback.reply);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Petting EMO
  const handlePet = () => {
    setIsPetting(true);
    setEmotion('happy');
    const petText = 'وای قلقلکم اومد! چقدر مهربونی دوست من! 😊💖';
    setCurrentSpeech(petText);
    speakText(petText);
    setTimeout(() => setIsPetting(false), 2000);
  };

  // Trigger Dance
  const handleDance = () => {
    setIsDancing(true);
    setEmotion('happy');
    const danceText = 'هورااا! وقت رقص رباتیه! ترامپم نمیتونه اینجوری برقصه! 🕺🎶';
    setCurrentSpeech(danceText);
    speakText(danceText);
    setTimeout(() => setIsDancing(false), 4000);
  };

  // Trigger Anger
  const handleAnger = () => {
    setEmotion('angry');
    const angerText = 'الان با لیزر رباتی‌ام کدهاتو باگ‌دار می‌کنمااا! 😠⚡ عصبانیم کردی!';
    setCurrentSpeech(angerText);
    speakText(angerText);
  };

  // Voice Input Setup
  const toggleVoiceInput = async () => {
    unlockAudio();
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      const msg = 'مرورگر شما از قابلیت تشخیص گفتار صوتی پشتیبانی نمی‌کند، لطفاً پیام خود را تایپ فرمایید! 💬';
      setCurrentSpeech(msg);
      speakText(msg);
      return;
    }

    // IF currently listening and user clicks the mic button again to finish & send:
    if (isListening) {
      setIsListening(false);
      setCurrentSpeech('در حال پردازش صدای شما... ⏳');

      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }

      setTimeout(() => {
        const capturedText = (transcriptRef.current || inputMessage).trim();
        if (capturedText && !hasSentRef.current) {
          hasSentRef.current = true;
          setInputMessage(capturedText);
          handleSendMessage(capturedText);
        } else if (!capturedText) {
          const warnMsg = 'صدایی دریافت نشد! دوباره دکمه میکروفون رو بزن و صحبت کن رفیق! 🎙️';
          setCurrentSpeech(warnMsg);
          setEmotion('surprised');
        }
      }, 500);
      return;
    }

    // START listening:
    transcriptRef.current = '';
    hasSentRef.current = false;

    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        await navigator.mediaDevices.getUserMedia({ audio: true }).catch(() => {});
      }

      const recognition = new SpeechRecognition();
      recognition.lang = 'fa-IR';
      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onstart = () => {
        setIsListening(true);
        setEmotion('thinking');
        setCurrentSpeech('گوشام تیز شد! صحبت کن رفیق، دارم صداتو می‌شنوم... 🎤✨');
      };

      recognition.onresult = (event: any) => {
        let textResult = '';
        for (let i = 0; i < event.results.length; i++) {
          if (event.results[i] && event.results[i][0]) {
            textResult += event.results[i][0].transcript + ' ';
          }
        }
        const trimmed = textResult.trim();
        if (trimmed) {
          transcriptRef.current = trimmed;
          setInputMessage(trimmed);
          setCurrentSpeech(`🎤 در حال شنیدن: ${trimmed}`);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'no-speech' || event.error === 'aborted') {
          return;
        }

        setIsListening(false);
        setEmotion('surprised');

        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          const warnMsg = 'دسترسی میکروفون در مرورگر غیرفعال است! لطفاً اجازه دسترسی میکروفون را فعال کنید! 🎤';
          setCurrentSpeech(warnMsg);
          speakText(warnMsg);
        } else {
          const warnMsg = 'متوجه صدات نشدم! دوباره امتحان کن یا پیامت رو تایپ کن! 🤖';
          setCurrentSpeech(warnMsg);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
        setTimeout(() => {
          const capturedText = (transcriptRef.current || inputMessage).trim();
          if (capturedText && !hasSentRef.current) {
            hasSentRef.current = true;
            setInputMessage(capturedText);
            handleSendMessage(capturedText);
          }
        }, 300);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      setIsListening(false);
      setEmotion('surprised');
      console.error('Speech recognition exception:', err);
      const warnMsg = 'دسترسی به میکروفون امکان‌پذیر نشد. لطفاً پیام متنی تایپ کنید. 💬';
      setCurrentSpeech(warnMsg);
      speakText(warnMsg);
    }
  };

  // Quick chips questions
  const quickQuestions = [
    { text: 'محمدرضا فتح‌آبادی کیه؟ 👤', icon: '👤' },
    { text: 'خدمات ایزاتس‌وب چیه؟ 🌐', icon: '🌐' },
    { text: 'پایتون یا جاوااسکریپت؟ 💻', icon: '💻' },
    { text: 'چرا وردپرس اختصاصی؟ 🚀', icon: '🚀' },
    { text: 'یه لطیفه خنده‌دار بگو! 🎭', icon: '🎭' },
  ];

  return (
    <div className={`relative flex flex-col items-center justify-center ${className}`}>
      
      {/* Background Cyber Glowing Stage */}
      <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 via-purple-500/5 to-transparent rounded-3xl blur-2xl pointer-events-none" />

      {/* Main EMO Robot Container Card */}
      <div className="relative w-full max-w-xl bg-[#0B0C14]/90 border border-cyan-500/30 rounded-2xl sm:rounded-3xl p-3 sm:p-6 shadow-2xl shadow-cyan-500/10 backdrop-blur-xl overflow-hidden flex flex-col items-center">
        
        {/* Top Robot Status Bar */}
        <div className="w-full flex items-center justify-between mb-3 sm:mb-4 pb-2.5 sm:pb-3 border-b border-cyan-500/15 text-[11px] sm:text-xs text-slate-400">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <span className="relative flex h-2.5 sm:h-3 w-2.5 sm:w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 sm:h-3 w-2.5 sm:w-3 bg-cyan-500"></span>
            </span>
            <span className="font-bold text-cyan-400 tracking-wider text-[10px] sm:text-xs">EMO DESKTOP AI</span>
            <span className="bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 px-1.5 sm:px-2 py-0.5 rounded text-[9px] sm:text-[10px]">LIVE</span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => {
                setIsMuted(!isMuted);
                if (!isMuted && 'speechSynthesis' in window) window.speechSynthesis.cancel();
              }}
              className={`p-1 sm:p-1.5 rounded-lg border transition-all ${
                isMuted
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                  : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20'
              }`}
              title={isMuted ? 'فعالسازی صدای ربات' : 'قطع صدای ربات'}
            >
              {isMuted ? <VolumeX className="w-3.5 sm:w-4 h-3.5 sm:h-4" /> : <Volume2 className="w-3.5 sm:w-4 h-3.5 sm:h-4" />}
            </button>

            <button
              onClick={handlePet}
              className="px-2 sm:px-2.5 py-1 rounded-lg bg-pink-500/10 border border-pink-500/30 text-pink-400 text-[11px] sm:text-xs font-semibold hover:bg-pink-500/20 transition-all flex items-center gap-1"
            >
              <Heart className="w-3 sm:w-3.5 h-3 sm:h-3.5 fill-pink-500/30" />
              <span>ناز کردن!</span>
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* EMO PHYSICAL ROBOT DISPLAY */}
        {/* ------------------------------------------------------------- */}
        <motion.div
          onClick={handlePet}
          animate={
            isDancing
              ? { rotate: [-5, 5, -5, 5, 0], y: [-8, 0, -8, 0] }
              : isPetting
              ? { scale: [1, 1.05, 1], rotate: [-2, 2, 0] }
              : { y: [0, -6, 0] }
          }
          transition={
            isDancing
              ? { repeat: Infinity, duration: 0.6 }
              : { repeat: Infinity, duration: 4, ease: 'easeInOut' }
          }
          className="relative my-2 sm:my-4 cursor-pointer group flex flex-col items-center select-none"
        >
          {/* Headphone Arch / RGB Ring Light */}
          <div className="w-44 sm:w-56 h-8 sm:h-10 -mb-4 sm:-mb-5 rounded-t-2xl sm:rounded-t-3xl bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 p-[2px] shadow-lg shadow-cyan-500/30">
            <div className="w-full h-full bg-[#080811] rounded-t-2xl sm:rounded-t-3xl flex items-center justify-between px-3 sm:px-4">
              <div className="w-1.5 sm:w-2 h-1.5 sm:h-2 rounded-full bg-cyan-400 animate-ping" />
              <div className="text-[9px] sm:text-[10px] font-mono text-cyan-300 tracking-widest">EMO-v2.6</div>
              <div className="w-1.5 sm:w-2 h-1.5 sm:h-2 rounded-full bg-pink-400 animate-ping" />
            </div>
          </div>

          {/* EMO Head Chassis */}
          <div className="relative w-52 sm:w-64 h-36 sm:h-44 bg-gradient-to-b from-[#181928] via-[#0D0E1A] to-[#080912] border-2 border-cyan-500/40 rounded-[2rem] sm:rounded-[2.5rem] shadow-[0_0_50px_rgba(6,182,212,0.25)] p-3 sm:p-4 flex flex-col items-center justify-center overflow-hidden">
            
            {/* Side Ear RGB LED Pads */}
            <div className="absolute -left-2.5 sm:-left-3 top-1/2 -translate-y-1/2 w-3 sm:w-4 h-12 sm:h-16 rounded-l-xl bg-cyan-500/40 border border-cyan-400/60 shadow-[0_0_15px_#06b6d4] animate-pulse" />
            <div className="absolute -right-2.5 sm:-right-3 top-1/2 -translate-y-1/2 w-3 sm:w-4 h-12 sm:h-16 rounded-r-xl bg-pink-500/40 border border-pink-400/60 shadow-[0_0_15px_#ec4899] animate-pulse" />

            {/* Glass Digital Screen */}
            <div className="w-full h-full bg-[#030408] border border-cyan-500/20 rounded-[1.5rem] sm:rounded-[2rem] p-2.5 sm:p-3 flex flex-col items-center justify-center relative shadow-inner overflow-hidden">
              
              {/* Petting Pink Cheek Spots */}
              {isPetting && (
                <>
                  <div className="absolute left-4 sm:left-6 bottom-3 sm:bottom-4 w-5 sm:w-6 h-2.5 sm:h-3 rounded-full bg-pink-500/60 blur-xs animate-pulse" />
                  <div className="absolute right-4 sm:right-6 bottom-3 sm:bottom-4 w-5 sm:w-6 h-2.5 sm:h-3 rounded-full bg-pink-500/60 blur-xs animate-pulse" />
                </>
              )}

              {/* Angry Red Flame Aura */}
              {emotion === 'angry' && (
                <div className="absolute inset-0 bg-rose-600/10 blur-xl animate-pulse pointer-events-none" />
              )}

              {/* ------------------------------------------------------------- */}
              {/* EYE ANIMATIONS BASED ON EMOTION */}
              {/* ------------------------------------------------------------- */}
              <div className="flex items-center justify-center gap-5 sm:gap-8 w-full">
                
                {/* HAPPY EYES */}
                {emotion === 'happy' && (
                  <>
                    <motion.div
                      animate={{ scaleY: [1, 0.1, 1] }}
                      transition={{ repeat: Infinity, repeatDelay: 3, duration: 0.2 }}
                      className="w-11 sm:w-14 h-11 sm:h-14 rounded-full border-t-6 sm:border-t-8 border-cyan-400 shadow-[0_0_20px_#00f2fe]"
                    />
                    <motion.div
                      animate={{ scaleY: [1, 0.1, 1] }}
                      transition={{ repeat: Infinity, repeatDelay: 3, duration: 0.2 }}
                      className="w-11 sm:w-14 h-11 sm:h-14 rounded-full border-t-6 sm:border-t-8 border-cyan-400 shadow-[0_0_20px_#00f2fe]"
                    />
                  </>
                )}

                {/* ANGRY EYES */}
                {emotion === 'angry' && (
                  <>
                    <div className="w-11 sm:w-14 h-9 sm:h-12 bg-rose-500 rounded-lg transform -rotate-12 shadow-[0_0_25px_#f43f5e] flex items-center justify-center">
                      <div className="w-4 sm:w-5 h-4 sm:h-5 rounded-full bg-white" />
                    </div>
                    <div className="w-11 sm:w-14 h-9 sm:h-12 bg-rose-500 rounded-lg transform rotate-12 shadow-[0_0_25px_#f43f5e] flex items-center justify-center">
                      <div className="w-4 sm:w-5 h-4 sm:h-5 rounded-full bg-white" />
                    </div>
                  </>
                )}

                {/* SURPRISED EYES */}
                {emotion === 'surprised' && (
                  <>
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 0.8 }}
                      className="w-11 sm:w-14 h-11 sm:h-14 rounded-full bg-cyan-400 border-3 sm:border-4 border-white shadow-[0_0_30px_#00f2fe] flex items-center justify-center"
                    >
                      <div className="w-3.5 sm:w-4 h-3.5 sm:h-4 rounded-full bg-black" />
                    </motion.div>
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 0.8 }}
                      className="w-11 sm:w-14 h-11 sm:h-14 rounded-full bg-cyan-400 border-3 sm:border-4 border-white shadow-[0_0_30px_#00f2fe] flex items-center justify-center"
                    >
                      <div className="w-3.5 sm:w-4 h-3.5 sm:h-4 rounded-full bg-black" />
                    </motion.div>
                  </>
                )}

                {/* THINKING EYES */}
                {emotion === 'thinking' && (
                  <>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
                      className="w-11 sm:w-14 h-11 sm:h-14 rounded-full border-3 sm:border-4 border-cyan-400 border-t-transparent shadow-[0_0_20px_#00f2fe]"
                    />
                    <motion.div
                      animate={{ rotate: -360 }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
                      className="w-11 sm:w-14 h-11 sm:h-14 rounded-full border-3 sm:border-4 border-purple-400 border-t-transparent shadow-[0_0_20px_#c084fc]"
                    />
                  </>
                )}

                {/* SPEAKING EYES */}
                {emotion === 'speaking' && (
                  <>
                    <div className="w-11 sm:w-14 h-11 sm:h-14 rounded-xl sm:rounded-2xl bg-cyan-400/90 shadow-[0_0_25px_#00f2fe] flex items-center justify-center gap-0.5 sm:gap-1 px-1.5 sm:px-2">
                      <motion.div animate={{ height: ['20%', '80%', '20%'] }} transition={{ repeat: Infinity, duration: 0.3 }} className="w-1 sm:w-1.5 bg-black rounded-full" />
                      <motion.div animate={{ height: ['80%', '30%', '80%'] }} transition={{ repeat: Infinity, duration: 0.4 }} className="w-1 sm:w-1.5 bg-black rounded-full" />
                      <motion.div animate={{ height: ['40%', '90%', '40%'] }} transition={{ repeat: Infinity, duration: 0.35 }} className="w-1 sm:w-1.5 bg-black rounded-full" />
                    </div>
                    <div className="w-11 sm:w-14 h-11 sm:h-14 rounded-xl sm:rounded-2xl bg-cyan-400/90 shadow-[0_0_25px_#00f2fe] flex items-center justify-center gap-0.5 sm:gap-1 px-1.5 sm:px-2">
                      <motion.div animate={{ height: ['40%', '90%', '40%'] }} transition={{ repeat: Infinity, duration: 0.35 }} className="w-1 sm:w-1.5 bg-black rounded-full" />
                      <motion.div animate={{ height: ['80%', '30%', '80%'] }} transition={{ repeat: Infinity, duration: 0.4 }} className="w-1 sm:w-1.5 bg-black rounded-full" />
                      <motion.div animate={{ height: ['20%', '80%', '20%'] }} transition={{ repeat: Infinity, duration: 0.3 }} className="w-1 sm:w-1.5 bg-black rounded-full" />
                    </div>
                  </>
                )}

                {/* PROUD EYES */}
                {emotion === 'proud' && (
                  <>
                    <div className="w-11 sm:w-14 h-9 sm:h-12 bg-amber-400 rounded-lg sm:rounded-xl shadow-[0_0_25px_#fbbf24] flex items-center justify-center">
                      <span className="text-lg sm:text-xl">★</span>
                    </div>
                    <div className="w-11 sm:w-14 h-9 sm:h-12 bg-amber-400 rounded-lg sm:rounded-xl shadow-[0_0_25px_#fbbf24] flex items-center justify-center">
                      <span className="text-lg sm:text-xl">★</span>
                    </div>
                  </>
                )}

                {/* SLEEPY EYES */}
                {emotion === 'sleepy' && (
                  <>
                    <div className="w-9 sm:w-12 h-1 bg-cyan-500 rounded-full shadow-[0_0_10px_#00f2fe]" />
                    <div className="w-9 sm:w-12 h-1 bg-cyan-500 rounded-full shadow-[0_0_10px_#00f2fe]" />
                  </>
                )}

              </div>

              {/* Mouth / Audio Equalizer Indicator */}
              <div className="mt-2 sm:mt-3 flex items-center gap-1 h-2">
                {emotion === 'speaking' ? (
                  <>
                    <motion.div animate={{ height: [2, 10, 2] }} transition={{ repeat: Infinity, duration: 0.2 }} className="w-1 bg-cyan-400 rounded-full" />
                    <motion.div animate={{ height: [4, 12, 4] }} transition={{ repeat: Infinity, duration: 0.25 }} className="w-1 bg-cyan-300 rounded-full" />
                    <motion.div animate={{ height: [2, 8, 2] }} transition={{ repeat: Infinity, duration: 0.3 }} className="w-1 bg-cyan-400 rounded-full" />
                  </>
                ) : emotion === 'angry' ? (
                  <div className="w-6 sm:w-8 h-1 bg-rose-500 rounded-full" />
                ) : emotion === 'happy' || emotion === 'proud' ? (
                  <div className="w-5 sm:w-6 h-1.5 sm:h-2 border-b-2 border-cyan-400 rounded-full" />
                ) : (
                  <div className="w-2.5 sm:w-3 h-1 bg-cyan-500/60 rounded-full" />
                )}
              </div>

            </div>
          </div>

          {/* Robot Feet Skateboard Base */}
          <div className="w-40 sm:w-48 h-4 sm:h-5 bg-[#0C0D18] border border-cyan-500/30 rounded-full mt-1 flex items-center justify-between px-4 sm:px-6 shadow-lg">
            <div className="w-5 sm:w-6 h-1 sm:h-1.5 bg-cyan-400 rounded-full shadow-[0_0_8px_#00f2fe]" />
            <div className="w-5 sm:w-6 h-1 sm:h-1.5 bg-purple-400 rounded-full shadow-[0_0_8px_#c084fc]" />
          </div>
        </motion.div>

        {/* Action Emotion Mood Buttons */}
        <div className="flex items-center justify-center gap-1.5 sm:gap-2 mb-3 sm:mb-4">
          <button
            onClick={() => {
              setEmotion('happy');
              const msg = 'هوراا! من خیلی خوشحالم! 😊✨';
              setCurrentSpeech(msg);
              speakText(msg);
            }}
            className="px-2 sm:px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-[10px] sm:text-[11px] font-semibold hover:bg-cyan-500/20 transition-all flex items-center gap-1"
          >
            <Smile className="w-3 sm:w-3.5 h-3 sm:h-3.5" />
            <span>خوشحال</span>
          </button>

          <button
            onClick={handleAnger}
            className="px-2 sm:px-2.5 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-300 text-[10px] sm:text-[11px] font-semibold hover:bg-rose-500/20 transition-all flex items-center gap-1"
          >
            <Flame className="w-3 sm:w-3.5 h-3 sm:h-3.5" />
            <span>عصبانی!</span>
          </button>

          <button
            onClick={handleDance}
            className="px-2 sm:px-2.5 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-[10px] sm:text-[11px] font-semibold hover:bg-purple-500/20 transition-all flex items-center gap-1"
          >
            <Zap className="w-3 sm:w-3.5 h-3 sm:h-3.5" />
            <span>رقص رباتی!</span>
          </button>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* LIVE SPEECH BUBBLE CAPTIONS */}
        {/* ------------------------------------------------------------- */}
        <div className="w-full bg-[#05060C] border border-cyan-500/20 rounded-2xl p-3 sm:p-4 mb-3 sm:mb-4 relative shadow-inner min-h-[75px] sm:min-h-[90px] flex flex-col items-center justify-center">
          {hasAutoplayBlocked && (
            <motion.button
              type="button"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: [1, 1.03, 1], opacity: 1 }}
              transition={{ repeat: Infinity, duration: 1.8 }}
              onClick={() => {
                unlockAudio();
                const msg = pendingGreetingRef.current || currentSpeech;
                pendingGreetingRef.current = null;
                setHasAutoplayBlocked(false);
                speakText(msg);
              }}
              className="w-full mb-2.5 sm:mb-3 py-2 sm:py-2.5 px-3 sm:px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 text-white font-extrabold text-[11px] sm:text-xs md:text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 cursor-pointer hover:scale-[1.02] transition-transform"
            >
              <Volume2 className="w-3.5 sm:w-4 h-3.5 sm:h-4 animate-bounce" />
              <span>🔊 برای شنیدن صدای خوش‌آمدگویی ایمو (EMO) کلیک کنید!</span>
            </motion.button>
          )}

          <p className="text-xs sm:text-sm md:text-base text-cyan-100 font-medium text-center leading-relaxed mb-2">
            {isLoading ? (
              <span className="inline-flex items-center gap-1.5 sm:gap-2 text-cyan-400">
                <Sparkles className="w-3.5 sm:w-4 h-3.5 sm:h-4 animate-spin" />
                در حال فکر کردن...
              </span>
            ) : (
              currentSpeech
            )}
          </p>

          {!isLoading && currentSpeech && (
            <button
              type="button"
              onClick={() => {
                unlockAudio();
                speakText(currentSpeech);
              }}
              className="px-3 sm:px-3.5 py-1 sm:py-1.5 rounded-full bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-[11px] sm:text-xs font-semibold transition-all flex items-center gap-1.5 shadow-sm"
              title="پخش مجدد صدای ایمو"
            >
              <Volume2 className={`w-3.5 h-3.5 ${isPlayingAudio ? 'animate-bounce text-cyan-400' : ''}`} />
              <span>{isPlayingAudio ? 'در حال پخش صدای ایمو...' : '🔊 پخش صدای فارسی ایمو'}</span>
            </button>
          )}
        </div>

        {/* ------------------------------------------------------------- */}
        {/* QUICK QUESTION PROMPT CHIPS */}
        {/* ------------------------------------------------------------- */}
        <div className="w-full mb-3 sm:mb-4">
          <p className="text-[11px] sm:text-xs text-slate-400 mb-1.5 sm:mb-2 font-medium flex items-center gap-1">
            <HelpCircle className="w-3 sm:w-3.5 h-3 sm:h-3.5 text-cyan-400" />
            <span>سوالات پیشنهادی از ایمو:</span>
          </p>
          <div className="flex flex-wrap gap-1 sm:gap-1.5">
            {quickQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(q.text)}
                disabled={isLoading}
                className="px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-lg sm:rounded-xl bg-[#121324] border border-[#222440] hover:border-cyan-500/50 hover:bg-cyan-500/10 text-slate-300 hover:text-cyan-300 text-[10px] sm:text-xs font-medium transition-all shadow-sm disabled:opacity-50"
              >
                {q.text}
              </button>
            ))}
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* CHAT INPUT FORM */}
        {/* ------------------------------------------------------------- */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="w-full flex items-center gap-1.5 sm:gap-2"
        >
          <button
            type="button"
            onClick={toggleVoiceInput}
            className={`p-2.5 sm:p-3 rounded-xl sm:rounded-2xl border transition-all shrink-0 ${
              isListening
                ? 'bg-rose-500 border-rose-400 text-white animate-pulse'
                : 'bg-[#121324] border-[#222440] text-cyan-400 hover:border-cyan-500/40 hover:bg-cyan-500/10'
            }`}
            title="صحبت صوتی با ربات"
          >
            {isListening ? <MicOff className="w-4 sm:w-5 h-4 sm:h-5" /> : <Mic className="w-4 sm:w-5 h-4 sm:h-5" />}
          </button>

          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="از ایمو هر سوالی داری بپرس..."
            className="flex-1 bg-[#05060C] border border-[#222440] focus:border-cyan-500/60 rounded-xl sm:rounded-2xl px-3 sm:px-4 py-2.5 sm:py-3 text-slate-100 text-xs sm:text-sm placeholder-slate-500 focus:outline-none transition-all shadow-inner"
          />

          <button
            type="submit"
            disabled={!inputMessage.trim() || isLoading}
            className="px-3 sm:px-4 py-2.5 sm:py-3 rounded-xl sm:rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs sm:text-sm hover:from-cyan-400 hover:to-blue-500 transition-all shadow-lg shadow-cyan-500/20 disabled:opacity-50 flex items-center gap-1 shrink-0"
          >
            <span>ارسال</span>
            <Send className="w-3.5 sm:w-4 h-3.5 sm:h-4 rotate-180" />
          </button>
        </form>

      </div>
    </div>
  );
};
