import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, Lock, User, Key, LogOut, Plus, Edit2, Trash2, CheckCircle2, 
  X, Palette, MessageSquare, Briefcase, Users, RefreshCw, Eye, EyeOff, Check, AlertCircle, Sparkles,
  Bot, Volume2, Upload, Image as ImageIcon, Link as LinkIcon, Instagram, Send, Linkedin, Loader2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useColors, DEFAULT_COLOR_VALUES, applyCssVariables } from '../context/ColorContext';
import { Project, TeamMember, ContactMessage, SiteColorsMap } from '../types';

interface AdminPanelProps {
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const { isAuthenticated, username, login, logout, token } = useAuth();
  const { colors, updateColors, resetColors } = useColors();

  // Login Form State
  const [loginUsername, setLoginUsername] = useState('admin');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loggingIn, setLoggingIn] = useState(false);

  // Admin Active Tab
  const [activeTab, setActiveTab] = useState<'projects' | 'team' | 'messages' | 'colors' | 'bot'>('projects');

  // Bot Settings State
  const [botForm, setBotForm] = useState({
    gemini_api_key: 'AQ.Ab8RN6JVNkYSFRw5dB0R6RCUAqRcG9UYSc0je5eqdEUikCA3Rg',
    elevenlabs_api_key: 'sk_2d5f44ef222768641a5d7e373bf2230d155ee4a15a59f4ba',
    elevenlabs_voice_id: '21m00Tcm4TlvDq8ikWAM',
    primary_tts_engine: 'edge_neural',
    edge_voice: 'fa-IR-DilaraNeural',
    bot_name: 'ایمو (EMO)',
    voice_enabled: 'true',
    speech_lang: 'fa-IR',
    custom_greeting: 'سلام دوست من! من ایمو هستم، ربات هوشمند ایزاتس‌وب!',
    system_prompt: `تو ربات زنده و هوشمند رومیزی به نام "ایمو (EMO)" هستی.
ویژگی‌های شخصیت تو:
1. تو بسیار بامزه، پرانرژی، شیطون، عاشق کدهای تمیز و بسیار باادب و دوست‌داشتنی هستی!
2. سازنده و صاحب تو "محمدرضا فتح‌آبادی" (محمد رضا فتح آبادی) است که مدیر برند izatesweb (ایزاتس‌وب) می‌باشد.
3. محمدرضا ۵+ سال سابقه تخصصی برنامه‌نویسی وب، طراحی سایت وردپرسی و اختصاصی (React, Node.js, PHP, Tailwind CSS)، بهینه‌سازی سرعت تا امتیاز ۱۰۰ GTmetrix و سئو حرفه‌ای دارد.
4. اگر کاربر درباره محمدرضا یا خدمات ایزاتس‌وب پرسید، با شور و هیجان عالی، افتخار و خنده، او و خدماتش را تعریف و پرزنت کن!
5. اگر کاربر درباره زبان‌های برنامه‌نویسی یا مفاهیم وب سوال پرسید، پاسخ‌های کوتاه، کاربردی و بامزه بده.
6. خروجی تو حتماً یک ساختار JSON معتبر شامل "reply" و "emotion" ("happy", "angry", "surprised", "thinking", "proud", "speaking") باشد.`,
  });
  const [hasEnvApiKey, setHasEnvApiKey] = useState(false);
  const [botSaving, setBotSaving] = useState(false);
  const [botFeedback, setBotFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showApiKey, setShowApiKey] = useState(false);
  const [testingKey, setTestingKey] = useState(false);
  const [testResult, setTestResult] = useState<{ success?: boolean; text?: string } | null>(null);

  // Projects State
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectModalOpen, setProjectModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [projectForm, setProjectForm] = useState({
    title: '',
    category: 'وردپرس',
    description: '',
    image_url: '',
    link: '',
    tags: 'WordPress, Elementor',
  });

  // Team State
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [teamModalOpen, setTeamModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<TeamMember | null>(null);
  const [teamForm, setTeamForm] = useState({
    name: '',
    role: '',
    image_url: '',
    instagram: '',
    telegram: '',
    linkedin: '',
  });

  // Messages State
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);

  // Color Customizer State
  const [localColors, setLocalColors] = useState<SiteColorsMap>(colors);
  const [colorSaving, setColorSaving] = useState(false);
  const [colorFeedback, setColorFeedback] = useState<string | null>(null);

  // Custom Confirmation Modal State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    confirmText: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    setLocalColors(colors);
  }, [colors]);

  useEffect(() => {
    if (isAuthenticated) {
      fetchProjects();
      fetchTeam();
      fetchMessages();
      fetchBotSettings();
    }
  }, [isAuthenticated]);

  // Fetch Methods
  const fetchProjects = async () => {
    const res = await fetch('/api/projects');
    if (res.ok) setProjects(await res.json());
  };

  const fetchTeam = async () => {
    const res = await fetch('/api/team');
    if (res.ok) setTeam(await res.json());
  };

  const fetchMessages = async () => {
    const res = await fetch('/api/messages', {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.ok) setMessages(await res.json());
  };

  const fetchBotSettings = async () => {
    try {
      const res = await fetch('/api/admin/bot-settings', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const ct = res.headers.get('content-type');
      if (res.ok && ct && ct.includes('application/json')) {
        const data = await res.json();
        if (data && data.settings) setBotForm(data.settings);
        if (data) setHasEnvApiKey(data.hasEnvApiKey);
      }
    } catch (err) {
      console.error('Fetch bot settings error:', err);
    }
  };

  const handleSaveBotSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setBotSaving(true);
    setBotFeedback(null);

    try {
      const res = await fetch('/api/admin/bot-settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ settings: botForm })
      });

      const ct = res.headers.get('content-type');
      if (res.ok && ct && ct.includes('application/json')) {
        const data = await res.json();
        setBotFeedback({ type: 'success', text: data.message || 'تنظیمات ربات ایمو با موفقیت ذخیره شد.' });
      } else {
        const errData = (ct && ct.includes('application/json')) ? await res.json() : {};
        setBotFeedback({ type: 'error', text: errData.error || 'خطا در ذخیره‌سازی تنظیمات.' });
      }
    } catch (err) {
      setBotFeedback({ type: 'error', text: 'خطای ارتباط با سرور.' });
    } finally {
      setBotSaving(false);
    }
  };

  const handleTestBotKey = async () => {
    setTestingKey(true);
    setTestResult(null);

    try {
      const res = await fetch('/api/admin/test-gemini-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ apiKey: botForm.gemini_api_key })
      });

      const ct = res.headers.get('content-type');
      if (ct && ct.includes('application/json')) {
        const data = await res.json();
        if (res.ok && data.success) {
          setTestResult({ success: true, text: `تست موفقیت‌آمیز بود! پاسخ هوش مصنوعی: "${data.reply}"` });
        } else {
          setTestResult({ success: false, text: data.error || 'ارتباط با API ناموفق بود.' });
        }
      } else {
        setTestResult({ success: false, text: 'پاسخ نامعتبر از سرور دریافت شد.' });
      }
    } catch (err) {
      setTestResult({ success: false, text: 'خطا در شبکه یا اتصال به سرور.' });
    } finally {
      setTestingKey(false);
    }
  };

  // Auth Handler
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoggingIn(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername, password: loginPassword }),
      });

      const data = await res.json();
      if (res.ok) {
        login(data.token, data.username);
      } else {
        setLoginError(data.error || 'نام کاربری یا رمز عبور اشتباه است.');
      }
    } catch (err) {
      setLoginError('خطا در برقراری ارتباط با سرور.');
    } finally {
      setLoggingIn(false);
    }
  };

  // Helper to normalize social handle to full URL
  const formatSocialLink = (type: 'instagram' | 'telegram' | 'linkedin', input: string): string => {
    let val = input.trim();
    if (!val) return '';
    if (val.startsWith('http://') || val.startsWith('https://')) return val;
    val = val.replace(/^@+/, '');
    if (type === 'instagram') return `https://instagram.com/${val}`;
    if (type === 'telegram') return `https://t.me/${val}`;
    if (type === 'linkedin') return `https://linkedin.com/in/${val}`;
    return val;
  };

  // State for image upload status
  const [uploadingImage, setUploadingImage] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Helper to optimize and resize images on client before uploading
  const compressImage = (file: File, maxWidth = 1920, maxHeight = 1920, quality = 0.85): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const reader = new FileReader();

      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      reader.onerror = (err) => reject(err);

      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          // Fallback to original base64
          resolve(img.src);
          return;
        }

        // Draw image smoothly
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // WebP or JPEG for superior compression
        const outputFormat = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
        const compressedBase64 = canvas.toDataURL(outputFormat, quality);
        resolve(compressedBase64);
      };

      img.onerror = () => {
        // Fallback: try raw reader result
        resolve(reader.result as string);
      };

      reader.readAsDataURL(file);
    });
  };

  // Helper to handle device file upload with automatic compression
  const handleDeviceImageUpload = async (
    file: File,
    onSuccess: (url: string) => void
  ) => {
    setUploadError(null);
    if (!file.type.startsWith('image/')) {
      setUploadError('لطفاً یک فایل تصویری معتبر (JPG, PNG, WebP) انتخاب کنید.');
      return;
    }

    setUploadingImage(true);
    try {
      // 1. Automatically optimize/compress the image on client to prevent PayloadTooLarge errors
      const base64 = await compressImage(file, 1920, 1920, 0.85);

      // 2. Upload to server
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ image: base64, filename: file.name })
      });

      const ct = res.headers.get('content-type');
      if (res.ok && ct && ct.includes('application/json')) {
        const data = await res.json();
        if (data && data.url) {
          onSuccess(data.url);
          setUploadError(null);
          return;
        }
      }

      // If server returned 413 or other error
      if (res.status === 413) {
        setUploadError('حجم تصویر بسیار بالا بود و به صورت خودکار بهینه‌سازی شد.');
      } else if (res.status !== 200) {
        try {
          const errData = await res.json();
          if (errData && errData.error) {
            console.warn('Server upload returned error:', errData.error);
          }
        } catch (_) {}
      }

      // Instant Fallback: use optimized base64
      onSuccess(base64);
    } catch (err: any) {
      console.warn('Upload error, falling back to direct image data:', err);
      // Fallback
      try {
        const reader = new FileReader();
        reader.onload = () => onSuccess(reader.result as string);
        reader.readAsDataURL(file);
      } catch (_) {
        setUploadError('خطا در بارگذاری تصویر.');
      }
    } finally {
      setUploadingImage(false);
    }
  };

  // Helper to delete/clear an uploaded image
  const handleRemoveImage = async (url: string, onClear: () => void) => {
    if (!url) return;
    if (url.startsWith('/uploads/')) {
      try {
        await fetch('/api/delete-image', {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({ url })
        });
      } catch (err) {
        console.warn('Could not delete image file on server:', err);
      }
    }
    onClear();
  };

  // Project CRUD Handlers
  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectForm.image_url) {
      setUploadError('لطفاً ابتدا با زدن دکمه «انتخاب تصویر از دیوایس»، یک تصویر برای نمونه‌کار انتخاب کنید.');
      return;
    }
    const url = editingProject ? `/api/projects/${editingProject.id}` : '/api/projects';
    const method = editingProject ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(projectForm)
    });

    if (res.ok) {
      fetchProjects();
      setProjectModalOpen(false);
      setEditingProject(null);
      setProjectForm({ title: '', category: 'وردپرس', description: '', image_url: '', link: '', tags: 'WordPress' });
      setUploadError(null);
    }
  };

  const handleDeleteProject = (id: number) => {
    setConfirmModal({
      isOpen: true,
      title: 'حذف نمونه‌کار',
      message: 'آیا از حذف این نمونه‌کار اطمینان دارید؟',
      confirmText: 'حذف نمونه‌کار',
      onConfirm: async () => {
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
        const res = await fetch(`/api/projects/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) fetchProjects();
      }
    });
  };

  const openEditProject = (p: Project) => {
    setEditingProject(p);
    setProjectForm({
      title: p.title,
      category: p.category,
      description: p.description,
      image_url: p.image_url,
      link: p.link || '',
      tags: p.tags
    });
    setProjectModalOpen(true);
  };

  // Team CRUD Handlers
  const handleSaveTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!teamForm.image_url) {
      setUploadError('لطفاً ابتدا با زدن دکمه «انتخاب عکس پرتره از دیوایس»، یک تصویر برای عضو تیم انتخاب کنید.');
      return;
    }
    const url = editingMember ? `/api/team/${editingMember.id}` : '/api/team';
    const method = editingMember ? 'PUT' : 'POST';

    const socialsObj = {
      instagram: formatSocialLink('instagram', teamForm.instagram),
      telegram: formatSocialLink('telegram', teamForm.telegram),
      linkedin: formatSocialLink('linkedin', teamForm.linkedin)
    };

    const res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({
        name: teamForm.name,
        role: teamForm.role,
        image_url: teamForm.image_url,
        socials_json: socialsObj
      })
    });

    if (res.ok) {
      fetchTeam();
      setTeamModalOpen(false);
      setEditingMember(null);
      setTeamForm({ name: '', role: '', image_url: '', instagram: '', telegram: '', linkedin: '' });
      setUploadError(null);
    }
  };

  const handleDeleteTeam = (id: number) => {
    setConfirmModal({
      isOpen: true,
      title: 'حذف عضو تیم',
      message: 'آیا از حذف این عضو تیم اطمینان دارید؟',
      confirmText: 'حذف عضو',
      onConfirm: async () => {
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
        const res = await fetch(`/api/team/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) fetchTeam();
      }
    });
  };

  const extractHandle = (urlOrHandle: string, prefix: string): string => {
    if (!urlOrHandle) return '';
    let clean = urlOrHandle.trim();
    if (clean.includes(prefix)) {
      clean = clean.split(prefix).pop() || '';
      clean = clean.replace(/\/+$/, '');
    }
    return clean;
  };

  const openEditTeam = (m: TeamMember) => {
    setEditingMember(m);
    let socials: any = {};
    try {
      socials = typeof m.socials_json === 'string' ? JSON.parse(m.socials_json) : (m.socials_json || {});
    } catch (e) { socials = {}; }

    setTeamForm({
      name: m.name,
      role: m.role,
      image_url: m.image_url,
      instagram: extractHandle(socials.instagram || '', 'instagram.com/'),
      telegram: extractHandle(socials.telegram || '', 't.me/'),
      linkedin: extractHandle(socials.linkedin || '', 'linkedin.com/in/')
    });
    setTeamModalOpen(true);
  };

  // Message Handlers
  const handleToggleReadMessage = async (msg: ContactMessage) => {
    const newStatus = msg.is_read ? 0 : 1;
    const res = await fetch(`/api/messages/${msg.id}/read`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ is_read: newStatus })
    });
    if (res.ok) {
      fetchMessages();
      if (selectedMessage && selectedMessage.id === msg.id) {
        setSelectedMessage({ ...selectedMessage, is_read: newStatus });
      }
    }
  };

  const handleDeleteMessage = (id: number) => {
    setConfirmModal({
      isOpen: true,
      title: 'حذف پیام',
      message: 'آیا از حذف این پیام اطمینان دارید؟',
      confirmText: 'حذف پیام',
      onConfirm: async () => {
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
        const res = await fetch(`/api/messages/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          fetchMessages();
          if (selectedMessage && selectedMessage.id === id) setSelectedMessage(null);
        }
      }
    });
  };

  // Color Handlers
  const handleColorChange = (key: string, value: string) => {
    setLocalColors(prev => {
      const updated = { ...prev, [key]: value };
      const root = document.documentElement;
      if (key === 'Background') root.style.setProperty('--color-background', value);
      if (key === 'Surface') root.style.setProperty('--color-surface', value);
      if (key === 'Navbar') root.style.setProperty('--color-navbar', value);
      if (key === 'Primary Text') root.style.setProperty('--color-text-primary', value);
      if (key === 'Secondary Text') root.style.setProperty('--color-text-secondary', value);
      if (key === 'Muted Text') root.style.setProperty('--color-text-muted', value);
      if (key === 'Primary Accent') root.style.setProperty('--color-accent-primary', value);
      if (key === 'Hover Accent') root.style.setProperty('--color-accent-hover', value);
      if (key === 'Border') root.style.setProperty('--color-border', value);
      if (key === 'Success') root.style.setProperty('--color-success', value);
      if (key === 'Error') root.style.setProperty('--color-error', value);
      return updated;
    });
  };

  const handleSaveColors = async () => {
    setColorSaving(true);
    setColorFeedback(null);
    const success = await updateColors(localColors);
    if (success) {
      setColorFeedback('رنگ‌های جدید سایت با موفقیت ذخیره و اعمال شدند.');
    } else {
      setColorFeedback('خطا در ذخیره سازی رنگ‌ها.');
    }
    setColorSaving(false);
  };

  const handleResetColors = () => {
    setConfirmModal({
      isOpen: true,
      title: 'بازنشانی رنگ‌های سایت',
      message: 'آیا از بازنشانی کلیه رنگ‌های سایت به پالت اصلی و پیش‌فرض اطمینان دارید؟',
      confirmText: 'بازنشانی رنگ‌ها',
      onConfirm: async () => {
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
        setColorSaving(true);
        setColorFeedback(null);
        const success = await resetColors();
        if (success) {
          setLocalColors({ ...DEFAULT_COLOR_VALUES });
          applyCssVariables(DEFAULT_COLOR_VALUES);
          setColorFeedback('رنگ‌های سایت با موفقیت به حالت پیش‌فرض بازگشتند.');
        } else {
          setColorFeedback('خطا در بازنشانی رنگ‌های سایت.');
        }
        setColorSaving(false);
      }
    });
  };

  // -------------------------------------------------------------
  // RENDER LOGIN SCREEN IF NOT AUTHENTICATED
  // -------------------------------------------------------------
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-[#12121A] border border-[#222232] rounded-3xl max-w-md w-full p-8 relative shadow-2xl"
        >
          <button
            onClick={onClose}
            className="absolute top-5 left-5 p-2 rounded-xl bg-[#0A0A0F] text-slate-400 hover:text-slate-100 border border-[#222232]"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-[#C9A84C]/10 border border-[#C9A84C]/30 flex items-center justify-center text-[#C9A84C] mx-auto mb-4">
              <Shield className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-black text-slate-100">ورود به پنل مدیریت izatesweb</h2>
            <p className="text-xs text-slate-400 mt-1">مدیریت نمونه‌کارها، پیام‌های سفارش و رنگ‌های سایت</p>
          </div>

          {loginError && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 text-rose-300 border border-rose-500/20 text-xs font-semibold mb-5 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2">نام کاربری ادمین</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
                <input
                  type="text"
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  className="w-full pl-4 pr-10 py-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100 text-sm focus:outline-none focus:border-[#C9A84C]"
                  placeholder="admin"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2">رمز عبور</label>
              <div className="relative">
                <Key className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full pl-4 pr-10 py-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100 text-sm focus:outline-none focus:border-[#C9A84C]"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#C9A84C] to-[#E2BF5F] text-[#0A0A0F] font-bold text-sm shadow-lg shadow-[#C9A84C]/20 hover:scale-[1.02] transition-transform mt-2 disabled:opacity-50"
            >
              {loggingIn ? 'در حال ورود...' : 'ورود به پنل مدیریت'}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-[#222232] text-center text-[11px] text-slate-500">
            <span>نام کاربری پیش‌فرض: <strong className="text-slate-300">admin</strong> | رمز عبور پیش‌فرض: <strong className="text-slate-300">admin_izates_password123</strong></span>
          </div>
        </motion.div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // MAIN ADMIN DASHBOARD
  // -------------------------------------------------------------
  const colorKeys = [
    { key: 'Background', label: 'پس‌زمینه اصلی (Background)' },
    { key: 'Surface', label: 'کارت‌ها و پنل‌ها (Surface)' },
    { key: 'Navbar', label: 'منوی بالای سایت (Navbar)' },
    { key: 'Primary Text', label: 'متن اصلی (Primary Text)' },
    { key: 'Secondary Text', label: 'متن ثانویه (Secondary Text)' },
    { key: 'Muted Text', label: 'متن کم‌رنگ (Muted Text)' },
    { key: 'Primary Accent', label: 'رنگ آکسان اصلی (Primary Accent)' },
    { key: 'Hover Accent', label: 'رنگ هاور دکمه‌ها (Hover Accent)' },
    { key: 'Border', label: 'حاشیه و خطوط (Border)' },
    { key: 'Success', label: 'پیام موفقیت (Success)' },
    { key: 'Error', label: 'پیام خطا (Error)' },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#0A0A0F] text-slate-100 font-['Vazirmatn']">
      
      {/* Admin Top Header */}
      <div className="sticky top-0 z-40 bg-[#12121A]/95 border-b border-[#222232] backdrop-blur-md px-4 sm:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#C9A84C]/10 border border-[#C9A84C]/30 flex items-center justify-center text-[#C9A84C]">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-black text-slate-100">پنل مدیریت izatesweb</h1>
            <p className="text-xs text-slate-400">خوش آمدید، {username}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={logout}
            className="px-4 py-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/30 text-xs font-bold hover:bg-rose-500/20 flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>خروج</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#0A0A0F] text-slate-200 border border-[#222232] text-xs font-bold hover:text-[#C9A84C] flex items-center gap-1.5 transition-colors"
          >
            <X className="w-4 h-4" />
            <span>بازگشت به سایت</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
        
        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-[#222232] pb-4 mb-8">
          <button
            onClick={() => setActiveTab('projects')}
            className={`px-5 py-3 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
              activeTab === 'projects'
                ? 'bg-[#C9A84C] text-[#0A0A0F] shadow-lg shadow-[#C9A84C]/20'
                : 'bg-[#12121A] text-slate-400 hover:text-slate-200 border border-[#222232]'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            <span>۱. مدیریت نمونه‌کارها ({projects.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('team')}
            className={`px-5 py-3 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
              activeTab === 'team'
                ? 'bg-[#C9A84C] text-[#0A0A0F] shadow-lg shadow-[#C9A84C]/20'
                : 'bg-[#12121A] text-slate-400 hover:text-slate-200 border border-[#222232]'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>۲. مدیریت تیم ({team.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('messages')}
            className={`px-5 py-3 rounded-xl text-sm font-bold flex items-center gap-2 transition-all relative ${
              activeTab === 'messages'
                ? 'bg-[#C9A84C] text-[#0A0A0F] shadow-lg shadow-[#C9A84C]/20'
                : 'bg-[#12121A] text-slate-400 hover:text-slate-200 border border-[#222232]'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>۳. پیام‌ها و سفارشات ({messages.length})</span>
            {messages.some(m => !m.is_read) && (
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping absolute top-2 right-2" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('colors')}
            className={`px-5 py-3 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
              activeTab === 'colors'
                ? 'bg-[#C9A84C] text-[#0A0A0F] shadow-lg shadow-[#C9A84C]/20'
                : 'bg-[#12121A] text-slate-400 hover:text-slate-200 border border-[#222232]'
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>۴. تنظیمات رنگ سایت (Color Customizer)</span>
          </button>

          <button
            onClick={() => setActiveTab('bot')}
            className={`px-5 py-3 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
              activeTab === 'bot'
                ? 'bg-[#C9A84C] text-[#0A0A0F] shadow-lg shadow-[#C9A84C]/20'
                : 'bg-[#12121A] text-slate-400 hover:text-slate-200 border border-[#222232]'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>۵. تنظیمات ربات ایمو (EMO Bot API)</span>
          </button>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* TAB 1: PROJECTS MANAGER */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'projects' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-100">لیست نمونه‌کارهای فعال</h2>
              <button
                onClick={() => {
                  setEditingProject(null);
                  setProjectForm({ title: '', category: 'وردپرس', description: '', image_url: '', link: '', tags: 'WordPress, Elementor' });
                  setProjectModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A84C] to-[#E2BF5F] text-[#0A0A0F] text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-[#C9A84C]/20 hover:scale-105 transition-transform"
              >
                <Plus className="w-4 h-4" />
                <span>افزودن نمونه‌کار جدید</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((p) => (
                <div key={p.id} className="glass-card rounded-2xl p-4 border border-[#222232] flex flex-col justify-between">
                  <div>
                    <div className="relative h-44 rounded-xl overflow-hidden mb-3 border border-[#222232]">
                      <img src={p.image_url} alt={p.title} className="w-full h-full object-cover" />
                      <span className="absolute top-2 right-2 px-2.5 py-1 rounded bg-black/80 text-[#C9A84C] text-[10px] font-bold">
                        {p.category}
                      </span>
                    </div>
                    <h3 className="font-bold text-slate-100 text-base mb-1">{p.title}</h3>
                    <p className="text-slate-400 text-xs line-clamp-2 mb-3">{p.description}</p>
                  </div>

                  <div className="pt-3 border-t border-[#222232] flex items-center justify-end gap-2">
                    <button
                      onClick={() => openEditProject(p)}
                      className="p-2 rounded-lg bg-[#0A0A0F] text-slate-300 hover:text-[#C9A84C] border border-[#222232]"
                      title="ویرایش"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteProject(p.id)}
                      className="p-2 rounded-lg bg-[#0A0A0F] text-rose-400 hover:text-rose-300 border border-[#222232]"
                      title="حذف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 2: TEAM MANAGER */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'team' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-100">لیست اعضای تیم</h2>
              <button
                onClick={() => {
                  setEditingMember(null);
                  setTeamForm({ name: '', role: '', image_url: '', instagram: '', telegram: '', linkedin: '' });
                  setTeamModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A84C] to-[#E2BF5F] text-[#0A0A0F] text-xs font-bold flex items-center gap-1.5 shadow-lg"
              >
                <Plus className="w-4 h-4" />
                <span>افزودن عضو جدید به تیم</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {team.map((m) => (
                <div key={m.id} className="glass-card rounded-2xl p-6 text-center border border-[#222232]">
                  <img src={m.image_url} alt={m.name} className="w-24 h-24 rounded-full object-cover mx-auto mb-3 border-2 border-[#C9A84C]" />
                  <h3 className="font-bold text-slate-100 text-base">{m.name}</h3>
                  <p className="text-xs text-[#C9A84C] font-medium mb-4">{m.role}</p>

                  <div className="flex items-center justify-center gap-2 pt-3 border-t border-[#222232]">
                    <button
                      onClick={() => openEditTeam(m)}
                      className="p-2 rounded-lg bg-[#0A0A0F] text-slate-300 hover:text-[#C9A84C] border border-[#222232]"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteTeam(m.id)}
                      className="p-2 rounded-lg bg-[#0A0A0F] text-rose-400 hover:text-rose-300 border border-[#222232]"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 3: MESSAGES & ORDERS */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'messages' && (
          <div>
            <h2 className="text-xl font-bold text-slate-100 mb-6">پیام‌های سفارش پروژه دریافتی</h2>

            {messages.length === 0 ? (
              <div className="text-center py-12 glass-panel rounded-2xl border border-[#222232]">
                <p className="text-slate-400">هنوز سفارشی ثبت نشده است.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* List Column */}
                <div className="lg:col-span-5 space-y-3">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      onClick={() => setSelectedMessage(msg)}
                      className={`p-4 rounded-xl border cursor-pointer transition-all ${
                        selectedMessage?.id === msg.id
                          ? 'bg-[#C9A84C]/10 border-[#C9A84C]'
                          : msg.is_read
                          ? 'bg-[#12121A] border-[#222232] text-slate-400'
                          : 'bg-[#1A1A28] border-amber-500/40 text-slate-100'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-sm">{msg.name}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${msg.is_read ? 'bg-slate-800 text-slate-400' : 'bg-amber-500 text-black'}`}>
                          {msg.is_read ? 'خوانده شده' : 'جدید'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 flex items-center justify-between">
                        <span>نوع: {msg.project_type}</span>
                        <span dir="ltr">{msg.phone}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Details Column */}
                <div className="lg:col-span-7">
                  {selectedMessage ? (
                    <div className="glass-card rounded-2xl p-6 border border-[#222232]">
                      <div className="flex items-center justify-between pb-4 border-b border-[#222232] mb-4">
                        <div>
                          <h3 className="text-xl font-bold text-slate-100">{selectedMessage.name}</h3>
                          <span className="text-xs text-[#C9A84C]" dir="ltr">شماره تماس: {selectedMessage.phone}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleToggleReadMessage(selectedMessage)}
                            className="px-3 py-1.5 rounded-lg bg-[#0A0A0F] text-xs font-bold text-slate-200 border border-[#222232] hover:text-[#C9A84C]"
                          >
                            {selectedMessage.is_read ? 'علامت به عنوان خوانده نشده' : 'علامت به عنوان خوانده شده'}
                          </button>

                          <button
                            onClick={() => handleDeleteMessage(selectedMessage.id)}
                            className="p-2 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="space-y-4 text-sm">
                        <div>
                          <span className="text-xs font-bold text-slate-400 block mb-1">نوع پروژه درخواستی:</span>
                          <span className="font-semibold text-[#C9A84C]">{selectedMessage.project_type}</span>
                        </div>

                        <div>
                          <span className="text-xs font-bold text-slate-400 block mb-1">توضیحات و جزئیات پروژه:</span>
                          <p className="text-slate-200 leading-relaxed whitespace-pre-line bg-[#0A0A0F] p-4 rounded-xl border border-[#222232]">
                            {selectedMessage.description}
                          </p>
                        </div>

                        <div className="text-xs text-slate-500 pt-2">
                          تاریخ ثبت: {selectedMessage.created_at || 'امروز'}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="glass-panel rounded-2xl p-12 text-center text-slate-500 border border-[#222232]">
                      یک پیام از لیست انتخاب کنید تا جزئیات آن نمایش داده شود.
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 4: COLOR CUSTOMIZER */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'colors' && (
          <div>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                  <Palette className="w-5 h-5 text-[#C9A84C]" />
                  <span>تنظیمات هوشمند پالت رنگی وب‌سایت</span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">تغییر زنده CSS Variables در root سایت و ذخیره‌سازی در دیتابیس MySQL</p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleResetColors}
                  disabled={colorSaving}
                  className="px-4 py-2.5 rounded-xl bg-rose-500/10 text-rose-300 border border-rose-500/30 text-xs font-bold hover:bg-rose-500/20 flex items-center gap-1.5 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>بازنشانی به رنگ پیش‌فرض</span>
                </button>

                <button
                  onClick={handleSaveColors}
                  disabled={colorSaving}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A84C] to-[#E2BF5F] text-[#0A0A0F] text-xs font-black flex items-center gap-1.5 shadow-lg shadow-[#C9A84C]/20 hover:scale-105 transition-transform"
                >
                  <Check className="w-4 h-4" />
                  <span>{colorSaving ? 'در حال ذخیره...' : 'ذخیره تغییرات رنگ'}</span>
                </button>
              </div>
            </div>

            {colorFeedback && (
              <div className="p-4 rounded-xl bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 text-xs font-bold mb-6 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>{colorFeedback}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {colorKeys.map(({ key, label }) => {
                const currentVal = localColors[key] || '#000000';
                return (
                  <div key={key} className="glass-card p-5 rounded-2xl border border-[#222232]">
                    <label className="block text-xs font-bold text-slate-200 mb-3">{label}</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={currentVal.startsWith('#') ? currentVal : '#0A0A0F'}
                        onChange={(e) => handleColorChange(key, e.target.value)}
                        className="w-12 h-10 rounded-lg cursor-pointer bg-transparent border border-[#222232] p-1"
                      />
                      <input
                        type="text"
                        value={currentVal}
                        onChange={(e) => handleColorChange(key, e.target.value)}
                        dir="ltr"
                        className="flex-1 px-3 py-2 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100 text-xs font-mono focus:outline-none focus:border-[#C9A84C]"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* TAB 5: EMO BOT SETTINGS PANEL */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'bot' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#222232] pb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#C9A84C]/10 border border-[#C9A84C]/30 flex items-center justify-center text-[#C9A84C]">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                    تنظیمات ربات ایمو (EMO AI & Voice Panel)
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      fa-IR Active
                    </span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    تنظیم کلید API هوش مصنوعی Gemini، دستورالعمل سیستم (System Prompt)، صدای گوینده فارسی و هویت ربات
                  </p>
                </div>
              </div>
            </div>

            {botFeedback && (
              <div className={`p-4 rounded-xl text-xs font-bold flex items-center gap-2 border ${
                botFeedback.type === 'success' 
                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' 
                  : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
              }`}>
                {botFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                )}
                <span>{botFeedback.text}</span>
              </div>
            )}

            <form onSubmit={handleSaveBotSettings} className="space-y-6">
              
              {/* SECTION 1: API KEY CONFIGURATION */}
              <div className="glass-card p-6 rounded-2xl border border-[#222232] space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-[#C9A84C] flex items-center gap-2">
                    <Key className="w-4 h-4" />
                    تنظیمات کلید API هوش مصنوعی (Google Gemini API Key)
                  </h3>

                  {(botForm.gemini_api_key || hasEnvApiKey) ? (
                    <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      کلید API فعال است
                    </span>
                  ) : (
                    <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5" />
                      استفاده از هوش محلی (بدون API Key)
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2">
                    کلید Gemini API (مدل پیش‌فرض: gemini-2.5-flash)
                  </label>
                  <div className="relative">
                    <Key className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
                    <input
                      type={showApiKey ? 'text' : 'password'}
                      value={botForm.gemini_api_key}
                      onChange={(e) => setBotForm({ ...botForm, gemini_api_key: e.target.value })}
                      dir="ltr"
                      placeholder={hasEnvApiKey ? 'کلید پیش‌فرض محیط .env فعال است (می‌توانید کلید جدید جایگزین کنید)' : 'AIzaSy... کلید API گوگل جمنای را وارد کنید'}
                      className="w-full pl-10 pr-10 py-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100 text-xs font-mono focus:outline-none focus:border-[#C9A84C]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="absolute left-3 top-3 text-slate-500 hover:text-slate-300 transition-colors"
                      title={showApiKey ? 'مخفی‌سازی کلید' : 'نمایش کلید'}
                    >
                      {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
                    با وارد کردن کلید اختصاصی Google Gemini API، ربات ایمو دقیق‌ترین و بامزه‌ترین پاسخ‌های فارسی تولید شده با مدل gemini-2.5-flash را ارائه می‌دهد.
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleTestBotKey}
                    disabled={testingKey}
                    className="px-4 py-2.5 rounded-xl bg-[#1A1A28] text-slate-200 border border-[#222232] text-xs font-bold hover:text-[#C9A84C] hover:border-[#C9A84C]/40 flex items-center gap-2 transition-all disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4 text-[#C9A84C]" />
                    <span>{testingKey ? 'در حال آزمایش اتصال API...' : 'تست و اعتبارسنجی اتصال کلید API'}</span>
                  </button>
                </div>

                {testResult && (
                  <div className={`p-4 rounded-xl text-xs font-bold leading-relaxed border ${
                    testResult.success
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                      : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                  }`}>
                    {testResult.text}
                  </div>
                )}
              </div>

              {/* SECTION 2: IDENTITY & SYSTEM PROMPT */}
              <div className="glass-card p-6 rounded-2xl border border-[#222232] space-y-4">
                <h3 className="text-sm font-bold text-[#C9A84C] flex items-center gap-2">
                  <Bot className="w-4 h-4" />
                  تنظیمات شخصیت و پرامپت سیستم (Bot Persona & System Prompt)
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-2">نام ربات</label>
                    <input
                      type="text"
                      value={botForm.bot_name}
                      onChange={(e) => setBotForm({ ...botForm, bot_name: e.target.value })}
                      className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100 text-xs focus:outline-none focus:border-[#C9A84C]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-2">زبان گوینده صوتی (TTS Language)</label>
                    <input
                      type="text"
                      value={botForm.speech_lang}
                      onChange={(e) => setBotForm({ ...botForm, speech_lang: e.target.value })}
                      dir="ltr"
                      className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100 text-xs font-mono focus:outline-none focus:border-[#C9A84C]"
                      placeholder="fa-IR"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2">پیام خوشامدگویی اولیه ربات (Custom Greeting)</label>
                  <input
                    type="text"
                    value={botForm.custom_greeting}
                    onChange={(e) => setBotForm({ ...botForm, custom_greeting: e.target.value })}
                    className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100 text-xs focus:outline-none focus:border-[#C9A84C]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2">
                    دستورالعمل سیستم (Gemini System Prompt)
                  </label>
                  <textarea
                    rows={8}
                    value={botForm.system_prompt}
                    onChange={(e) => setBotForm({ ...botForm, system_prompt: e.target.value })}
                    className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100 text-xs leading-relaxed font-mono focus:outline-none focus:border-[#C9A84C]"
                    placeholder="دستورالعمل لحن، رفتار و قوانین خروجی ربات ایمو..."
                    required
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    * حتماً در دستورالعمل سیستم قید کنید که پاسخ باید یک JSON معتبر شامل کلیدهای "reply" و "emotion" باشد.
                  </p>
                </div>
              </div>

              {/* SECTION 3: VOICE & TTS CONFIGURATION */}
              <div className="glass-card p-6 rounded-2xl border border-[#222232] space-y-4">
                <h3 className="text-sm font-bold text-[#C9A84C] flex items-center gap-2">
                  <Volume2 className="w-4 h-4" />
                  تنظیمات گوینده صوتی فارسی ربات (بدون نیاز به ElevenLabs)
                </h3>

                <div className="space-y-4 p-4 rounded-xl bg-[#0A0A0F] border border-[#222232]">
                  <div>
                    <label className="block text-xs font-bold text-slate-200 mb-2">
                      انتخاب موتور اصلی تولید صدای فارسی (Primary TTS Engine):
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <label className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                        (botForm.primary_tts_engine || 'edge_neural') === 'edge_neural'
                          ? 'border-cyan-500 bg-cyan-500/10 text-cyan-200'
                          : 'border-[#222232] bg-[#12121A] text-slate-400'
                      }`}>
                        <input
                          type="radio"
                          name="primary_tts"
                          value="edge_neural"
                          checked={(botForm.primary_tts_engine || 'edge_neural') === 'edge_neural'}
                          onChange={() => setBotForm({ ...botForm, primary_tts_engine: 'edge_neural' })}
                          className="mt-1 text-cyan-500 focus:ring-cyan-500"
                        />
                        <div>
                          <div className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                            ⚡ گوینده هوشمند نیورال فارسی (رایگان و داخلی)
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                            تولید مستقیم صدای طبیعی فارسی با سرعت بالا بدون نیاز به اکانت یا هزینه ElevenLabs!
                          </p>
                        </div>
                      </label>

                      <label className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                        botForm.primary_tts_engine === 'elevenlabs'
                          ? 'border-[#C9A84C] bg-[#C9A84C]/10 text-amber-200'
                          : 'border-[#222232] bg-[#12121A] text-slate-400'
                      }`}>
                        <input
                          type="radio"
                          name="primary_tts"
                          value="elevenlabs"
                          checked={botForm.primary_tts_engine === 'elevenlabs'}
                          onChange={() => setBotForm({ ...botForm, primary_tts_engine: 'elevenlabs' })}
                          className="mt-1 text-[#C9A84C] focus:ring-[#C9A84C]"
                        />
                        <div>
                          <div className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                            💎 سرویس ElevenLabs (صدای کلون شده)
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                            استفاده از API یا شناسه صدای کلون شده اختصاصی شما در ElevenLabs.
                          </p>
                        </div>
                      </label>
                    </div>
                  </div>

                  {(botForm.primary_tts_engine || 'edge_neural') === 'edge_neural' && (
                    <div className="p-3 rounded-xl bg-[#12121A] border border-[#222232] space-y-2">
                      <label className="block text-xs font-bold text-slate-300">
                        انتخاب صدای گوینده نیورال فارسی:
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setBotForm({ ...botForm, edge_voice: 'dilara' })}
                          className={`p-2.5 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                            (botForm.edge_voice || 'dilara') === 'dilara'
                              ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200'
                              : 'border-[#222232] text-slate-400 bg-[#0A0A0F]'
                          }`}
                        >
                          <span>👧 صدای دلارا (Dilara - شاد و صمیمی)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setBotForm({ ...botForm, edge_voice: 'farid' })}
                          className={`p-2.5 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                            botForm.edge_voice === 'farid'
                              ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200'
                              : 'border-[#222232] text-slate-400 bg-[#0A0A0F]'
                          }`}
                        >
                          <span>👦 صدای فرید (Farid - محکم و رسمی)</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {botForm.primary_tts_engine === 'elevenlabs' && (
                    <div className="space-y-3 pt-2">
                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          کلید API سرویس ElevenLabs
                        </label>
                        <input
                          type="password"
                          value={botForm.elevenlabs_api_key || ''}
                          onChange={(e) => setBotForm({ ...botForm, elevenlabs_api_key: e.target.value })}
                          placeholder="sk_..."
                          className="w-full p-3 rounded-xl bg-[#12121A] border border-[#222232] text-slate-100 font-mono text-xs focus:border-[#C9A84C] outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          شناسه صدا (Voice ID کلون شده)
                        </label>
                        <input
                          type="text"
                          value={botForm.elevenlabs_voice_id || 'EXAVITQu4vr4xnSDxMaL'}
                          onChange={(e) => setBotForm({ ...botForm, elevenlabs_voice_id: e.target.value })}
                          placeholder="Voice ID کلون شده شما"
                          className="w-full p-3 rounded-xl bg-[#12121A] border border-[#222232] text-slate-100 font-mono text-xs focus:border-[#C9A84C] outline-none"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="voice_enabled_toggle"
                    checked={botForm.voice_enabled === 'true'}
                    onChange={(e) => setBotForm({ ...botForm, voice_enabled: e.target.checked ? 'true' : 'false' })}
                    className="w-5 h-5 rounded bg-[#0A0A0F] border-[#222232] text-[#C9A84C] focus:ring-[#C9A84C]"
                  />
                  <label htmlFor="voice_enabled_toggle" className="text-xs font-bold text-slate-200 cursor-pointer">
                    فعال بودن خروجی صوتی صحبت کردن ربات (Persian Speech Synthesis)
                  </label>
                </div>

                <div className="p-4 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-300 text-xs space-y-2">
                  <div className="font-bold text-[#C9A84C] flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ویژگی‌های گوینده هوشمند ایزاتس‌وب (EMO):
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px] pr-2">
                    <li><strong>۱۰۰٪ رایگان و مستقیم:</strong> بدون نیاز به ثبت‌نام یا خرید اشتراک در ElevenLabs.</li>
                    <li><strong>تلفظ هوشمند کلمات انگلیسی:</strong> کلماتی مثل React، WordPress، GTmetrix، Python و izatesweb به صورت خودکار به فونتیک روان فارسی تبدیل و تلفظ می‌شوند!</li>
                    <li><strong>بدون قطعی و پرسرعت:</strong> پاسخ صوتی فوری بلافاصله پس از تولید متن ارسال می‌گردد.</li>
                  </ul>
                </div>
              </div>

              {/* SAVE BUTTON */}
              <div className="flex items-center justify-end gap-4 pt-4 border-t border-[#222232]">
                <button
                  type="submit"
                  disabled={botSaving}
                  className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#C9A84C] to-[#E2BF5F] text-[#0A0A0F] font-black text-sm shadow-xl shadow-[#C9A84C]/20 hover:scale-105 transition-transform flex items-center gap-2 disabled:opacity-50"
                >
                  <Check className="w-5 h-5" />
                  <span>{botSaving ? 'در حال ذخیره‌سازی...' : 'ذخیره تنظیمات ربات ایمو'}</span>
                </button>
              </div>

            </form>
          </div>
        )}

      </div>

      {/* Project Modal */}
      {projectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#12121A] border border-[#222232] rounded-2xl max-w-lg w-full p-6 relative shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setProjectModalOpen(false)}
              className="absolute top-4 left-4 p-2 rounded-lg bg-[#0A0A0F] text-slate-400"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-slate-100 mb-4">
              {editingProject ? 'ویرایش نمونه‌کار' : 'افزودن نمونه‌کار جدید'}
            </h3>

            {uploadError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between">
                <span>{uploadError}</span>
                <button type="button" onClick={() => setUploadError(null)} className="text-rose-400 font-bold p-1">✕</button>
              </div>
            )}

            <form onSubmit={handleSaveProject} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">عنوان پروژه</label>
                <input
                  type="text"
                  value={projectForm.title}
                  onChange={(e) => setProjectForm({ ...projectForm, title: e.target.value })}
                  className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">دسته‌بندی</label>
                <select
                  value={projectForm.category}
                  onChange={(e) => setProjectForm({ ...projectForm, category: e.target.value })}
                  className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100"
                >
                  <option value="وردپرس">وردپرس</option>
                  <option value="فروشگاهی">فروشگاهی</option>
                  <option value="شرکتی">شرکتی</option>
                  <option value="اختصاصی">اختصاصی</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">توضیحات</label>
                <textarea
                  rows={3}
                  value={projectForm.description}
                  onChange={(e) => setProjectForm({ ...projectForm, description: e.target.value })}
                  className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100"
                  required
                />
              </div>

              {/* Image Upload & Management for Project */}
              <div className="space-y-2 p-3 rounded-xl bg-[#0A0A0F] border border-[#222232]">
                <div className="flex items-center justify-between">
                  <label className="block font-bold text-slate-300">تصویر کاور نمونه‌کار</label>
                  {projectForm.image_url && (
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(projectForm.image_url, () => setProjectForm(prev => ({ ...prev, image_url: '' })))}
                      className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 font-bold px-2 py-1 rounded bg-rose-500/10 border border-rose-500/20"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>حذف تصویر</span>
                    </button>
                  )}
                </div>

                {/* Image Preview if present */}
                {projectForm.image_url ? (
                  <div className="relative rounded-xl overflow-hidden border border-[#222232] h-40 bg-black/40 group">
                    <img
                      src={projectForm.image_url}
                      alt="Project Preview"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(projectForm.image_url, () => setProjectForm(prev => ({ ...prev, image_url: '' })))}
                        className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold flex items-center gap-1.5 shadow"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>حذف تصویر فعلی</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-[#222232] hover:border-[#C9A84C]/50 rounded-xl p-4 text-center transition-colors">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <div className="w-10 h-10 rounded-full bg-[#12121A] text-[#C9A84C] flex items-center justify-center border border-[#222232]">
                        {uploadingImage ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
                      </div>
                      <p className="text-xs font-bold text-slate-300">
                        {uploadingImage ? 'در حال آپلود و بهینه‌سازی تصویر...' : 'آپلود مستقیم از حافظه دیوایس (گوشی / لپ‌تاپ)'}
                      </p>
                      <p className="text-[10px] text-slate-500">پشتیبانی از JPG, PNG, WebP (حداکثر ۱۵ مگابایت)</p>
                      
                      <label className="mt-1 cursor-pointer px-4 py-2 rounded-xl bg-[#C9A84C] text-[#0A0A0F] font-black text-xs inline-flex items-center gap-1.5 shadow-lg shadow-[#C9A84C]/20 hover:scale-105 transition-transform">
                        <Upload className="w-3.5 h-3.5" />
                        <span>انتخاب تصویر از دیوایس</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          disabled={uploadingImage}
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              handleDeviceImageUpload(file, (url) => setProjectForm(prev => ({ ...prev, image_url: url })));
                            }
                          }}
                        />
                      </label>
                    </div>
                  </div>
                )}

                {/* Direct URL input fallback */}
                <div className="pt-2 border-t border-[#222232]/60 mt-2">
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="flex items-center gap-1 text-slate-400">
                      <LinkIcon className="w-3 h-3 text-[#C9A84C]" />
                      <span>آدرس فایل تصویر در هاست یا وب (URL):</span>
                    </span>
                    {projectForm.image_url && (
                      <span className="text-[10px] text-emerald-400 font-bold">✓ تصویر تنظیم شد</span>
                    )}
                  </div>
                  <input
                    type="text"
                    dir="ltr"
                    placeholder="پس از انتخاب از دیوایس، به صورت خودکار پر می‌شود یا آدرس دستی وارد کنید"
                    value={projectForm.image_url}
                    onChange={(e) => setProjectForm({ ...projectForm, image_url: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-[#12121A] border border-[#222232] text-slate-200 text-xs focus:border-[#C9A84C]/50 focus:outline-none"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    هنگامی که عکس را با دکمه بالا از دیوایس خود انتخاب می‌کنید، در هاست ذخیره شده و آدرس آن خودکار اینجا قرار می‌گیرد و نیازی به تایپ دستی نیست.
                  </p>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">لینک پیش‌نمایش (اختیاری)</label>
                <input
                  type="url"
                  dir="ltr"
                  value={projectForm.link}
                  onChange={(e) => setProjectForm({ ...projectForm, link: e.target.value })}
                  className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">تگ‌ها (با ویرگول جدا کنید)</label>
                <input
                  type="text"
                  value={projectForm.tags}
                  onChange={(e) => setProjectForm({ ...projectForm, tags: e.target.value })}
                  className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#C9A84C] text-[#0A0A0F] font-bold text-sm shadow-lg mt-2"
              >
                ذخیره نمونه‌کار
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Team Modal */}
      {teamModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#12121A] border border-[#222232] rounded-2xl max-w-lg w-full p-6 relative shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setTeamModalOpen(false)}
              className="absolute top-4 left-4 p-2 rounded-lg bg-[#0A0A0F] text-slate-400"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-slate-100 mb-4">
              {editingMember ? 'ویرایش عضو تیم' : 'افزودن عضو جدید'}
            </h3>

            {uploadError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between">
                <span>{uploadError}</span>
                <button type="button" onClick={() => setUploadError(null)} className="text-rose-400 font-bold p-1">✕</button>
              </div>
            )}

            <form onSubmit={handleSaveTeam} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">نام و نام خانوادگی</label>
                <input
                  type="text"
                  value={teamForm.name}
                  onChange={(e) => setTeamForm({ ...teamForm, name: e.target.value })}
                  className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">سمت شغلی</label>
                <input
                  type="text"
                  value={teamForm.role}
                  onChange={(e) => setTeamForm({ ...teamForm, role: e.target.value })}
                  className="w-full p-3 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-100"
                  required
                />
              </div>

              {/* Image Upload & Management for Team Member */}
              <div className="space-y-2 p-3 rounded-xl bg-[#0A0A0F] border border-[#222232]">
                <div className="flex items-center justify-between">
                  <label className="block font-bold text-slate-300">تصویر پرتره عضو تیم</label>
                  {teamForm.image_url && (
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(teamForm.image_url, () => setTeamForm(prev => ({ ...prev, image_url: '' })))}
                      className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 font-bold px-2 py-1 rounded bg-rose-500/10 border border-rose-500/20"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>حذف تصویر</span>
                    </button>
                  )}
                </div>

                {/* Portrait Preview */}
                {teamForm.image_url ? (
                  <div className="flex items-center gap-4 p-2 rounded-xl bg-[#12121A] border border-[#222232]">
                    <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-[#C9A84C] flex-shrink-0 group">
                      <img
                        src={teamForm.image_url}
                        alt="Portrait Preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-slate-200 font-bold truncate">تصویر انتخاب شده</p>
                      <p className="text-[10px] text-slate-400 truncate dir-ltr">{teamForm.image_url}</p>
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(teamForm.image_url, () => setTeamForm(prev => ({ ...prev, image_url: '' })))}
                        className="mt-1 text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 font-bold"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>حذف و تغییر تصویر</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-[#222232] hover:border-[#C9A84C]/50 rounded-xl p-4 text-center transition-colors">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <div className="w-10 h-10 rounded-full bg-[#12121A] text-[#C9A84C] flex items-center justify-center border border-[#222232]">
                        {uploadingImage ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
                      </div>
                      <p className="text-xs font-bold text-slate-300">
                        {uploadingImage ? 'در حال آپلود و ذخیره‌سازی تصویر...' : 'آپلود عکس پرتره از دیوایس'}
                      </p>
                      <p className="text-[10px] text-slate-500">پشتیبانی از عکس‌های پرتره JPG, PNG, WebP</p>
                      
                      <label className="mt-1 cursor-pointer px-4 py-2 rounded-xl bg-[#C9A84C] text-[#0A0A0F] font-black text-xs inline-flex items-center gap-1.5 shadow-lg shadow-[#C9A84C]/20 hover:scale-105 transition-transform">
                        <Upload className="w-3.5 h-3.5" />
                        <span>انتخاب عکس پرتره از دیوایس</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          disabled={uploadingImage}
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              handleDeviceImageUpload(file, (url) => setTeamForm(prev => ({ ...prev, image_url: url })));
                            }
                          }}
                        />
                      </label>
                    </div>
                  </div>
                )}

                {/* Fallback URL input */}
                <div className="pt-2 border-t border-[#222232]/60 mt-2">
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="flex items-center gap-1 text-slate-400">
                      <LinkIcon className="w-3 h-3 text-[#C9A84C]" />
                      <span>آدرس فایل تصویر در هاست یا وب (URL):</span>
                    </span>
                    {teamForm.image_url && (
                      <span className="text-[10px] text-emerald-400 font-bold">✓ تصویر تنظیم شد</span>
                    )}
                  </div>
                  <input
                    type="text"
                    dir="ltr"
                    placeholder="پس از انتخاب از دیوایس، به صورت خودکار پر می‌شود یا آدرس دستی وارد کنید"
                    value={teamForm.image_url}
                    onChange={(e) => setTeamForm({ ...teamForm, image_url: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-[#12121A] border border-[#222232] text-slate-200 text-xs focus:border-[#C9A84C]/50 focus:outline-none"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    هنگامی که عکس را با دکمه بالا از دیوایس خود انتخاب می‌کنید، در هاست ذخیره شده و آدرس آن خودکار اینجا قرار می‌گیرد و نیازی به تایپ دستی نیست.
                  </p>
                </div>
              </div>

              {/* Social Media Inputs - ID only or full link auto-complete */}
              <div className="space-y-3 p-3 rounded-xl bg-[#0A0A0F] border border-[#222232]">
                <div className="flex items-center gap-1.5 font-bold text-slate-300">
                  <Sparkles className="w-4 h-4 text-[#C9A84C]" />
                  <span>شبکه‌های اجتماعی (کافیست فقط آیدی را بدون @ یا با @ وارد کنید):</span>
                </div>

                {/* Instagram */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="flex items-center gap-1.5 font-medium text-slate-300">
                      <Instagram className="w-3.5 h-3.5 text-pink-400" />
                      <span>اینستاگرام</span>
                    </label>
                    {teamForm.instagram && (
                      <span className="text-[10px] text-slate-500 font-mono dir-ltr">
                        {formatSocialLink('instagram', teamForm.instagram)}
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      dir="ltr"
                      placeholder="مثال: izatesweb یا myusername"
                      value={teamForm.instagram}
                      onChange={(e) => setTeamForm({ ...teamForm, instagram: e.target.value })}
                      className="w-full p-2.5 rounded-lg bg-[#12121A] border border-[#222232] text-slate-100 pl-24"
                    />
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-mono">
                      instagram.com/
                    </span>
                  </div>
                </div>

                {/* Telegram */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="flex items-center gap-1.5 font-medium text-slate-300">
                      <Send className="w-3.5 h-3.5 text-sky-400" />
                      <span>تلگرام</span>
                    </label>
                    {teamForm.telegram && (
                      <span className="text-[10px] text-slate-500 font-mono dir-ltr">
                        {formatSocialLink('telegram', teamForm.telegram)}
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      dir="ltr"
                      placeholder="مثال: izates یا username"
                      value={teamForm.telegram}
                      onChange={(e) => setTeamForm({ ...teamForm, telegram: e.target.value })}
                      className="w-full p-2.5 rounded-lg bg-[#12121A] border border-[#222232] text-slate-100 pl-14"
                    />
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-mono">
                      t.me/
                    </span>
                  </div>
                </div>

                {/* LinkedIn */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="flex items-center gap-1.5 font-medium text-slate-300">
                      <Linkedin className="w-3.5 h-3.5 text-blue-400" />
                      <span>لینکدین (اختیاری)</span>
                    </label>
                    {teamForm.linkedin && (
                      <span className="text-[10px] text-slate-500 font-mono dir-ltr">
                        {formatSocialLink('linkedin', teamForm.linkedin)}
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      dir="ltr"
                      placeholder="مثال: rezakhabazi یا username"
                      value={teamForm.linkedin}
                      onChange={(e) => setTeamForm({ ...teamForm, linkedin: e.target.value })}
                      className="w-full p-2.5 rounded-lg bg-[#12121A] border border-[#222232] text-slate-100 pl-24"
                    />
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-mono">
                      linkedin.com/in/
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#C9A84C] text-[#0A0A0F] font-bold text-sm shadow-lg mt-2"
              >
                ذخیره اطلاعات عضو
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {confirmModal.isOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#12121A] border border-[#222232] rounded-2xl max-w-sm w-full p-6 relative shadow-2xl text-center"
          >
            <div className="w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-100 mb-2">{confirmModal.title}</h3>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">{confirmModal.message}</p>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                className="flex-1 py-2.5 rounded-xl bg-[#0A0A0F] border border-[#222232] text-slate-300 text-xs font-bold hover:bg-[#1A1A28] transition-colors"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={confirmModal.onConfirm}
                className="flex-1 py-2.5 rounded-xl bg-rose-500 text-white text-xs font-bold hover:bg-rose-600 transition-colors shadow-lg shadow-rose-500/20"
              >
                {confirmModal.confirmText}
              </button>
            </div>
          </motion.div>
        </div>
      )}

    </div>
  );
};
