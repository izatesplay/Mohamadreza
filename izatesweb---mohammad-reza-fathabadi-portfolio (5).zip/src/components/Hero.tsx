import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, ArrowRight, Sparkles, CheckCircle2, ShieldCheck, Zap, Laptop, Code2, Bot } from 'lucide-react';
import { EmoRobot } from './EmoRobot';
import { useLanguage } from '../context/LanguageContext';

export const Hero: React.FC = () => {
  const [typedTitleIndex, setTypedTitleIndex] = useState(0);
  const { t, direction } = useLanguage();

  const titles = [
    t('title1'),
    t('title2'),
    t('title3'),
    t('title4'),
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setTypedTitleIndex((prev) => (prev + 1) % titles.length);
    }, 3500);
    return () => clearInterval(timer);
  }, [titles.length]);

  const stats = [
    { number: '+۵۰', label: t('stat1Label'), icon: Laptop },
    { number: '۵+', label: t('stat2Label'), icon: ShieldCheck },
    { number: '۱۰۰٪', label: t('stat3Label'), icon: CheckCircle2 },
    { number: 'A+', label: t('stat4Label'), icon: Zap },
  ];

  const ArrowIcon = direction === 'rtl' ? ArrowLeft : ArrowRight;

  return (
    <section id="hero" className="relative min-h-screen pt-32 pb-20 flex flex-col items-center justify-center overflow-hidden">
      
      {/* Background Animated Gradient Glowing Orbs */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[var(--color-accent-primary)]/15 rounded-full blur-[120px] pointer-events-none animate-pulse" />
      <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-[#7C3AED]/15 rounded-full blur-[140px] pointer-events-none animate-pulse delay-1000" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#12121a_1px,transparent_1px),linear-gradient(to_bottom,#12121a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center z-10 w-full">
        
        {/* Top Floating Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[var(--color-surface)] border border-[var(--color-accent-primary)]/30 text-[var(--color-accent-primary)] text-xs sm:text-sm font-semibold mb-8 shadow-xl shadow-[var(--color-accent-primary)]/10 backdrop-blur-md"
        >
          <Sparkles className="w-4 h-4 animate-spin text-[var(--color-accent-primary)]" />
          <span>{t('officialBadge')}</span>
        </motion.div>

        {/* Main Name & Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-4xl sm:text-6xl md:text-7xl font-black text-[var(--color-text-primary)] tracking-tight leading-tight mb-6"
        >
          {t('designerName')}
        </motion.h1>

        {/* Dynamic Animated Subtitle */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="h-12 flex items-center justify-center mb-8"
        >
          <span className="text-xl sm:text-2xl md:text-3xl font-bold text-accent-gradient">
            {titles[typedTitleIndex]}
          </span>
        </motion.div>

        {/* Description Text */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="max-w-3xl mx-auto text-base sm:text-lg text-[var(--color-text-secondary)] leading-relaxed font-light mb-10"
        >
          {t('heroDesc')}
        </motion.p>

        {/* Action Call to Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-14"
        >
          <a
            href="#order"
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-[var(--color-accent-primary)] via-[var(--color-accent-hover)] to-[var(--color-accent-primary)] text-[var(--color-background)] font-extrabold text-base flex items-center justify-center gap-3 shadow-xl shadow-[var(--color-accent-primary)]/25 hover:shadow-[var(--color-accent-primary)]/40 hover:scale-105 transition-all duration-300 group"
          >
            <span>{t('heroOrderBtn')}</span>
            <ArrowIcon className={`w-5 h-5 transition-transform duration-300 ${direction === 'rtl' ? 'group-hover:-translate-x-1' : 'group-hover:translate-x-1'}`} />
          </a>

          <a
            href="#projects"
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-[var(--color-surface)] text-[var(--color-text-primary)] border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/60 hover:text-[var(--color-accent-primary)] font-semibold text-base flex items-center justify-center gap-2 backdrop-blur-md transition-all duration-300 shadow-lg"
          >
            <Code2 className="w-5 h-5 text-[var(--color-accent-primary)]" />
            <span>{t('heroProjectsBtn')}</span>
          </a>
        </motion.div>

        {/* EMO ROBOT INTEGRATED HERO FEATURE */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.45 }}
          className="my-10 w-full flex flex-col items-center justify-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-bold mb-4">
            <Bot className="w-4 h-4 text-cyan-400 animate-bounce" />
            <span>{t('botBanner')}</span>
          </div>

          <EmoRobot className="w-full" />
        </motion.div>

        {/* Key Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto mt-12"
        >
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={idx}
                className="glass-card p-6 rounded-2xl flex flex-col items-center justify-center text-center group hover:border-[var(--color-accent-primary)]/40 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-[var(--color-accent-primary)]/10 border border-[var(--color-accent-primary)]/20 flex items-center justify-center mb-3 text-[var(--color-accent-primary)] group-hover:scale-110 transition-transform">
                  <Icon className="w-6 h-6" />
                </div>
                <span className="text-2xl sm:text-3xl font-black text-[var(--color-text-primary)] mb-1" dir="ltr">
                  {stat.number}
                </span>
                <span className="text-xs sm:text-sm text-[var(--color-text-muted)] font-medium">
                  {stat.label}
                </span>
              </div>
            );
          })}
        </motion.div>

      </div>
    </section>
  );
};

