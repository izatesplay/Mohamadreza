import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Users, Instagram, Send, Linkedin, Github, Globe } from 'lucide-react';
import { TeamMember } from '../types';
import { useLanguage } from '../context/LanguageContext';

export const Team: React.FC = () => {
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const { t } = useLanguage();

  const fetchTeam = async () => {
    try {
      const res = await fetch('/api/team');
      if (res.ok) {
        const data = await res.json();
        setTeam(data);
      }
    } catch (err) {
      console.error('Failed to fetch team members:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTeam();
  }, []);

  const normalizeSocialUrl = (key: string, value: string): string => {
    let val = (value || '').trim();
    if (!val) return '';
    if (val.startsWith('http://') || val.startsWith('https://')) return val;
    val = val.replace(/^@+/, '');
    const k = key.toLowerCase();
    if (k === 'instagram') return `https://instagram.com/${val}`;
    if (k === 'telegram') return `https://t.me/${val}`;
    if (k === 'linkedin') return `https://linkedin.com/in/${val}`;
    if (k === 'github') return `https://github.com/${val}`;
    return `https://${val}`;
  };

  const renderSocialIcon = (key: string) => {
    switch (key.toLowerCase()) {
      case 'instagram': return <Instagram className="w-4 h-4" />;
      case 'telegram': return <Send className="w-4 h-4" />;
      case 'linkedin': return <Linkedin className="w-4 h-4" />;
      case 'github': return <Github className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  return (
    <section id="team" className="py-24 relative bg-[var(--color-surface)]/60 border-y border-[var(--color-border)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="text-xs sm:text-sm font-bold text-[var(--color-accent-primary)] uppercase tracking-widest bg-[var(--color-accent-primary)]/10 px-3.5 py-1.5 rounded-full border border-[var(--color-accent-primary)]/20 inline-block mb-3">
            {t('teamBadge')}
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[var(--color-text-primary)] tracking-tight">
            {t('teamHeading')}
          </h2>
          <p className="mt-4 text-[var(--color-text-muted)] text-base leading-relaxed">
            {t('teamSubheading')}
          </p>
        </motion.div>

        {/* Team Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((n) => (
              <div key={n} className="glass-card rounded-2xl p-6 text-center animate-pulse">
                <div className="w-32 h-32 bg-slate-800/50 rounded-full mx-auto mb-4" />
                <div className="h-5 bg-slate-800/50 rounded w-1/2 mx-auto mb-2" />
                <div className="h-4 bg-slate-800/50 rounded w-3/4 mx-auto" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, idx) => {
              let socials: Record<string, string> = {};
              try {
                socials = typeof member.socials_json === 'string' ? JSON.parse(member.socials_json) : (member.socials_json || {});
              } catch (e) {
                socials = {};
              }

              return (
                <motion.div
                  initial={{ opacity: 0, y: 25 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-30px' }}
                  transition={{ duration: 0.5, delay: idx * 0.1 }}
                  whileHover={{ y: -8 }}
                  key={member.id}
                  className="glass-card rounded-2xl p-6 text-center border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/40 transition-all duration-300 relative group"
                >
                  {/* Photo with glowing ring */}
                  <div className="relative w-36 h-36 mx-auto mb-6">
                    <div className="absolute -inset-1.5 bg-gradient-to-tr from-[var(--color-accent-primary)] to-[var(--color-accent-secondary)] rounded-full blur-sm opacity-50 group-hover:opacity-100 transition-opacity" />
                    <img
                      src={member.image_url}
                      alt={member.name}
                      className="relative w-full h-full object-cover rounded-full border-2 border-[var(--color-surface)] shadow-xl"
                    />
                  </div>

                  <h3 className="text-xl font-bold text-[var(--color-text-primary)] mb-1">
                    {member.name}
                  </h3>

                  <p className="text-sm text-[var(--color-accent-primary)] font-semibold mb-4">
                    {member.role}
                  </p>

                  {/* Social links */}
                  <div className="flex items-center justify-center gap-2 pt-4 border-t border-[var(--color-border)]">
                    {Object.entries(socials).map(([key, url]) => {
                      const fullUrl = normalizeSocialUrl(key, url);
                      if (!fullUrl) return null;
                      return (
                        <a
                          key={key}
                          href={fullUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2.5 rounded-xl bg-[var(--color-background)] text-[var(--color-text-muted)] hover:text-[var(--color-accent-primary)] border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/50 transition-colors"
                          title={key}
                        >
                          {renderSocialIcon(key)}
                        </a>
                      );
                    })}
                  </div>

                </motion.div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
