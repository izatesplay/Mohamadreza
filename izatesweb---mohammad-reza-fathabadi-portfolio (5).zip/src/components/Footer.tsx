import React from 'react';
import { Code, Heart, ArrowUp, Phone, Mail, MapPin } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[var(--color-background)] border-t border-[var(--color-border)] pt-16 pb-12 relative text-[var(--color-text-muted)] text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[var(--color-border)]">
          
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[var(--color-accent-primary)] to-[var(--color-accent-secondary)] p-[1px] shadow-lg">
                <div className="w-full h-full bg-[var(--color-background)] rounded-[11px] flex items-center justify-center">
                  <Code className="w-5 h-5 text-[var(--color-accent-primary)]" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-black text-gold-gradient">
                  izatesweb
                </span>
                <span className="text-xs text-[var(--color-text-muted)] font-medium">
                  {t('footerSubtitle')}
                </span>
              </div>
            </div>

            <p className="text-[var(--color-text-muted)] text-xs sm:text-sm font-light leading-relaxed max-w-md">
              {t('footerDesc')}
            </p>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-[var(--color-text-primary)] font-bold text-sm">{t('quickLinks')}</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#hero" className="hover:text-[var(--color-accent-primary)] transition-colors">{t('navHome')}</a></li>
              <li><a href="#about" className="hover:text-[var(--color-accent-primary)] transition-colors">{t('navAbout')}</a></li>
              <li><a href="#projects" className="hover:text-[var(--color-accent-primary)] transition-colors">{t('navProjects')}</a></li>
              <li><a href="#team" className="hover:text-[var(--color-accent-primary)] transition-colors">{t('navTeam')}</a></li>
              <li><a href="#order" className="hover:text-[var(--color-accent-primary)] transition-colors">{t('navOrder')}</a></li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-[var(--color-text-primary)] font-bold text-sm">{t('contactInfo')}</h4>
            <div className="space-y-2.5 text-xs font-medium">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[var(--color-accent-primary)]" />
                <span dir="ltr">0992 175 8505</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[var(--color-accent-primary)]" />
                <span>izatesplay@gmail.com</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[var(--color-accent-primary)]" />
                <span>{t('addressValue')}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-light">
          <p>© {new Date().getFullYear()} izatesweb. {t('copyright')}</p>

          <button
            onClick={scrollToTop}
            className="p-3 rounded-xl bg-[var(--color-surface)] text-[var(--color-text-secondary)] hover:text-[var(--color-accent-primary)] border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/50 transition-colors flex items-center gap-1.5 font-bold cursor-pointer"
            title={t('backToTop')}
          >
            <span>{t('backToTop')}</span>
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>
    </footer>
  );
};
