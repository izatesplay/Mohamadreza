import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUp } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const BackToTop: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const { t, direction } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setVisible(true);
      } else {
        setVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 20 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          onClick={scrollToTop}
          aria-label={t('backToTop')}
          title={t('backToTop')}
          className={`fixed bottom-6 ${direction === 'rtl' ? 'left-6' : 'right-6'} z-40 p-3.5 rounded-2xl bg-[var(--color-surface)]/90 backdrop-blur-md text-[var(--color-accent-primary)] border border-[var(--color-accent-primary)]/40 shadow-2xl hover:bg-[var(--color-accent-primary)] hover:text-[var(--color-background)] hover:scale-110 active:scale-95 transition-all group flex items-center gap-2`}
        >
          <ArrowUp className="w-5 h-5 group-hover:-translate-y-0.5 transition-transform" />
          <span className="text-xs font-bold hidden sm:inline-block pr-1">
            {t('backToTop')}
          </span>
        </motion.button>
      )}
    </AnimatePresence>
  );
};
