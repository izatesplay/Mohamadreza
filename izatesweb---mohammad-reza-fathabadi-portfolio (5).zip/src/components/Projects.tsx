import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Eye, X, Layers, Sparkles, Filter, Monitor, Laptop, Smartphone } from 'lucide-react';
import { Project } from '../types';
import { useLanguage } from '../context/LanguageContext';

export const Projects: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategoryKey, setSelectedCategoryKey] = useState<string>('all');
  const [activeProjectModal, setActiveProjectModal] = useState<Project | null>(null);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'laptop' | 'mobile'>('desktop');
  const { t, direction } = useLanguage();

  const categoryMap: { key: string; label: string }[] = [
    { key: 'all', label: t('catAll') },
    { key: 'wordpress', label: t('catWordPress') },
    { key: 'store', label: t('catStore') },
    { key: 'corporate', label: t('catCorporate') },
    { key: 'custom', label: t('catCustom') },
  ];

  const fetchProjects = async () => {
    try {
      const res = await fetch('/api/projects');
      if (res.ok) {
        const data = await res.json();
        setProjects(data);
      }
    } catch (err) {
      console.error('Failed to fetch projects:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const selectedCategoryLabel = categoryMap.find(c => c.key === selectedCategoryKey)?.label || t('catAll');

  const filteredProjects = selectedCategoryKey === 'all'
    ? projects
    : projects.filter(p => {
        if (selectedCategoryKey === 'wordpress') return p.category === 'وردپرس' || p.category === 'WordPress' || p.tags?.includes('WordPress') || p.tags?.includes('وردپرس');
        if (selectedCategoryKey === 'store') return p.category === 'فروشگاهی' || p.category === 'Store' || p.category === 'E-Commerce' || p.tags?.includes('فروشگاهی');
        if (selectedCategoryKey === 'corporate') return p.category === 'شرکتی' || p.category === 'Corporate' || p.tags?.includes('شرکتی');
        if (selectedCategoryKey === 'custom') return p.category === 'اختصاصی' || p.category === 'Custom' || p.tags?.includes('اختصاصی') || p.tags?.includes('React');
        return p.category === selectedCategoryLabel || (p.tags && p.tags.includes(selectedCategoryLabel));
      });

  return (
    <section id="projects" className="py-24 relative bg-[var(--color-background)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-12"
        >
          <span className="text-xs sm:text-sm font-bold text-[var(--color-accent-primary)] uppercase tracking-widest bg-[var(--color-accent-primary)]/10 px-3.5 py-1.5 rounded-full border border-[var(--color-accent-primary)]/20 inline-block mb-3">
            {t('projectsBadge')}
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[var(--color-text-primary)] tracking-tight">
            {t('projectsHeading')}
          </h2>
          <p className="mt-4 text-[var(--color-text-muted)] text-base leading-relaxed">
            {t('projectsSubheading')}
          </p>
        </motion.div>

        {/* Filter Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-30px' }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex flex-wrap items-center justify-center gap-2 mb-12"
        >
          {categoryMap.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedCategoryKey(cat.key)}
              className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 flex items-center gap-2 ${
                selectedCategoryKey === cat.key
                  ? 'bg-gradient-to-r from-[var(--color-accent-primary)] to-[var(--color-accent-hover)] text-[var(--color-background)] shadow-lg shadow-[var(--color-accent-primary)]/20 scale-105'
                  : 'bg-[var(--color-surface)] text-[var(--color-text-muted)] border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/40 hover:text-[var(--color-text-secondary)]'
              }`}
            >
              {cat.key === 'all' && <Layers className="w-4 h-4" />}
              <span>{cat.label}</span>
            </button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((n) => (
              <div key={n} className="glass-card rounded-2xl p-4 animate-pulse">
                <div className="w-full h-56 bg-slate-800/50 rounded-xl mb-4" />
                <div className="h-6 bg-slate-800/50 rounded w-3/4 mb-3" />
                <div className="h-4 bg-slate-800/50 rounded w-full mb-2" />
                <div className="h-4 bg-slate-800/50 rounded w-2/3 mb-4" />
              </div>
            ))}
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="text-center py-16 glass-panel rounded-2xl border border-[var(--color-border)]">
            <Filter className="w-12 h-12 text-[var(--color-text-muted)] mx-auto mb-3" />
            <p className="text-[var(--color-text-muted)] font-medium text-lg">{t('noProjectsFound')}</p>
          </div>
        ) : (
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredProjects.map((project, idx) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-30px' }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                key={project.id}
                className="glass-card rounded-2xl overflow-hidden group flex flex-col justify-between border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/50 transition-all duration-300 shadow-xl"
              >
                {/* Image Container */}
                <div className="relative overflow-hidden h-60 bg-[var(--color-surface)]">
                  <img
                    src={project.image_url}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-background)] via-transparent to-transparent opacity-80" />
                  
                  {/* Category Badge */}
                  <span className={`absolute top-4 ${direction === 'rtl' ? 'right-4' : 'left-4'} px-3 py-1 rounded-lg bg-[var(--color-background)]/80 backdrop-blur-md border border-[var(--color-accent-primary)]/30 text-[var(--color-accent-primary)] text-xs font-bold shadow-lg`}>
                    {project.category}
                  </span>

                  {/* Quick Action Overlay */}
                  <div className="absolute inset-0 bg-[var(--color-background)]/60 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                    <button
                      onClick={() => setActiveProjectModal(project)}
                      className="p-3 rounded-xl bg-[var(--color-surface)] text-[var(--color-text-primary)] hover:text-[var(--color-accent-primary)] border border-[var(--color-border)] hover:border-[var(--color-accent-primary)] shadow-lg transition-transform hover:scale-110 flex items-center gap-1.5 text-xs font-bold"
                    >
                      <Eye className="w-4 h-4" />
                      <span>{t('detailsBtn')}</span>
                    </button>

                    {project.link && (
                      <a
                        href={project.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-3 rounded-xl bg-[var(--color-accent-primary)] text-[var(--color-background)] hover:bg-[var(--color-accent-hover)] shadow-lg transition-transform hover:scale-110 flex items-center gap-1.5 text-xs font-bold"
                      >
                        <ExternalLink className="w-4 h-4" />
                        <span>{t('liveDemoBtn')}</span>
                      </a>
                    )}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-[var(--color-text-primary)] group-hover:text-[var(--color-accent-primary)] transition-colors mb-2">
                      {project.title}
                    </h3>
                    <p className="text-[var(--color-text-muted)] text-xs sm:text-sm line-clamp-3 leading-relaxed mb-4 font-light">
                      {project.description}
                    </p>
                  </div>

                  {/* Tech Tags - Strict LTR for English Frameworks */}
                  <div dir="ltr" className="pt-4 border-t border-[var(--color-border)] flex flex-wrap items-center gap-1.5 justify-start">
                    {project.tags.split(',').map((tag, i) => (
                      <span
                        key={i}
                        dir="ltr"
                        className="px-2.5 py-1 rounded-md bg-[var(--color-surface)] text-[var(--color-text-secondary)] border border-[var(--color-border)] text-[11px] font-mono font-medium"
                      >
                        {tag.trim()}
                      </span>
                    ))}
                  </div>
                </div>

              </motion.div>
            ))}
          </motion.div>
        )}

      </div>

      {/* Project Detail Modal with Interactive Device Studio Viewport */}
      <AnimatePresence>
        {activeProjectModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 20 }}
              transition={{ duration: 0.3 }}
              className="bg-[#0d0f17] border border-[#D4AF37]/35 rounded-2xl max-w-4xl w-full p-4 sm:p-7 relative shadow-[0_25px_80px_rgba(0,0,0,0.9)] overflow-hidden my-auto max-h-[92vh] flex flex-col"
            >
              {/* Top Modal Header */}
              <div className="flex items-center justify-between pb-4 border-b border-[#1e2436] shrink-0 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#D4AF37] shadow-[0_0_10px_#D4AF37]" />
                  <span className="text-xs font-mono font-bold text-[#D4AF37] uppercase tracking-widest">
                    STUDIO VIEWPORT INSPECTOR
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Interactive Device Viewport Mode Switcher */}
                  <div className="flex items-center bg-[#141824] p-1 rounded-xl border border-[#1e2436] gap-1">
                    <button
                      onClick={() => setPreviewDevice('desktop')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                        previewDevice === 'desktop'
                          ? 'bg-[#D4AF37] text-[#08090E] font-bold shadow-md'
                          : 'text-[#94A3B8] hover:text-white'
                      }`}
                      title="نمایشگر دسکتاپ 5K"
                    >
                      <Monitor className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Desktop</span>
                    </button>

                    <button
                      onClick={() => setPreviewDevice('laptop')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                        previewDevice === 'laptop'
                          ? 'bg-[#D4AF37] text-[#08090E] font-bold shadow-md'
                          : 'text-[#94A3B8] hover:text-white'
                      }`}
                      title="مک‌بوک پرو ۱۶ اینچ"
                    >
                      <Laptop className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">MacBook</span>
                    </button>

                    <button
                      onClick={() => setPreviewDevice('mobile')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                        previewDevice === 'mobile'
                          ? 'bg-[#D4AF37] text-[#08090E] font-bold shadow-md'
                          : 'text-[#94A3B8] hover:text-white'
                      }`}
                      title="آیفون ۱۶ پرو"
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">iPhone</span>
                    </button>
                  </div>

                  <button
                    onClick={() => setActiveProjectModal(null)}
                    className="p-1.5 rounded-xl bg-[#141824] hover:bg-[#1e2436] text-[#94A3B8] hover:text-white transition-colors cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Scrollable Modal Content */}
              <div className="overflow-y-auto flex-1 custom-scrollbar pr-1 space-y-5">
                {/* Simulated Hardware Frame */}
                <div className="flex justify-center items-center py-2 bg-[#08090E]/60 rounded-2xl border border-[#1e2436] p-3">
                  <div
                    className={`transition-all duration-500 ease-out overflow-hidden shadow-2xl relative ${
                      previewDevice === 'desktop'
                        ? 'w-full max-w-2xl rounded-xl border-4 border-[#222232] bg-[#12121A]'
                        : previewDevice === 'laptop'
                        ? 'w-full max-w-lg rounded-t-xl border-4 border-[#2a2a3c] bg-[#12121A]'
                        : 'w-[260px] h-[380px] rounded-[32px] border-[6px] border-[#222232] bg-[#12121A] relative'
                    }`}
                  >
                    {/* Simulated Camera Notch / Dynamic Island for Mobile */}
                    {previewDevice === 'mobile' && (
                      <div className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-4 bg-black rounded-full z-20 flex items-center justify-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#1e2436]" />
                      </div>
                    )}

                    <div className="relative overflow-hidden w-full h-56 sm:h-72">
                      <img
                        src={activeProjectModal.image_url}
                        alt={activeProjectModal.title}
                        className="w-full h-full object-cover filter brightness-95 hover:scale-105 transition-transform duration-700"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>
                </div>

                {/* Metadata & Title */}
                <div>
                  <span className="inline-block px-3 py-1 rounded-lg bg-[#D4AF37]/15 text-[#F3E5AB] text-xs font-bold border border-[#D4AF37]/30 mb-2">
                    دسته‌بندی: {activeProjectModal.category}
                  </span>

                  <h3 className="text-xl sm:text-2xl font-black text-[#F8FAFC] mb-2 font-['Vazirmatn']">
                    {activeProjectModal.title}
                  </h3>

                  <p className="text-[#CBD5E1] text-xs sm:text-sm leading-relaxed whitespace-pre-line font-light">
                    {activeProjectModal.description}
                  </p>
                </div>

                {/* Tech Stack Chips */}
                <div>
                  <h4 className="text-xs font-bold text-[#64748b] uppercase tracking-wider mb-2 font-mono">
                    TECHNOLOGIES & ARCHITECTURE
                  </h4>
                  <div dir="ltr" className="flex flex-wrap gap-2 justify-start">
                    {activeProjectModal.tags.split(',').map((tTag, idx) => (
                      <span
                        key={idx}
                        dir="ltr"
                        className="px-3 py-1 rounded-lg bg-[#141824] text-[#38BDF8] border border-[#1e2436] text-xs font-mono font-semibold"
                      >
                        {tTag.trim()}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Action Footer */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#1e2436] shrink-0 mt-3">
                <button
                  onClick={() => setActiveProjectModal(null)}
                  className="px-5 py-2.5 rounded-xl bg-[#141824] hover:bg-[#1e2436] text-[#94A3B8] hover:text-white border border-[#1e2436] text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
                >
                  بستن پنجره
                </button>
                {activeProjectModal.link && (
                  <a
                    href={activeProjectModal.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] via-[#F3E5AB] to-[#C5A059] text-[#08090E] font-bold text-xs sm:text-sm flex items-center gap-2 shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:scale-105 transition-all cursor-pointer"
                  >
                    <span>مشاهده زنده پروژه آنلاین</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </section>
  );
};
