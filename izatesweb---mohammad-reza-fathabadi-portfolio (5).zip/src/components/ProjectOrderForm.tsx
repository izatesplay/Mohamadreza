import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Send, CheckCircle2, AlertCircle, Sparkles, Phone, User, FileText, Layers } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const ProjectOrderForm: React.FC = () => {
  const { t, direction } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    project_type: t('opt1'),
    description: '',
  });
  const [selectedPlan, setSelectedPlan] = useState<string>('corp');

  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const projectTypes = [
    t('opt1'),
    t('opt2'),
    t('opt3'),
    t('opt4'),
    t('opt5'),
    t('opt6'),
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus(null);

    if (!formData.name.trim() || !formData.phone.trim() || !formData.description.trim()) {
      setStatus({ type: 'error', message: t('requiredFieldError') });
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (res.ok) {
        setStatus({
          type: 'success',
          message: t('successOrderMsg'),
        });
        setFormData({ name: '', phone: '', project_type: projectTypes[0], description: '' });
      } else {
        setStatus({ type: 'error', message: data.error || t('requiredFieldError') });
      }
    } catch (err) {
      setStatus({ type: 'error', message: t('networkError') });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="order" className="py-24 relative bg-[var(--color-background)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Info Column */}
          <motion.div
            initial={{ opacity: 0, x: direction === 'rtl' ? 30 : -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-5 space-y-6"
          >
            <span className="text-xs sm:text-sm font-bold text-[var(--color-accent-primary)] uppercase tracking-widest bg-[var(--color-accent-primary)]/10 px-3.5 py-1.5 rounded-full border border-[var(--color-accent-primary)]/20 inline-block">
              {t('orderBadge')}
            </span>

            <h2 className="text-3xl sm:text-4xl font-black text-[var(--color-text-primary)] leading-tight">
              {t('orderHeading')}
            </h2>

            <p className="text-[var(--color-text-secondary)] text-base sm:text-lg font-light leading-relaxed">
              {t('orderSubheading')}
            </p>

            <div className="p-4 sm:p-5 rounded-2xl bg-[#0d0f17]/95 border border-[#D4AF37]/30 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#1e2436]">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                  <h4 className="text-sm font-bold text-[#F8FAFC]">برآوردگر هوشمند زمان و تکنولوژی</h4>
                </div>
                <span className="text-[10px] font-mono font-bold text-[#D4AF37] px-2 py-0.5 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/20">
                  SMART ESTIMATOR
                </span>
              </div>

              {/* Quick Type Selection */}
              <div>
                <label className="block text-xs font-medium text-[#94A3B8] mb-1.5">نوع پلن مد نظر:</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'corp', name: 'شرکتی لوکس', days: 12, arch: 'React + Tailwind + سئو فنی' },
                    { id: 'store', name: 'فروشگاهی جامع', days: 18, arch: 'WooCommerce / Next.js + درگاه' },
                    { id: '3d', name: 'سه‌بعدی Three.js', days: 22, arch: 'WebGL + Three.js + شیدرهای اختصاصی' },
                    { id: 'custom', name: 'پلتفرم اختصاصی', days: 28, arch: 'Node.js + React + دیتابیس ابری' },
                  ].map((plan) => (
                    <button
                      key={plan.id}
                      type="button"
                      onClick={() => {
                        setSelectedPlan(plan.id);
                        setFormData((prev) => ({
                          ...prev,
                          project_type: plan.name,
                          description: `پلن انتخابی: ${plan.name} | معماری مد نظر: ${plan.arch} | زمان تخمینی: حدود ${plan.days} روز کاری\n${prev.description.replace(/^پلن انتخابی:[^\n]*\n?/g, '')}`.trim(),
                        }));
                      }}
                      className={`p-2 rounded-xl text-right border transition-all text-xs cursor-pointer ${
                        selectedPlan === plan.id
                          ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#F3E5AB] font-bold shadow-[0_0_12px_rgba(212,175,55,0.2)]'
                          : 'border-[#1e2436] bg-[#141824]/60 text-[#94A3B8] hover:text-white hover:border-[#D4AF37]/30'
                      }`}
                    >
                      <div className="font-semibold">{plan.name}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">تحویل: ~{plan.days} روز</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Dynamic Summary Card */}
              <div className="p-3 rounded-xl bg-[#08090E] border border-[#1e2436] flex items-center justify-between text-xs">
                <div>
                  <span className="text-[#94A3B8] block text-[11px]">زمان تقریبی تحویل:</span>
                  <span className="text-[#38BDF8] font-bold text-xs">
                    {selectedPlan === 'corp' ? '۱۰ الی ۱۴ روز کاری' :
                     selectedPlan === 'store' ? '۱۵ الی ۲۲ روز کاری' :
                     selectedPlan === '3d' ? '۱۸ الی ۲۵ روز کاری' : '۲۵ الی ۳۵ روز کاری'}
                  </span>
                </div>
                <div className="text-left">
                  <span className="text-[#94A3B8] block text-[11px]">پشتیبانی و گارانتی:</span>
                  <span className="text-[#D4AF37] font-bold text-xs">۱۰۰٪ فنی و سئو</span>
                </div>
              </div>
            </div>

            <div className="space-y-4 pt-2">
              <div className="flex items-start gap-3.5 p-4 rounded-xl glass-panel border border-[var(--color-border)]">
                <div className="w-10 h-10 rounded-lg bg-[var(--color-accent-primary)]/10 border border-[var(--color-accent-primary)]/30 flex items-center justify-center text-[var(--color-accent-primary)] shrink-0 mt-0.5">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-[var(--color-text-primary)] font-bold text-sm">{t('orderHilite1Title')}</h4>
                  <p className="text-[var(--color-text-muted)] text-xs mt-1">{t('orderHilite1Desc')}</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 p-4 rounded-xl glass-panel border border-[var(--color-border)]">
                <div className="w-10 h-10 rounded-lg bg-[var(--color-accent-primary)]/10 border border-[var(--color-accent-primary)]/30 flex items-center justify-center text-[var(--color-accent-primary)] shrink-0 mt-0.5">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-[var(--color-text-primary)] font-bold text-sm">{t('orderHilite2Title')}</h4>
                  <p className="text-[var(--color-text-muted)] text-xs mt-1">{t('orderHilite2Desc')}</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Form Card */}
          <motion.div
            initial={{ opacity: 0, x: direction === 'rtl' ? -30 : 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-7"
          >
            <div className="glass-card rounded-3xl p-8 border border-[var(--color-border)] shadow-2xl relative">
              <h3 className="text-2xl font-bold text-[var(--color-text-primary)] mb-6 flex items-center gap-2">
                <FileText className="w-6 h-6 text-[var(--color-accent-primary)]" />
                <span>{t('formTitle')}</span>
              </h3>

              {status && (
                <div
                  className={`p-4 rounded-xl mb-6 flex items-start gap-3 text-sm font-medium border ${
                    status.type === 'success'
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                      : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                  }`}
                >
                  {status.type === 'success' ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <span>{status.message}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                
                {/* Name */}
                <div>
                  <label className="block text-xs font-bold text-[var(--color-text-secondary)] mb-2">
                    {t('fullNameLabel')} <span className="text-rose-400">*</span>
                  </label>
                  <div className="relative">
                    <User className={`w-5 h-5 text-[var(--color-text-muted)] absolute ${direction === 'rtl' ? 'right-3.5' : 'left-3.5'} top-3.5 pointer-events-none`} />
                    <input
                      type="text"
                      placeholder={t('fullNamePlaceholder')}
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full ${direction === 'rtl' ? 'pl-4 pr-11' : 'pr-4 pl-11'} py-3 rounded-xl bg-[var(--color-background)] border border-[var(--color-border)] text-[var(--color-text-primary)] placeholder-[var(--color-text-muted)] focus:outline-none focus:border-[var(--color-accent-primary)] text-sm transition-colors`}
                      required
                    />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-xs font-bold text-[var(--color-text-secondary)] mb-2">
                    {t('phoneLabel')} <span className="text-rose-400">*</span>
                  </label>
                  <div className="relative">
                    <Phone className={`w-5 h-5 text-[var(--color-text-muted)] absolute ${direction === 'rtl' ? 'right-3.5' : 'left-3.5'} top-3.5 pointer-events-none`} />
                    <input
                      type="tel"
                      dir="ltr"
                      placeholder="09123456789"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className={`w-full ${direction === 'rtl' ? 'pl-4 pr-11 text-right' : 'pr-4 pl-11 text-left'} py-3 rounded-xl bg-[var(--color-background)] border border-[var(--color-border)] text-[var(--color-text-primary)] placeholder-[var(--color-text-muted)] focus:outline-none focus:border-[var(--color-accent-primary)] text-sm transition-colors`}
                      required
                    />
                  </div>
                </div>

                {/* Project Type */}
                <div>
                  <label className="block text-xs font-bold text-[var(--color-text-secondary)] mb-2">
                    {t('projectTypeLabel')}
                  </label>
                  <div className="relative">
                    <Layers className={`w-5 h-5 text-[var(--color-text-muted)] absolute ${direction === 'rtl' ? 'right-3.5' : 'left-3.5'} top-3.5 pointer-events-none`} />
                    <select
                      value={formData.project_type}
                      onChange={(e) => setFormData({ ...formData, project_type: e.target.value })}
                      className={`w-full ${direction === 'rtl' ? 'pl-4 pr-11' : 'pr-4 pl-11'} py-3 rounded-xl bg-[var(--color-background)] border border-[var(--color-border)] text-[var(--color-text-primary)] focus:outline-none focus:border-[var(--color-accent-primary)] text-sm transition-colors appearance-none cursor-pointer`}
                    >
                      {projectTypes.map((pt, idx) => (
                        <option key={idx} value={pt} className="bg-[var(--color-surface)] text-[var(--color-text-primary)]">
                          {pt}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-xs font-bold text-[var(--color-text-secondary)] mb-2">
                    {t('projectDescLabel')} <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    rows={4}
                    placeholder={t('projectDescPlaceholder')}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full p-4 rounded-xl bg-[var(--color-background)] border border-[var(--color-border)] text-[var(--color-text-primary)] placeholder-[var(--color-text-muted)] focus:outline-none focus:border-[var(--color-accent-primary)] text-sm transition-colors resize-none"
                    required
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-[var(--color-accent-primary)] via-[var(--color-accent-hover)] to-[var(--color-accent-primary)] text-[var(--color-background)] font-black text-base flex items-center justify-center gap-2 shadow-xl shadow-[var(--color-accent-primary)]/20 hover:shadow-[var(--color-accent-primary)]/35 hover:scale-[1.01] transition-all disabled:opacity-50 cursor-pointer"
                >
                  <Send className="w-5 h-5" />
                  <span>{submitting ? t('submittingText') : t('submitOrderBtn')}</span>
                </button>

              </form>
            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
};
