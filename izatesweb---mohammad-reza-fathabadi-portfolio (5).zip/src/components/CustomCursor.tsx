import React, { useEffect, useRef } from 'react';

export const CustomCursor: React.FC = () => {
  const outerRingRef = useRef<HTMLDivElement>(null);
  const innerDotRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Only activate on pointer devices (desktop mouse/trackpad)
    if (window.matchMedia('(pointer: coarse)').matches) {
      return;
    }

    let mouseX = -100;
    let mouseY = -100;
    let ringX = -100;
    let ringY = -100;
    let isHovered = false;
    let isClicking = false;
    let isVisible = false;
    let animId: number;

    const onMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      if (!isVisible) {
        isVisible = true;
        if (outerRingRef.current) outerRingRef.current.style.opacity = '1';
        if (innerDotRef.current) innerDotRef.current.style.opacity = '1';
      }

      // Check hover only on element under pointer
      const target = e.target as HTMLElement | null;
      if (target) {
        isHovered = !!target.closest('button, a, input, textarea, select, [role="button"], .clickable');
      }
    };

    const onMouseDown = () => { isClicking = true; };
    const onMouseUp = () => { isClicking = false; };
    const onMouseLeave = () => {
      isVisible = false;
      if (outerRingRef.current) outerRingRef.current.style.opacity = '0';
      if (innerDotRef.current) innerDotRef.current.style.opacity = '0';
    };
    const onMouseEnter = () => {
      isVisible = true;
      if (outerRingRef.current) outerRingRef.current.style.opacity = '1';
      if (innerDotRef.current) innerDotRef.current.style.opacity = '1';
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('mousedown', onMouseDown, { passive: true });
    window.addEventListener('mouseup', onMouseUp, { passive: true });
    document.addEventListener('mouseleave', onMouseLeave);
    document.addEventListener('mouseenter', onMouseEnter);

    // Ultra-smooth 120fps RAF spring loop with zero React re-renders
    const tick = () => {
      // Smooth lerp damping for outer trailing ring
      ringX += (mouseX - ringX) * 0.18;
      ringY += (mouseY - ringY) * 0.18;

      if (innerDotRef.current) {
        const dotScale = isClicking ? 0.6 : isHovered ? 1.5 : 1.0;
        innerDotRef.current.style.transform = `translate3d(${mouseX}px, ${mouseY}px, 0) translate(-50%, -50%) scale(${dotScale})`;
      }

      if (outerRingRef.current) {
        const ringScale = isClicking ? 0.8 : isHovered ? 1.4 : 1.0;
        outerRingRef.current.style.transform = `translate3d(${ringX}px, ${ringY}px, 0) translate(-50%, -50%) scale(${ringScale})`;
        if (isHovered) {
          outerRingRef.current.style.borderColor = 'rgba(212, 175, 55, 0.9)';
          outerRingRef.current.style.backgroundColor = 'rgba(212, 175, 55, 0.15)';
        } else {
          outerRingRef.current.style.borderColor = 'rgba(212, 175, 55, 0.45)';
          outerRingRef.current.style.backgroundColor = 'rgba(212, 175, 55, 0.04)';
        }
      }

      animId = requestAnimationFrame(tick);
    };

    animId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      document.removeEventListener('mouseleave', onMouseLeave);
      document.removeEventListener('mouseenter', onMouseEnter);
    };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 z-[9999] overflow-hidden select-none">
      {/* Outer Glowing Trailing Ring */}
      <div
        ref={outerRingRef}
        className="fixed top-0 left-0 w-9 h-9 rounded-full border border-[#D4AF37]/50 bg-[#D4AF37]/5 backdrop-blur-[1px] shadow-[0_0_20px_rgba(212,175,55,0.25)] pointer-events-none will-change-transform opacity-0 transition-opacity duration-300"
      />

      {/* Inner Precision Laser Dot */}
      <div
        ref={innerDotRef}
        className="fixed top-0 left-0 w-2 h-2 rounded-full bg-[#D4AF37] shadow-[0_0_10px_#D4AF37] pointer-events-none will-change-transform opacity-0 transition-opacity duration-200"
      />
    </div>
  );
};
