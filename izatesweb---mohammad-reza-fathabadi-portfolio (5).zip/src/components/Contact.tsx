import React from 'react';
import { motion } from 'motion/react';
import { Phone, Mail, MapPin, Send, MessageCircle, Clock, ExternalLink } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const Contact: React.FC = () => {
  const { t, direction } = useLanguage();

  const contactDetails = [
    {
      title: t('contact1Title'),
      value: '0992 175 8505',
      href: 'tel:09921758505',
      sub: t('contact1Sub'),
      icon: Phone,
    },
    {
      title: t('contact2Title'),
      value: 'izatesplay@gmail.com',
      href: 'mailto:izatesplay@gmail.com',
      sub: t('contact2Sub'),
      icon: Mail,
    },
    {
      title: t('contact3Title'),
      value: t('contact3Value'),
      href: '#',
      sub: t('contact3Sub'),
      icon: MapPin,
    },
  ];

  return (
    <section id="contact" className="py-24 relative bg-[var(--color-surface)]/60 border-t border-[var(--color-border)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="text-xs sm:text-sm font-bold text-[var(--color-accent-primary)] uppercase tracking-widest bg-[var(--color-accent-primary)]/10 px-3.5 py-1.5 rounded-full border border-[var(--color-accent-primary)]/20 inline-block mb-3">
            {t('contactBadge')}
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[var(--color-text-primary)] tracking-tight">
            {t('contactHeading')}
          </h2>
          <p className="mt-4 text-[var(--color-text-muted)] text-base leading-relaxed">
            {t('contactSubheading')}
          </p>
        </motion.div>

        {/* Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {contactDetails.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.a
                key={idx}
                href={item.href}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-30px' }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="glass-card rounded-2xl p-8 border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/50 transition-all duration-300 flex flex-col items-center text-center group shadow-xl"
              >
                <div className="w-16 h-16 rounded-2xl bg-[var(--color-accent-primary)]/10 border border-[var(--color-accent-primary)]/30 flex items-center justify-center text-[var(--color-accent-primary)] mb-6 group-hover:scale-110 transition-transform">
                  <Icon className="w-8 h-8" />
                </div>

                <h3 className="text-sm font-bold text-[var(--color-text-muted)] mb-2">
                  {item.title}
                </h3>

                <span className="text-xl font-black text-[var(--color-text-primary)] group-hover:text-[var(--color-accent-primary)] transition-colors mb-2" dir="ltr">
                  {item.value}
                </span>

                <span className="text-xs text-[var(--color-text-muted)] font-medium">
                  {item.sub}
                </span>
              </motion.a>
            );
          })}
        </div>

        {/* Messaging Quick Action Banner */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
          className="glass-panel rounded-3xl p-8 sm:p-12 border border-[var(--color-border)] bg-gradient-to-r from-[var(--color-surface)] via-[var(--color-surface)] to-[var(--color-surface)] relative overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-8"
        >
          <div className={`space-y-3 text-center ${direction === 'rtl' ? 'lg:text-right' : 'lg:text-left'}`}>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-bold border border-emerald-500/20 mb-1">
              <Clock className="w-3.5 h-3.5" />
              <span>{t('bannerBadge')}</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-[var(--color-text-primary)]">
              {t('bannerTitle')}
            </h3>
            <p className="text-[var(--color-text-secondary)] text-sm sm:text-base font-light">
              {t('bannerDesc')}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 shrink-0">
            <a
              href="tel:09921758505"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-[var(--color-accent-primary)] to-[var(--color-accent-hover)] text-[var(--color-background)] font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-[var(--color-accent-primary)]/20 hover:scale-105 transition-transform"
            >
              <Phone className="w-4 h-4" />
              <span>{t('directCallBtn')}</span>
            </a>

            <a
              href="https://t.me/izatesweb"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-[var(--color-background)] text-[var(--color-text-secondary)] border border-[var(--color-border)] hover:border-[var(--color-accent-primary)]/50 hover:text-[var(--color-accent-primary)] font-bold text-sm flex items-center justify-center gap-2 transition-colors"
            >
              <Send className="w-4 h-4 text-sky-400" />
              <span>{t('telegramMsgBtn')}</span>
            </a>
          </div>
        </motion.div>

      </div>
    </section>
  );
};
