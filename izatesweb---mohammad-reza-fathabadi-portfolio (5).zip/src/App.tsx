import React, { useState, useEffect } from 'react';
import { ColorProvider } from './context/ColorContext';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { CustomCursor } from './components/CustomCursor';
import { FilmCanvas } from './film/FilmCanvas';
import { VideoWorkstationStage } from './film/VideoWorkstationStage';
import { FilmOverlays } from './film/FilmOverlays';
import { FilmHUD } from './film/FilmHUD';
import { PortfolioModal } from './film/PortfolioModal';
import { Projects } from './components/Projects';
import { About } from './components/About';
import { Team } from './components/Team';
import { ProjectOrderForm } from './components/ProjectOrderForm';
import { Contact } from './components/Contact';
import { AdminPanel } from './components/AdminPanel';
import { EmoRobot } from './components/EmoRobot';

export default function App() {
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<'projects' | 'order' | 'about' | 'contact' | 'emo' | null>(null);

  useEffect(() => {
    if (window.location.hash === '#admin' || window.location.search.includes('admin')) {
      setIsAdminOpen(true);
    }
    if (window.location.hash === '#emo' || window.location.hash === '#robot') {
      setActiveModal('emo');
    }

    const handleHashChange = () => {
      if (window.location.hash === '#admin') {
        setIsAdminOpen(true);
      } else if (window.location.hash === '#emo' || window.location.hash === '#robot') {
        setActiveModal('emo');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  return (
    <AuthProvider>
      <LanguageProvider>
        <ColorProvider>
          <div className="relative w-full bg-[#08090E] text-[#F8FAFC] font-['Vazirmatn',sans-serif] selection:bg-[#D4AF37]/30 selection:text-[#F3E5AB]">
            <CustomCursor />

            {/* THE 900vh SCROLL TRACK — Tuned for responsive, snappy, silky-smooth cinematic pacing */}
            <div className="relative w-full h-[900vh]">
              {/* Single Sticky Stage over the 900vh track */}
              <div className="sticky top-0 w-full h-screen overflow-hidden">
                {/* ONE Canvas: 3D WebGL Scene */}
                <FilmCanvas />

                {/* Video-to-Frame Scroll Engine (Developer at Workstation zooming into VS Code) */}
                <VideoWorkstationStage />

                {/* DOM Over It: 6 Acts Overlays on sp act axis with kinetic letter blur */}
                <FilmOverlays
                  onOpenProjects={() => setActiveModal('projects')}
                  onOpenOrder={() => setActiveModal('order')}
                  onOpenContact={() => setActiveModal('contact')}
                  onOpenAbout={() => setActiveModal('about')}
                  onOpenEmo={() => setActiveModal('emo')}
                />

                {/* Film HUD: Telemetry, Audio Synthesizer, Acts Navigation, Quick Actions */}
                <FilmHUD
                  onOpenProjects={() => setActiveModal('projects')}
                  onOpenOrder={() => setActiveModal('order')}
                  onOpenAbout={() => setActiveModal('about')}
                  onOpenContact={() => setActiveModal('contact')}
                  onOpenAdmin={() => setIsAdminOpen(true)}
                  onOpenEmo={() => setActiveModal('emo')}
                />
              </div>
            </div>

            {/* Creative Fusion: Interactive Modals for IzatesWeb Portfolio Modules */}
            <PortfolioModal
              isOpen={activeModal === 'projects'}
              onClose={() => setActiveModal(null)}
              title="پرونده پروژه‌ها و نمونه کارها | PORTFOLIO WORKS"
            >
              <Projects />
            </PortfolioModal>

            <PortfolioModal
              isOpen={activeModal === 'order'}
              onClose={() => setActiveModal(null)}
              title="ثبت سفارش و برآورد هوشمند پروژه | START A PROJECT"
            >
              <ProjectOrderForm />
            </PortfolioModal>

            <PortfolioModal
              isOpen={activeModal === 'about'}
              onClose={() => setActiveModal(null)}
              title="درباره محمد رضا فتح آبادی و متدولوژی طراحی | ABOUT"
            >
              <div className="space-y-12">
                <About />
                <Team />
              </div>
            </PortfolioModal>

            <PortfolioModal
              isOpen={activeModal === 'contact'}
              onClose={() => setActiveModal(null)}
              title="راه‌های ارتباطی و مشاوره مستقیم | CONNECT"
            >
              <Contact />
            </PortfolioModal>

            {/* EMO AI Robot Assistant Modal */}
            <PortfolioModal
              isOpen={activeModal === 'emo'}
              onClose={() => setActiveModal(null)}
              title="دستیار هوشمند و سخنگوی سایت (ربات ایمو) | EMO AI ASSISTANT"
              maxWidth="max-w-4xl"
            >
              <div className="py-2">
                <EmoRobot />
              </div>
            </PortfolioModal>

            {/* Admin Panel Overlay */}
            {isAdminOpen && <AdminPanel onClose={() => setIsAdminOpen(false)} />}
          </div>
        </ColorProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}
