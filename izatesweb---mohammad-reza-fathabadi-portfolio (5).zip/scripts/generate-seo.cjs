const fs = require('fs');
const path = require('path');

function generateSeoFiles() {
  console.log('[SEO Generator] Generating sitemap.xml and robots.txt...');

  const domain = 'https://izatesweb.ir';
  const currentDate = new Date().toISOString().split('T')[0];

  // 1. Generate robots.txt
  const robotsTxtContent = `# ===================================================
# Robots.txt for izatesweb (ایزاتس‌وب)
# Developer: Mohammad Reza Fathabadi (محمد رضا فتح آبادی)
# Services: طراحی سایت وردپرسی و اختصاصی | بهینه‌سازی سرعت و سئو | طراحی وب‌سایت‌های شرکتی و فروشگاهی
# ===================================================

User-agent: *
Allow: /
Allow: /#hero
Allow: /#about
Allow: /#projects
Allow: /#team
Allow: /#order
Allow: /#contact

Disallow: /api/admin/
Disallow: /admin

# Sitemaps
Sitemap: ${domain}/sitemap.xml
`;

  // 2. Generate sitemap.xml
  const sitemapXmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
  
  <!-- izatesweb | صفحه اصلی طراحی سایت وردپرسی و اختصاصی - محمد رضا فتح آبادی -->
  <url>
    <loc>${domain}/</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>

  <!-- درباره محمد رضا فتح آبادی و برند ایزاتس‌وب (izatesweb) -->
  <url>
    <loc>${domain}/#about</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
  </url>

  <!-- نمونه کارهای جدید طراحی سایت وردپرس و کدنویسی اختصاصی -->
  <url>
    <loc>${domain}/#projects</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.95</priority>
  </url>

  <!-- اعضای تیم ایزاتس‌وب (izatesweb) -->
  <url>
    <loc>${domain}/#team</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>

  <!-- ثبت سفارش آنلاین طراحی سایت شرکتی، فروشگاهی و پورتفولیو -->
  <url>
    <loc>${domain}/#order</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.95</priority>
  </url>

  <!-- اطلاعات تماس با محمد رضا فتح آبادی و مشاوره رایگان سئو و سرعت -->
  <url>
    <loc>${domain}/#contact</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.85</priority>
  </url>

</urlset>
`;

  // Ensure directories exist
  const publicDir = path.join(process.cwd(), 'public');
  const distDir = path.join(process.cwd(), 'dist');

  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  // Write to public/
  fs.writeFileSync(path.join(publicDir, 'robots.txt'), robotsTxtContent, 'utf8');
  fs.writeFileSync(path.join(publicDir, 'sitemap.xml'), sitemapXmlContent, 'utf8');

  // If dist/ exists (after or during build), also write to dist/
  if (fs.existsSync(distDir)) {
    fs.writeFileSync(path.join(distDir, 'robots.txt'), robotsTxtContent, 'utf8');
    fs.writeFileSync(path.join(distDir, 'sitemap.xml'), sitemapXmlContent, 'utf8');
  }

  console.log('[SEO Generator] Successfully created public/robots.txt and public/sitemap.xml!');
}

generateSeoFiles();
