-- ========================================================
-- izatesweb - MySQL Database Schema & Initial Seed Data
-- Designed for Mohammad Reza Fathabadi Portfolio
-- ========================================================

CREATE DATABASE IF NOT EXISTS `izatesweb_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `izatesweb_db`;

-- --------------------------------------------------------
-- Table: projects (نمونه کارها)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `projects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL DEFAULT 'وردپرس',
  `description` TEXT NOT NULL,
  `image_url` VARCHAR(500) NOT NULL,
  `link` VARCHAR(500) DEFAULT NULL,
  `tags` VARCHAR(255) DEFAULT 'WordPress, Elementor',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: team_members (تیم)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `team_members` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `role` VARCHAR(255) NOT NULL,
  `image_url` VARCHAR(500) NOT NULL,
  `socials_json` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: contact_messages (پیام‌ها و سفارشات پروژه)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `project_type` VARCHAR(100) NOT NULL,
  `description` TEXT NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: admin_users (کاربران ادمین)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: site_colors (تنظیمات رنگ سایت)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_colors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `color_key` VARCHAR(100) NOT NULL UNIQUE,
  `color_value` VARCHAR(50) NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================================
-- Seed Initial Data
-- ========================================================

-- Initial Admin User (Username: admin / Default Password Hash or plaintext handler)
INSERT INTO `admin_users` (`username`, `password_hash`) 
VALUES ('admin', '$2a$10$wI5f2QoQ7S0/r1q3eNfJ4.kY3p1jV4U2.0Xq6E1Y/2b9Y0mZ.4a6K') 
ON DUPLICATE KEY UPDATE `username`=`username`;

-- Initial Default Site Colors
INSERT INTO `site_colors` (`color_key`, `color_value`) VALUES
('Background', '#0A0A0F'),
('Surface', '#12121A'),
('Navbar', 'rgba(18, 18, 26, 0.85)'),
('Primary Text', '#F8FAFC'),
('Secondary Text', '#CBD5E1'),
('Muted Text', '#64748B'),
('Primary Accent', '#C9A84C'),
('Hover Accent', '#E2BF5F'),
('Border', '#222232'),
('Success', '#10B981'),
('Error', '#EF4444')
ON DUPLICATE KEY UPDATE `color_value` = VALUES(`color_value`);

-- Initial Projects (نمونه کارها)
INSERT INTO `projects` (`title`, `category`, `description`, `image_url`, `link`, `tags`) VALUES
('فروشگاه اینترنتی لوکس زرنشان', 'فروشگاهی', 'طراحی سایت فروشگاهی طلای آنلاین با وردپرس و ووکامرس، اتصال به درگاه پرداخت مستقیم، محاسبه زنده قیمت طلا و طراحی لوکس RTL.', 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1000&auto=format&fit=crop', 'https://example.com/zarneshan', 'وردپرس, ووکامرس, طراحی لوکس'),
('پرتال شرکتی گروه مهندسی آریا', 'شرکتی', 'وب‌سایت اختصاصی معرفی خدمات مهندسی عمران با پنل مدیریت پروژه اختصاصی، فرم استعلام قیمت هوشمند و ریسپانسو کامل.', 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop', 'https://example.com/aria-engineering', 'وردپرس, المنتور, اختصاصی'),
('سایت رزرو آنلاین آکادمی زیباییزاد', 'اختصاصی', 'طراحی سیستم رزرو نوبت آنلاین اختصاصی با React و Express، پنل تقویم شمسی مدیریت نوبت‌ها و یادآوری پیامکی.', 'https://images.unsplash.com/photo-1560066984-138dadb4c035?q=80&w=1000&auto=format&fit=crop', 'https://example.com/zibaeezad', 'طراحی اختصاصی, React, Node.js'),
('وب‌سایت معماری و دکوراسیون طرح‌نو', 'شرکتی', 'پورتفولیو اختصاصی معماری با گالری ۳D پیشرفته، انیمیشن‌های روان و سئوی عالی در گوگل.', 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1000&auto=format&fit=crop', 'https://example.com/tarh-no', 'وردپرس, انیمیشن UI, سئو'),
('پلتفرم آموزشی و وبینار تخصصی وب‌سازان', 'اختصاصی', 'سایت فروش دوره آموزشی آنلاین با سیستم آزمون‌ساز اختصاصی و اتصال به ویدیو پلیر ایمن.', 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1000&auto=format&fit=crop', 'https://example.com/websazan-edu', 'طراحی اختصاصی, ووکامرس, React')
ON DUPLICATE KEY UPDATE `title`=`title`;

-- Initial Team Members (تیم izatesweb)
INSERT INTO `team_members` (`name`, `role`, `image_url`, `socials_json`) VALUES
('محمد رضا فتح آبادی', 'طراح ارشد سایت و توسعه‌دهنده وب (بنیان‌گذار izatesweb)', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop', '{"instagram":"https://instagram.com","telegram":"https://t.me","linkedin":"https://linkedin.com"}'),
('سارا حسینی', 'طراح UI/UX و رابط کاربری', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&auto=format&fit=crop', '{"instagram":"https://instagram.com","linkedin":"https://linkedin.com"}'),
('علی رضا محمدی', 'متخصص سئو و تولید محتوای وب', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600&auto=format&fit=crop', '{"telegram":"https://t.me","linkedin":"https://linkedin.com"}')
ON DUPLICATE KEY UPDATE `name`=`name`;
