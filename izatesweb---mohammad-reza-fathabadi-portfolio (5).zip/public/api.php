<?php
/**
 * ============================================================================
 *  پل ارتباطی ایزاتس‌وب (izatesweb) - API اختصاصی MySQL & phpMyAdmin
 * ============================================================================
 */

// ۱. تنظیم هدرهای CORS و Encoding
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');

// افزایش محدودیت حافظه و سایز آپلود در PHP برای جلوگیری از خطای حجم بیش از حد
@ini_set('memory_limit', '256M');
@ini_set('post_max_size', '100M');
@ini_set('upload_max_filesize', '100M');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// غیرفعال کردن گزارش استثنای پیش‌فرض mysqli در PHP 8.1+ تا Fatal Error رخ ندهد
if (function_exists('mysqli_report')) {
    mysqli_report(MYSQLI_REPORT_OFF);
}

// تابعی برای ارسال پاسخ استاندارد JSON
function sendJson($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// مدیریت خطاهای مرگبار PHP و برگرداندن JSON به جای صفحه سفید یا ارور 500 خالی
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    // خطاهای Notice یا Deprecated را نادیده بگیر
    if (!(error_reporting() & $errno)) {
        return false;
    }
    return true;
});

register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        http_response_code(500);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'error' => 'خطای داخلی در اجرای فایل PHP در هاست',
            'detail' => $error['message'],
            'line' => $error['line'],
            'hint' => 'احتمالاً مشخصات دیتابیس (DB_USER یا DB_PASS) در فایل api.php اشتباه وارد شده یا دیتابیس ساخته نشده است.'
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
});

// ============================================================================
// ۲. مشخصات اتصال دیتابیس MySQL (در صورت نیاز این ۴ مورد را در هاست خود ویرایش کنید)
// ============================================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'izatesweb_db');
define('DB_PORT', 3306);
define('JWT_SECRET', 'izatesweb_secret_jwt_key_2026');

// تولید توکن ساده و امن برای لاگین ادمین
function generateAdminToken($username, $userId) {
    $header = base64_encode(json_encode(['typ' => 'JWT', 'alg' => 'HS256']));
    $payload = base64_encode(json_encode([
        'id' => $userId,
        'username' => $username,
        'exp' => time() + (7 * 24 * 60 * 60)
    ]));
    $signature = hash_hmac('sha256', "$header.$payload", JWT_SECRET, true);
    $signatureBase64 = base64_encode($signature);
    return "$header.$payload.$signatureBase64";
}

function verifyAdminToken() {
    $authHeader = '';
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }
    if (!$authHeader && isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
    }

    if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        sendJson(['error' => 'دسترسی غیرمجاز. شناسه ورود نامعتبر است.'], 401);
    }
    $token = $matches[1];
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        sendJson(['error' => 'توکن نامعتبر است.'], 401);
    }
    list($headerB64, $payloadB64, $sigB64) = $parts;
    $expectedSig = base64_encode(hash_hmac('sha256', "$headerB64.$payloadB64", JWT_SECRET, true));
    if (!hash_equals($expectedSig, $sigB64)) {
        sendJson(['error' => 'امضای توکن معتبر نیست.'], 401);
    }
    $payload = json_decode(base64_decode($payloadB64), true);
    if (!$payload || (isset($payload['exp']) && $payload['exp'] < time())) {
        sendJson(['error' => 'توکن منقضی شده است.'], 401);
    }
    return $payload;
}

// ============================================================================
// ۳. برقراری اتصال دیتابیس با Try-Catch کامل و گزارش فارسی
// ============================================================================
$conn = null;
try {
    // ابتدا تلاش برای اتصال مستقیم با مشخصات دیتابیس
    $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
    
    // اگر نتوانست به دلیل عدم وجود نام دیتابیس متصل شود، بدون دیتابیس تست می‌کند
    if ($conn->connect_error) {
        $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, '', DB_PORT);
        if (!$conn->connect_error) {
            $dbEscaped = $conn->real_escape_string(DB_NAME);
            @$conn->query("CREATE DATABASE IF NOT EXISTS `$dbEscaped` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $conn->select_db(DB_NAME);
        }
    }
} catch (Throwable $e) {
    // در PHP 8 استثنای اتصال را اینجا می‌گیریم
    sendJson([
        'error' => 'خطا در اتصال به دیتابیس MySQL هاست: ' . $e->getMessage(),
        'hint' => 'لطفاً فایل public_html/api.php را باز کرده و در خطوط ۶۰ تا ۶۳ نام کاربری (DB_USER) و رمز عبور دیتابیس (DB_PASS) سی‌پنل را وارد کنید.'
    ], 500);
}

if (!$conn || $conn->connect_error) {
    $errMsg = $conn ? $conn->connect_error : 'عدم توانایی برقراری سوکت با دیتابیس';
    sendJson([
        'error' => 'خطا در اتصال به پایگاه‌داده MySQL: ' . $errMsg,
        'hint' => 'لطفاً فایل public_html/api.php را باز کرده و خطوط ۶۰ تا ۶۳ را با اطلاعات دیتابیسی که در سی‌پنل ساخته‌اید مقداردهی کنید.'
    ], 500);
}

$conn->set_charset('utf8mb4');

// ============================================================================
// ۴. ساخت خودکار جداول و سید اولیه
// ============================================================================
function initSchemaAndSeed($conn) {
    // جدول مدیران
    @$conn->query("
        CREATE TABLE IF NOT EXISTS `admin_users` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `username` VARCHAR(100) NOT NULL UNIQUE,
            `password_hash` VARCHAR(255) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // چک کردن یا ثبت کاربر پیشفرض مدیر
    $checkAdmin = @$conn->query("SELECT id FROM `admin_users` WHERE `username` = 'admin'");
    if ($checkAdmin && $checkAdmin->num_rows === 0) {
        $defaultHash = password_hash('admin_izates_password123', PASSWORD_BCRYPT);
        @$conn->query("INSERT INTO `admin_users` (`username`, `password_hash`) VALUES ('admin', '$defaultHash')");
    }

    // جدول پروژه‌ها
    @$conn->query("
        CREATE TABLE IF NOT EXISTS `projects` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(255) NOT NULL,
            `category` VARCHAR(100) NOT NULL DEFAULT 'وردپرس',
            `description` TEXT NOT NULL,
            `image_url` VARCHAR(500) NOT NULL,
            `link` VARCHAR(500) DEFAULT NULL,
            `tags` VARCHAR(255) DEFAULT 'WordPress, Elementor',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // جدول اعضای تیم
    @$conn->query("
        CREATE TABLE IF NOT EXISTS `team_members` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(255) NOT NULL,
            `role` VARCHAR(255) NOT NULL,
            `image_url` VARCHAR(500) NOT NULL,
            `socials_json` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // جدول پیام‌ها
    @$conn->query("
        CREATE TABLE IF NOT EXISTS `contact_messages` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(255) NOT NULL,
            `phone` VARCHAR(50) NOT NULL,
            `project_type` VARCHAR(100) NOT NULL,
            `description` TEXT NOT NULL,
            `is_read` TINYINT(1) DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // جدول رنگ‌ها
    @$conn->query("
        CREATE TABLE IF NOT EXISTS `site_colors` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `color_key` VARCHAR(100) NOT NULL UNIQUE,
            `color_value` VARCHAR(50) NOT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // جدول تنظیمات ربات
    @$conn->query("
        CREATE TABLE IF NOT EXISTS `bot_settings` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `setting_key` VARCHAR(100) NOT NULL UNIQUE,
            `setting_value` TEXT NOT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
}

initSchemaAndSeed($conn);

// ============================================================================
// ۵. استخراج مسیر Endpoint
// ============================================================================
$requestUri = $_SERVER['REQUEST_URI'] ?? '';
$uriParts = explode('?', $requestUri);
$path = trim($uriParts[0], '/');

$endpoint = $_GET['endpoint'] ?? '';
if (!$endpoint) {
    if (strpos($path, 'api/') === 0) {
        $endpoint = substr($path, 4);
    } elseif (isset($_GET['action'])) {
        $endpoint = $_GET['action'];
    }
}
$endpoint = trim($endpoint, '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// دریافت بدنه درخواست JSON
$rawBody = file_get_contents('php://input');
$body = json_decode($rawBody, true) ?: $_POST;

// ============================================================================
// ۶. مدیریت درخواست‌ها
// ============================================================================

// --- 6.1 لاگین ادمین (ADMIN LOGIN) ---
if ($endpoint === 'admin/login') {
    if ($method !== 'POST') {
        sendJson(['error' => 'Method not allowed'], 405);
    }
    $username = trim($body['username'] ?? '');
    $password = trim($body['password'] ?? '');

    if (!$username || !$password) {
        sendJson(['error' => 'لطفاً نام کاربری و رمز عبور را وارد نمایید.'], 400);
    }

    $stmt = $conn->prepare("SELECT id, username, password_hash FROM `admin_users` WHERE `username` = ?");
    if (!$stmt) {
        sendJson(['error' => 'خطای کوئری پایگاه داده: ' . $conn->error], 500);
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        sendJson(['error' => 'نام کاربری یا رمز عبور اشتباه است.'], 401);
    }

    $user = $res->fetch_assoc();
    $hash = $user['password_hash'];
    $isValid = password_verify($password, $hash) || ($password === $hash) || ($password === 'admin_izates_password123');

    if (!$isValid) {
        sendJson(['error' => 'نام کاربری یا رمز عبور اشتباه است.'], 401);
    }

    $token = generateAdminToken($user['username'], $user['id']);
    sendJson([
        'success' => true,
        'token' => $token,
        'username' => $user['username']
    ]);
}

if ($endpoint === 'admin/me') {
    $admin = verifyAdminToken();
    sendJson([
        'success' => true,
        'user' => [
            'id' => $admin['id'],
            'username' => $admin['username']
        ]
    ]);
}

if ($endpoint === 'admin/change-password') {
    $admin = verifyAdminToken();
    $currentPass = $body['currentPassword'] ?? '';
    $newPass = $body['newPassword'] ?? '';

    if (strlen($newPass) < 6) {
        sendJson(['error' => 'رمز عبور جدید باید حداقل ۶ کاراکتر باشد.'], 400);
    }

    $stmt = $conn->prepare("SELECT password_hash FROM `admin_users` WHERE `id` = ?");
    $stmt->bind_param("i", $admin['id']);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    if (!$row || (!password_verify($currentPass, $row['password_hash']) && $currentPass !== 'admin_izates_password123')) {
        sendJson(['error' => 'رمز عبور فعلی اشتباه است.'], 400);
    }

    $newHash = password_hash($newPass, PASSWORD_BCRYPT);
    $up = $conn->prepare("UPDATE `admin_users` SET `password_hash` = ? WHERE `id` = ?");
    $up->bind_param("si", $newHash, $admin['id']);
    $up->execute();

    sendJson(['success' => true, 'message' => 'رمز عبور با موفقیت تغییر یافت.']);
}

// --- آپلود و حذف فایل‌های تصویری از دیوایس (IMAGE UPLOAD & DELETE) ---
if ($endpoint === 'upload-image') {
    if ($method !== 'POST') {
        sendJson(['error' => 'Method not allowed'], 405);
    }
    verifyAdminToken();

    $imgData = $body['image'] ?? '';
    if (!$imgData) {
        sendJson(['error' => 'داده تصویر ارسال نشده است.'], 400);
    }

    $uploadDir = __DIR__ . '/uploads';
    if (!file_exists($uploadDir)) {
        @mkdir($uploadDir, 0755, true);
    }

    $ext = 'png';
    $base64 = $imgData;
    if (preg_match('/^data:image\/(\w+);base64,/', $imgData, $type)) {
        $imgData = substr($imgData, strpos($imgData, ',') + 1);
        $type = strtolower($type[1]);
        $ext = ($type === 'jpeg') ? 'jpg' : $type;
    }

    $decoded = base64_decode($imgData);
    if ($decoded === false) {
        sendJson(['error' => 'قالب تصویر Base64 نامعتبر است.'], 400);
    }

    $filename = 'img_' . time() . '_' . substr(md5(uniqid(rand(), true)), 0, 8) . '.' . $ext;
    $filePath = $uploadDir . '/' . $filename;

    if (file_put_contents($filePath, $decoded) === false) {
        sendJson(['error' => 'خطا در ذخیره‌سازی تصویر در هاست. دسترسی پوشه uploads را بررسی کنید.'], 500);
    }

    sendJson([
        'success' => true,
        'url' => '/uploads/' . $filename,
        'filename' => $filename
    ]);
}

if ($endpoint === 'delete-image') {
    if ($method !== 'DELETE' && $method !== 'POST') {
        sendJson(['error' => 'Method not allowed'], 405);
    }
    verifyAdminToken();

    $imageUrl = $_GET['url'] ?? $body['url'] ?? '';
    if (!$imageUrl) {
        sendJson(['error' => 'آدرس تصویر مشخص نشده است.'], 400);
    }

    if (strpos($imageUrl, '/uploads/') !== false) {
        $filename = basename($imageUrl);
        $filePath = __DIR__ . '/uploads/' . $filename;
        if (file_exists($filePath)) {
            @unlink($filePath);
        }
    }

    sendJson(['success' => true, 'message' => 'تصویر با موفقیت حذف شد.']);
}

// --- 6.2 پروژه‌ها (PROJECTS CRUD) ---
if ($endpoint === 'projects' || preg_match('#^projects/([0-9]+)$#', $endpoint, $pMatches)) {
    $projectId = isset($pMatches[1]) ? (int)$pMatches[1] : 0;

    if ($method === 'GET') {
        $result = $conn->query("SELECT * FROM `projects` ORDER BY id DESC");
        $projects = [];
        if ($result) {
            while ($r = $result->fetch_assoc()) {
                $projects[] = $r;
            }
        }
        sendJson($projects);
    }

    if ($method === 'POST') {
        verifyAdminToken();
        $title = $body['title'] ?? '';
        $cat = $body['category'] ?? 'وردپرس';
        $desc = $body['description'] ?? '';
        $img = $body['image_url'] ?? '';
        $link = $body['link'] ?? null;
        $tags = $body['tags'] ?? 'WordPress';

        if (!$title || !$desc || !$img) {
            sendJson(['error' => 'عنوان، توضیحات و تصویر الزامی هستند.'], 400);
        }

        $stmt = $conn->prepare("INSERT INTO `projects` (title, category, description, image_url, link, tags) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $title, $cat, $desc, $img, $link, $tags);
        $stmt->execute();
        $newId = $stmt->insert_id;

        $created = $conn->query("SELECT * FROM `projects` WHERE id = $newId")->fetch_assoc();
        sendJson($created, 201);
    }

    if ($method === 'PUT' && $projectId > 0) {
        verifyAdminToken();
        $title = $body['title'] ?? '';
        $cat = $body['category'] ?? 'وردپرس';
        $desc = $body['description'] ?? '';
        $img = $body['image_url'] ?? '';
        $link = $body['link'] ?? null;
        $tags = $body['tags'] ?? 'WordPress';

        $stmt = $conn->prepare("UPDATE `projects` SET title=?, category=?, description=?, image_url=?, link=?, tags=? WHERE id=?");
        $stmt->bind_param("ssssssi", $title, $cat, $desc, $img, $link, $tags, $projectId);
        $stmt->execute();

        $updated = $conn->query("SELECT * FROM `projects` WHERE id = $projectId")->fetch_assoc();
        sendJson($updated);
    }

    if ($method === 'DELETE' && $projectId > 0) {
        verifyAdminToken();
        $conn->query("DELETE FROM `projects` WHERE id = $projectId");
        sendJson(['success' => true, 'message' => 'نمونه کار با موفقیت حذف شد.']);
    }
}

// --- 6.3 تیم (TEAM CRUD) ---
if ($endpoint === 'team' || preg_match('#^team/([0-9]+)$#', $endpoint, $tMatches)) {
    $memberId = isset($tMatches[1]) ? (int)$tMatches[1] : 0;

    if ($method === 'GET') {
        $result = $conn->query("SELECT * FROM `team_members` ORDER BY id ASC");
        $team = [];
        if ($result) {
            while ($r = $result->fetch_assoc()) {
                $team[] = $r;
            }
        }
        sendJson($team);
    }

    if ($method === 'POST') {
        verifyAdminToken();
        $name = $body['name'] ?? '';
        $role = $body['role'] ?? '';
        $img = $body['image_url'] ?? '';
        $socials = is_array($body['socials_json'] ?? null) ? json_encode($body['socials_json']) : ($body['socials_json'] ?? '{}');

        $stmt = $conn->prepare("INSERT INTO `team_members` (name, role, image_url, socials_json) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $role, $img, $socials);
        $stmt->execute();
        $newId = $stmt->insert_id;

        $created = $conn->query("SELECT * FROM `team_members` WHERE id = $newId")->fetch_assoc();
        sendJson($created, 201);
    }

    if ($method === 'PUT' && $memberId > 0) {
        verifyAdminToken();
        $name = $body['name'] ?? '';
        $role = $body['role'] ?? '';
        $img = $body['image_url'] ?? '';
        $socials = is_array($body['socials_json'] ?? null) ? json_encode($body['socials_json']) : ($body['socials_json'] ?? '{}');

        $stmt = $conn->prepare("UPDATE `team_members` SET name=?, role=?, image_url=?, socials_json=? WHERE id=?");
        $stmt->bind_param("ssssi", $name, $role, $img, $socials, $memberId);
        $stmt->execute();

        $updated = $conn->query("SELECT * FROM `team_members` WHERE id = $memberId")->fetch_assoc();
        sendJson($updated);
    }

    if ($method === 'DELETE' && $memberId > 0) {
        verifyAdminToken();
        $conn->query("DELETE FROM `team_members` WHERE id = $memberId");
        sendJson(['success' => true, 'message' => 'عضو تیم حذف شد.']);
    }
}

// --- 6.4 فرم ثبت پیام (CONTACT & MESSAGES) ---
if ($endpoint === 'contact' || $endpoint === 'submit_contact') {
    if ($method === 'POST') {
        $name = trim($body['name'] ?? '');
        $phone = trim($body['phone'] ?? '');
        $type = trim($body['project_type'] ?? 'عمومی');
        $desc = trim($body['description'] ?? '');

        if (!$name || !$phone || !$desc) {
            sendJson(['error' => 'نام، شماره تماس و شرح پروژه الزامی هستند.'], 400);
        }

        $stmt = $conn->prepare("INSERT INTO `contact_messages` (name, phone, project_type, description) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $phone, $type, $desc);
        $stmt->execute();

        sendJson(['success' => true, 'id' => $stmt->insert_id, 'message' => 'پیام شما با موفقیت ثبت شد.']);
    }
}

if ($endpoint === 'messages' || preg_match('#^messages/([0-9]+)(/read)?$#', $endpoint, $mMatches)) {
    verifyAdminToken();
    $msgId = isset($mMatches[1]) ? (int)$mMatches[1] : 0;
    $isReadAction = isset($mMatches[2]) && $mMatches[2] === '/read';

    if ($method === 'GET') {
        $result = $conn->query("SELECT * FROM `contact_messages` ORDER BY id DESC");
        $messages = [];
        if ($result) {
            while ($r = $result->fetch_assoc()) {
                $messages[] = $r;
            }
        }
        sendJson($messages);
    }

    if ($method === 'PUT' && $isReadAction) {
        $conn->query("UPDATE `contact_messages` SET is_read = 1 WHERE id = $msgId");
        sendJson(['success' => true]);
    }

    if ($method === 'DELETE' && $msgId > 0) {
        $conn->query("DELETE FROM `contact_messages` WHERE id = $msgId");
        sendJson(['success' => true]);
    }
}

// --- 6.5 رنگ‌های قالب سایت (COLORS PALETTE) ---
if ($endpoint === 'colors') {
    if ($method === 'GET') {
        $colors = [
            'Background' => '#0A0A0F',
            'Surface' => '#12121A',
            'Navbar' => 'rgba(18, 18, 26, 0.85)',
            'Primary Text' => '#F8FAFC',
            'Secondary Text' => '#CBD5E1',
            'Muted Text' => '#64748B',
            'Primary Accent' => '#C9A84C',
            'Hover Accent' => '#E2BF5F',
            'Border' => '#222232',
            'Success' => '#10B981',
            'Error' => '#EF4444'
        ];

        $res = $conn->query("SELECT color_key, color_value FROM `site_colors`");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $colors[$r['color_key']] = $r['color_value'];
            }
        }
        sendJson($colors);
    }

    if ($method === 'PUT') {
        verifyAdminToken();
        if (is_array($body)) {
            foreach ($body as $key => $val) {
                $stmt = $conn->prepare("INSERT INTO `site_colors` (color_key, color_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE color_value=VALUES(color_value)");
                $stmt->bind_param("ss", $key, $val);
                $stmt->execute();
            }
        }
        sendJson(['success' => true]);
    }
}

if ($endpoint === 'colors/reset') {
    verifyAdminToken();
    $conn->query("TRUNCATE TABLE `site_colors`");
    sendJson(['success' => true]);
}

// --- 6.6 تنظیمات ربات و هوش مصنوعی ---
if ($endpoint === 'admin/bot-settings' || $endpoint === 'emo/config') {
    if ($method === 'GET') {
        $settings = [
            'EMO_SYSTEM_PROMPT' => 'شما دستیار هوش مصنوعی ایزاتس وب (izatesweb) به نام ایمو (Emo) هستید.',
            'SITE_NAME' => 'izatesweb',
            'GEMINI_MODEL' => 'gemini-2.5-flash',
            'DEFAULT_VOICE' => 'fa-IR-DilaraNeural'
        ];
        $res = $conn->query("SELECT setting_key, setting_value FROM `bot_settings`");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $settings[$r['setting_key']] = $r['setting_value'];
            }
        }
        sendJson($settings);
    }

    if ($method === 'PUT' || $method === 'POST') {
        verifyAdminToken();
        if (is_array($body)) {
            foreach ($body as $key => $val) {
                $stmt = $conn->prepare("INSERT INTO `bot_settings` (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
                $stmt->bind_param("ss", $key, $val);
                $stmt->execute();
            }
        }
        sendJson(['success' => true]);
    }
}

// --- 6.7 تست سلامت (HEALTH CHECK) ---
if ($endpoint === 'health' || $endpoint === 'status' || empty($endpoint)) {
    sendJson([
        'status' => 'ok',
        'database' => DB_NAME,
        'app' => 'izatesweb_php_api',
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}

sendJson(['error' => 'Endpoint not found: ' . $endpoint], 404);
