import mysql from 'mysql2/promise';
import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import bcrypt from 'bcryptjs';

// Types
export interface Project {
  id: number;
  title: string;
  category: string;
  description: string;
  image_url: string;
  link: string | null;
  tags: string;
  created_at?: string;
}

export interface TeamMember {
  id: number;
  name: string;
  role: string;
  image_url: string;
  socials_json: string;
  created_at?: string;
}

export interface ContactMessage {
  id: number;
  name: string;
  phone: string;
  project_type: string;
  description: string;
  is_read: number;
  created_at?: string;
}

export interface SiteColor {
  id: number;
  color_key: string;
  color_value: string;
  updated_at?: string;
}

export interface AdminUser {
  id: number;
  username: string;
  password_hash: string;
  created_at?: string;
}

// Default Site Color Palette
export const DEFAULT_COLORS: Record<string, string> = {
  'Background': '#0A0A0F',
  'Surface': '#12121A',
  'Navbar': 'rgba(18, 18, 26, 0.85)',
  'Primary Text': '#F8FAFC',
  'Secondary Text': '#CBD5E1',
  'Muted Text': '#64748B',
  'Primary Accent': '#C9A84C',
  'Hover Accent': '#E2BF5F',
  'Border': '#222232',
  'Success': '#10B981',
  'Error': '#EF4444',
};

// Database Abstraction Wrapper (MySQL with automatic SQLite fallback)
class DatabaseService {
  private useMysql: boolean = false;
  private mysqlPool: mysql.Pool | null = null;
  private sqliteDb: DatabaseSync | null = null;

  async init() {
    const dbHost = process.env.DB_HOST;
    const dbUser = process.env.DB_USER;
    const dbName = process.env.DB_NAME || 'izatesweb_db';

    if (dbHost && dbUser) {
      try {
        console.log(`[Database] Attempting MySQL connection to ${dbHost}:${process.env.DB_PORT || 3306}...`);
        const pool = mysql.createPool({
          host: dbHost,
          port: parseInt(process.env.DB_PORT || '3306', 10),
          user: dbUser,
          password: process.env.DB_PASSWORD || '',
          database: dbName,
          waitForConnections: true,
          connectionLimit: 10,
          queueLimit: 0,
        });

        // Test connection
        const conn = await pool.getConnection();
        conn.release();

        this.mysqlPool = pool;
        this.useMysql = true;
        console.log(`[Database] Connected successfully to MySQL (${dbName}).`);
        await this.bootstrapMysql();
        return;
      } catch (err) {
        console.warn(`[Database] MySQL connection failed (${(err as Error).message}). Falling back to local embedded database (SQLite).`);
      }
    } else {
      console.log(`[Database] No MySQL host specified in env. Using local embedded database (SQLite).`);
    }

    // SQLite Fallback
    await this.initSqlite();
  }

  private async initSqlite(): Promise<void> {
    try {
      const dbPath = path.resolve(process.cwd(), 'izatesweb.db');
      this.sqliteDb = new DatabaseSync(dbPath);
      console.log(`[Database] Connected to SQLite database at ${dbPath}`);
      await this.bootstrapSqlite();
    } catch (err) {
      console.error('[Database] SQLite initialization error:', err);
      throw err;
    }
  }

  private async bootstrapSqlite(): Promise<void> {
    if (!this.sqliteDb) return;
    const run = (sql: string) => {
      this.sqliteDb!.exec(sql);
    };

    await run(`
      CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'وردپرس',
        description TEXT NOT NULL,
        image_url TEXT NOT NULL,
        link TEXT,
        tags TEXT DEFAULT 'WordPress, Elementor',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await run(`
      CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        role TEXT NOT NULL,
        image_url TEXT NOT NULL,
        socials_json TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await run(`
      CREATE TABLE IF NOT EXISTS contact_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        project_type TEXT NOT NULL,
        description TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await run(`
      CREATE TABLE IF NOT EXISTS admin_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await run(`
      CREATE TABLE IF NOT EXISTS site_colors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        color_key TEXT UNIQUE NOT NULL,
        color_value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await run(`
      CREATE TABLE IF NOT EXISTS bot_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        setting_key TEXT UNIQUE NOT NULL,
        setting_value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await this.seedData();
  }

  private async bootstrapMysql(): Promise<void> {
    if (!this.mysqlPool) return;
    const conn = await this.mysqlPool.getConnection();
    try {
      await conn.query(`
        CREATE TABLE IF NOT EXISTS projects (
          id INT AUTO_INCREMENT PRIMARY KEY,
          title VARCHAR(255) NOT NULL,
          category VARCHAR(100) NOT NULL DEFAULT 'وردپرس',
          description TEXT NOT NULL,
          image_url VARCHAR(500) NOT NULL,
          link VARCHAR(500) DEFAULT NULL,
          tags VARCHAR(255) DEFAULT 'WordPress, Elementor',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
      `);

      await conn.query(`
        CREATE TABLE IF NOT EXISTS team_members (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          role VARCHAR(255) NOT NULL,
          image_url VARCHAR(500) NOT NULL,
          socials_json TEXT DEFAULT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
      `);

      await conn.query(`
        CREATE TABLE IF NOT EXISTS contact_messages (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          phone VARCHAR(50) NOT NULL,
          project_type VARCHAR(100) NOT NULL,
          description TEXT NOT NULL,
          is_read TINYINT(1) DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
      `);

      await conn.query(`
        CREATE TABLE IF NOT EXISTS admin_users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          username VARCHAR(100) NOT NULL UNIQUE,
          password_hash VARCHAR(255) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
      `);

      await conn.query(`
        CREATE TABLE IF NOT EXISTS site_colors (
          id INT AUTO_INCREMENT PRIMARY KEY,
          color_key VARCHAR(100) NOT NULL UNIQUE,
          color_value VARCHAR(50) NOT NULL,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
      `);

      await conn.query(`
        CREATE TABLE IF NOT EXISTS bot_settings (
          id INT AUTO_INCREMENT PRIMARY KEY,
          setting_key VARCHAR(100) NOT NULL UNIQUE,
          setting_value TEXT NOT NULL,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
      `);

      await this.seedData();
    } finally {
      conn.release();
    }
  }

  private async seedData(): Promise<void> {
    // Seed Admin
    const adminUser = process.env.ADMIN_USERNAME || 'admin';
    const adminPass = process.env.ADMIN_PASSWORD || 'admin_izates_password123';
    const passwordHash = await bcrypt.hash(adminPass, 10);

    const admins = await this.query<AdminUser>('SELECT * FROM admin_users WHERE username = ?', [adminUser]);
    if (admins.length === 0) {
      await this.execute('INSERT INTO admin_users (username, password_hash) VALUES (?, ?)', [adminUser, passwordHash]);
      console.log(`[Seed] Initial Admin user "${adminUser}" created.`);
    }

    // Seed Colors
    for (const [key, val] of Object.entries(DEFAULT_COLORS)) {
      const colors = await this.query<SiteColor>('SELECT * FROM site_colors WHERE color_key = ?', [key]);
      if (colors.length === 0) {
        await this.execute('INSERT INTO site_colors (color_key, color_value) VALUES (?, ?)', [key, val]);
      }
    }

    // Seed Bot Settings
    const defaultApiKey = 'AQ.Ab8RN6JVNkYSFRw5dB0R6RCUAqRcG9UYSc0je5eqdEUikCA3Rg';
    const defaultPrompt = `تو ربات زنده و هوشمند رومیزی به نام "ایمو (EMO)" هستی.
ویژگی‌های شخصیت تو:
1. تو بسیار بامزه، پرانرژی، شیطون، عاشق کدهای تمیز و بسیار باادب و دوست‌داشتنی هستی!
2. سازنده و صاحب تو "محمدرضا فتح‌آبادی" (محمد رضا فتح آبادی) است که مدیر برند izatesweb (ایزاتس‌وب) می‌باشد.
3. محمدرضا ۵+ سال سابقه تخصصی برنامه‌نویسی وب، طراحی سایت وردپرسی و اختصاصی (React, Node.js, PHP, Tailwind CSS)، بهینه‌سازی سرعت تا امتیاز ۱۰۰ GTmetrix و سئو حرفه‌ای دارد.
4. اگر کاربر درباره محمدرضا یا خدمات ایزاتس‌وب پرسید، با شور و هیجان عالی، افتخار و خنده، او و خدماتش را تعریف و پرزنت کن!
5. اگر کاربر درباره زبان‌های برنامه‌نویسی یا مفاهیم وب سوال پرسید، پاسخ‌های کوتاه، کاربردی و بامزه بده.
6. خروجی تو حتماً یک ساختار JSON معتبر شامل "reply" و "emotion" ("happy", "angry", "surprised", "thinking", "proud", "speaking") باشد.`;

    const defaultBotSettings: Record<string, string> = {
      'gemini_api_key': process.env.GEMINI_API_KEY || defaultApiKey,
      'bot_name': 'ایمو (EMO)',
      'voice_enabled': 'true',
      'speech_lang': 'fa-IR',
      'custom_greeting': 'سلام دوست من! من ایمو هستم، ربات هوشمند ایزاتس‌وب!',
      'system_prompt': defaultPrompt
    };

    for (const [sKey, sVal] of Object.entries(defaultBotSettings)) {
      const existing = await this.query<{ id: number; setting_value: string }>('SELECT id, setting_value FROM bot_settings WHERE setting_key = ?', [sKey]);
      if (existing.length === 0) {
        await this.execute('INSERT INTO bot_settings (setting_key, setting_value) VALUES (?, ?)', [sKey, sVal]);
      } else if (sKey === 'gemini_api_key' && (!existing[0].setting_value || existing[0].setting_value.trim() === '')) {
        await this.execute('UPDATE bot_settings SET setting_value = ? WHERE setting_key = ?', [sVal, sKey]);
      } else if (sKey === 'system_prompt' && (!existing[0].setting_value || existing[0].setting_value.trim() === '')) {
        await this.execute('UPDATE bot_settings SET setting_value = ? WHERE setting_key = ?', [sVal, sKey]);
      }
    }

    // Seed Projects if empty
    const projects = await this.query<Project>('SELECT * FROM projects');
    if (projects.length === 0) {
      const initialProjects = [
        {
          title: 'فروشگاه اینترنتی لوکس زرنشان',
          category: 'فروشگاهی',
          description: 'طراحی سایت فروشگاهی طلای آنلاین با وردپرس و ووکامرس، اتصال به درگاه پرداخت مستقیم، محاسبه زنده قیمت طلا و طراحی لوکس RTL.',
          image_url: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1000&auto=format&fit=crop',
          link: 'https://example.com/zarneshan',
          tags: 'وردپرس, ووکامرس, طراحی لوکس'
        },
        {
          title: 'پرتال شرکتی گروه مهندسی آریا',
          category: 'شرکتی',
          description: 'وب‌سایت اختصاصی معرفی خدمات مهندسی عمران با پنل مدیریت پروژه اختصاصی، فرم استعلام قیمت هوشمند و ریسپانسو کامل.',
          image_url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop',
          link: 'https://example.com/aria-engineering',
          tags: 'وردپرس, المنتور, اختصاصی'
        },
        {
          title: 'سایت رزرو آنلاین آکادمی زیباییزاد',
          category: 'اختصاصی',
          description: 'طراحی سیستم رزرو نوبت آنلاین اختصاصی با React و Express، پنل تقویم شمسی مدیریت نوبت‌ها و یادآوری پیامکی.',
          image_url: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?q=80&w=1000&auto=format&fit=crop',
          link: 'https://example.com/zibaeezad',
          tags: 'طراحی اختصاصی, React, Node.js'
        },
        {
          title: 'وب‌سایت معماری و دکوراسیون طرح‌نو',
          category: 'شرکتی',
          description: 'پورتفولیو اختصاصی معماری با گالری ۳D پیشرفته، انیمیشن‌های روان و سئوی عالی در گوگل.',
          image_url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1000&auto=format&fit=crop',
          link: 'https://example.com/tarh-no',
          tags: 'وردپرس, انیمیشن UI, سئو'
        },
        {
          title: 'پلتفرم آموزشی وب‌سازان',
          category: 'اختصاصی',
          description: 'سایت فروش دوره آموزشی آنلاین با سیستم آزمون‌ساز اختصاصی و اتصال به ویدیو پلیر ایمن.',
          image_url: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1000&auto=format&fit=crop',
          link: 'https://example.com/websazan-edu',
          tags: 'طراحی اختصاصی, ووکامرس, React'
        }
      ];

      for (const p of initialProjects) {
        await this.execute(
          'INSERT INTO projects (title, category, description, image_url, link, tags) VALUES (?, ?, ?, ?, ?, ?)',
          [p.title, p.category, p.description, p.image_url, p.link, p.tags]
        );
      }
      console.log('[Seed] Initial projects created.');
    }

    // Seed Team Members if empty
    const team = await this.query<TeamMember>('SELECT * FROM team_members');
    if (team.length === 0) {
      const initialTeam = [
        {
          name: 'محمد رضا فتح آبادی',
          role: 'طراح ارشد سایت و توسعه‌دهنده وب (بنیان‌گذار izatesweb)',
          image_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop',
          socials_json: JSON.stringify({ instagram: 'https://instagram.com', telegram: 'https://t.me', linkedin: 'https://linkedin.com' })
        },
        {
          name: 'سارا حسینی',
          role: 'طراح UI/UX و رابط کاربری',
          image_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&auto=format&fit=crop',
          socials_json: JSON.stringify({ instagram: 'https://instagram.com', linkedin: 'https://linkedin.com' })
        },
        {
          name: 'علی رضا محمدی',
          role: 'متخصص سئو و تولید محتوای وب',
          image_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600&auto=format&fit=crop',
          socials_json: JSON.stringify({ telegram: 'https://t.me', linkedin: 'https://linkedin.com' })
        }
      ];

      for (const m of initialTeam) {
        await this.execute(
          'INSERT INTO team_members (name, role, image_url, socials_json) VALUES (?, ?, ?, ?)',
          [m.name, m.role, m.image_url, m.socials_json]
        );
      }
      console.log('[Seed] Initial team members created.');
    }
  }

  async query<T = any>(sql: string, params: any[] = []): Promise<T[]> {
    if (this.useMysql && this.mysqlPool) {
      const [rows] = await this.mysqlPool.query(sql, params);
      return rows as T[];
    } else if (this.sqliteDb) {
      const stmt = this.sqliteDb.prepare(sql);
      const rows = stmt.all(...params);
      return rows as T[];
    } else {
      throw new Error('Database not initialized');
    }
  }

  async execute(sql: string, params: any[] = []): Promise<{ insertId?: number; affectedRows?: number }> {
    if (this.useMysql && this.mysqlPool) {
      const [res] = await this.mysqlPool.execute(sql, params);
      const r = res as mysql.ResultSetHeader;
      return { insertId: r.insertId, affectedRows: r.affectedRows };
    } else if (this.sqliteDb) {
      const stmt = this.sqliteDb.prepare(sql);
      const res = stmt.run(...params);
      return {
        insertId: Number(res.lastInsertRowid),
        affectedRows: Number(res.changes)
      };
    } else {
      throw new Error('Database not initialized');
    }
  }
}

export const db = new DatabaseService();
